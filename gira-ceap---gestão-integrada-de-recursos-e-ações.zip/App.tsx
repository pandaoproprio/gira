
import React, { useState, useEffect, Suspense } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Layout } from './components/Layout';
import { AIOverlay } from './components/AIOverlay';
import { Button, Input, ToastProvider, useToast } from './components/UI';
import { Mail, Lock, Eye, EyeOff, Fingerprint, Cpu, ArrowRight, Database, AlertCircle } from 'lucide-react';

// --- LAZY LOADED MODULES (Code Splitting) ---
// Carrega os módulos apenas quando necessários para reduzir o bundle inicial
const Dashboard = React.lazy(() => import('./pages/Dashboard').then(module => ({ default: module.Dashboard })));
const Users = React.lazy(() => import('./pages/Users').then(module => ({ default: module.Users })));
const Supplies = React.lazy(() => import('./pages/Supplies').then(module => ({ default: module.Supplies })));
const Suppliers = React.lazy(() => import('./pages/Suppliers').then(module => ({ default: module.Suppliers })));
const Projects = React.lazy(() => import('./pages/Projects').then(module => ({ default: module.Projects })));
const Settings = React.lazy(() => import('./pages/Settings').then(module => ({ default: module.Settings })));
const Finance = React.lazy(() => import('./pages/Finance').then(module => ({ default: module.Finance })));
const Patrimony = React.lazy(() => import('./pages/Patrimony').then(module => ({ default: module.Patrimony })));
const HR = React.lazy(() => import('./pages/HR').then(module => ({ default: module.HR })));
const Contracts = React.lazy(() => import('./pages/Contracts').then(module => ({ default: module.Contracts })));
const Documents = React.lazy(() => import('./pages/Documents').then(module => ({ default: module.Documents })));
const CEAPInsight = React.lazy(() => import('./pages/CEAPInsight').then(module => ({ default: module.CEAPInsight })));
const Conformia = React.lazy(() => import('./pages/Conformia').then(module => ({ default: module.Conformia })));
const GiraVinculos = React.lazy(() => import('./pages/GiraVinculos').then(module => ({ default: module.GiraVinculos })));
const Reports = React.lazy(() => import('./pages/Reports').then(module => ({ default: module.Reports })));

// Componente de Carregamento Visual para transição de rotas
const PageLoader = () => (
  <div className="h-[70vh] flex flex-col items-center justify-center gap-6 animate-in fade-in duration-300">
    <div className="relative w-16 h-16">
       <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
       <div className="absolute inset-0 border-4 border-t-indigo-600 rounded-full animate-spin"></div>
    </div>
    <div className="text-center">
      <p className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-widest">Carregando Módulo</p>
      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em] mt-1 animate-pulse">Otimizando Recursos...</p>
    </div>
  </div>
);

const LoginView: React.FC = () => {
  const { login, authError } = useAuth();
  const toast = useToast();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const result = await login(email, password);
    if (result.success) {
      toast.success('Bem-vindo ao GIRA CEAP Cloud.');
    } else {
      toast.error(result.error || 'Erro ao entrar no sistema.');
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50 relative overflow-hidden">
      {/* Optimized Background: Static Gradients instead of heavy blurs */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-indigo-100 via-slate-50 to-emerald-50 opacity-70"></div>
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none"></div>

      <div className="w-full max-w-[460px] z-10 animate-in fade-in zoom-in-95 duration-700">
        <div className="bg-white rounded-[48px] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.08)] border border-slate-100 overflow-hidden">
            <div className="bg-slate-50/50 border-b border-slate-100 px-10 py-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
                  Autenticação Corporativa
                </span>
              </div>
              <Database size={16} className="text-indigo-400" />
            </div>

            <div className="p-10 md:p-14">
              <div className="flex flex-col items-center mb-12 text-center">
                <div className="relative mb-8">
                  <div className="absolute inset-0 bg-indigo-500/10 blur-xl rounded-full"></div>
                  <div className="w-20 h-20 bg-white border border-slate-100 rounded-3xl flex items-center justify-center shadow-xl relative transform -rotate-3 transition-transform hover:rotate-0">
                    <div className="bg-gradient-to-br from-indigo-600 to-indigo-400 bg-clip-text text-transparent font-black text-4xl">G</div>
                  </div>
                </div>

                <h1 className="text-4xl font-black text-slate-900 tracking-tighter mb-2">
                  GIRA <span className="text-indigo-600">CEAP</span>
                </h1>
                <p className="text-slate-400 font-bold text-[10px] uppercase tracking-[0.2em]">Acesso Restrito @ceapoficial.org.br</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">E-mail Institucional</label>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors">
                      <Mail size={18} />
                    </div>
                    <input 
                      type="email" 
                      value={email} 
                      onChange={e => setEmail(e.target.value)} 
                      required 
                      placeholder="nome@ceapoficial.org.br"
                      className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-slate-100 bg-slate-50/50 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:border-indigo-500 focus:bg-white focus:outline-none transition-all"
                    />
                  </div>
                </div>
                
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Senha de Acesso</label>
                    <button type="button" className="text-[10px] font-black text-indigo-500 uppercase hover:underline">Recuperar</button>
                  </div>
                  <div className="relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors">
                      <Lock size={18} />
                    </div>
                    <input 
                      type={showPassword ? "text" : "password"} 
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required 
                      placeholder="••••••••"
                      className="w-full pl-12 pr-12 py-4 rounded-2xl border-2 border-slate-100 bg-slate-50/50 text-sm font-bold text-slate-700 placeholder:text-slate-300 focus:border-indigo-500 focus:bg-white focus:outline-none transition-all"
                    />
                    <button 
                      type="button" 
                      onClick={() => setShowPassword(!showPassword)} 
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-600 transition-colors"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {authError && (
                  <div className="flex items-center gap-2 p-4 bg-rose-50 border border-rose-100 rounded-2xl animate-in fade-in zoom-in-95">
                    <AlertCircle size={16} className="text-rose-500 shrink-0" />
                    <p className="text-[10px] font-black text-rose-500 uppercase leading-tight">{authError}</p>
                  </div>
                )}

                <Button 
                  className="w-full h-16 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-xl shadow-indigo-600/20 font-black uppercase tracking-widest text-xs mt-2 transition-all active:scale-[0.98] group" 
                  loading={isSubmitting}
                >
                  {!isSubmitting && (
                    <>
                      Acessar Painel
                      <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                  Não possui conta? Contate o Administrador
                </p>
              </div>

              <div className="mt-12 pt-8 border-t border-slate-100 grid grid-cols-2 gap-4">
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-100/50">
                  <Fingerprint size={20} className="text-indigo-400" />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black text-slate-400 uppercase leading-none mb-1">Status</span>
                    <span className="text-[9px] font-black text-slate-900 uppercase">Seguro</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-100/50">
                  <Cpu size={20} className="text-emerald-400" />
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black text-slate-400 uppercase leading-none mb-1">Versão</span>
                    <span className="text-[9px] font-black text-slate-900 uppercase">CLOUD 6.2 FAST</span>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  );
};

const MainApp: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    const handleNav = (e: any) => setActiveTab(e.detail);
    window.addEventListener('nav-change', handleNav);
    return () => window.removeEventListener('nav-change', handleNav);
  }, []);

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-white">
       <div className="flex flex-col items-center gap-6">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-t-indigo-600 rounded-full animate-spin"></div>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em] animate-pulse">Sincronizando com Cloud...</p>
       </div>
    </div>
  );

  if (!currentUser) return <LoginView />;

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'reports': return <Reports />;
      case 'finance': return <Finance />;
      case 'supplies': return <Supplies />;
      case 'suppliers': return <Suppliers />;
      case 'patrimony': return <Patrimony />;
      case 'hr': return <HR />;
      case 'projects': return <Projects />;
      case 'crm': return <GiraVinculos />;
      case 'contracts': return <Contracts />;
      case 'docs': return <Documents />;
      case 'users': return <Users />;
      case 'insight': return <CEAPInsight />;
      case 'conformia': return <Conformia />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
        <div className="max-w-[1600px] mx-auto animate-in fade-in duration-500">
            {/* Suspense Wrapper para gerenciar carregamento assíncrono dos módulos */}
            <Suspense fallback={<PageLoader />}>
              {renderContent()}
            </Suspense>
        </div>
        <AIOverlay />
    </Layout>
  );
};

const App: React.FC = () => (
  <ToastProvider>
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  </ToastProvider>
);

export default App;

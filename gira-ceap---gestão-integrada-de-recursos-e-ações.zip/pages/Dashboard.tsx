
import React, { useMemo, useEffect, useState } from 'react';
import { Card, Badge, useTheme, useToast } from '../components/UI';
import { 
  TrendingUp, TrendingDown, Package, Briefcase, 
  AlertCircle, Activity, ChevronRight, Sparkles, Loader2, Leaf, Heart
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area
} from 'recharts';
import { mockDB } from '../services/mockDB';
import { useAuth } from '../context/AuthContext';
import { FirestoreService } from '../services/FirestoreService';
import { Material, Project, AuditLog } from '../types';
import { orderBy, limit } from 'firebase/firestore';

const KPICard: React.FC<{ title: string; subtitle?: string; value: string; trend: number; icon: React.ReactNode; color: string; onClick?: () => void; loading?: boolean }> = ({ title, subtitle, value, trend, icon, color, onClick, loading }) => (
  <Card onClick={onClick} className="hover:scale-[1.03] transition-all cursor-pointer group glass relative overflow-hidden">
    {loading && <div className="absolute inset-0 bg-white/50 dark:bg-slate-900/50 z-10 flex items-center justify-center backdrop-blur-sm"><Loader2 className="animate-spin text-slate-400"/></div>}
    <div className="flex justify-between items-start mb-6">
      <div className={`p-4 rounded-[20px] ${color} shadow-lg transition-transform group-hover:rotate-12 duration-500`}>
        {icon}
      </div>
      <div className={`flex items-center gap-1.5 text-xs font-black ${trend >= 0 ? 'text-emerald-500' : 'text-rose-500'} bg-white/50 dark:bg-black/20 px-3 py-1.5 rounded-full backdrop-blur-md border border-white/20 dark:border-white/5`}>
        {trend >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
        {Math.abs(trend)}%
      </div>
    </div>
    <p className="text-slate-400 dark:text-slate-500 text-[10px] font-black uppercase tracking-widest">{title}</p>
    <h3 className="text-3xl font-black text-slate-800 dark:text-white mt-1 tracking-tighter">{value}</h3>
    {subtitle && <p className="text-[10px] font-bold text-slate-400 mt-1">{subtitle}</p>}
    <div className="mt-6 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-500">
        <span className="text-[10px] font-bold text-blue-500">Ver detalhes</span>
        <ChevronRight size={14} className="text-blue-500" />
    </div>
  </Card>
);

export const Dashboard: React.FC<{ onNavigate?: (tab: string) => void }> = ({ onNavigate }) => {
  const { isDark } = useTheme();
  const { currentUser } = useAuth();
  const toast = useToast();

  const [materials, setMaterials] = useState<Material[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const chartData = useMemo(() => mockDB.getChartData(), []);

  useEffect(() => {
    setIsLoading(true);
    const unsubMaterials = FirestoreService.subscribe<Material>('materials', (data) => setMaterials(data));
    const unsubProjects = FirestoreService.subscribe<Project>('projects', (data) => setProjects(data));
    const unsubLogs = FirestoreService.subscribe<AuditLog>('auditLogs', (data) => {
      setLogs(data);
      setIsLoading(false);
    }, [orderBy('timestamp', 'desc'), limit(5)]);

    return () => {
      unsubMaterials();
      unsubProjects();
      unsubLogs();
    };
  }, []);

  const totalBudget = useMemo(() => projects.reduce((acc, p) => acc + (p.approvedValue || 0), 0), [projects]);
  const criticalMaterials = useMemo(() => materials.filter(m => m.quantity <= m.minQuantity).length, [materials]);

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-2">
              <span className="px-3 py-1 bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-[10px] font-black rounded-full uppercase tracking-widest shadow-lg shadow-indigo-500/20">Ecossistema GIRA</span>
              <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-600 rounded-full border border-emerald-500/20">
                 <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                 <span className="text-[9px] font-black uppercase tracking-widest">Online</span>
              </div>
          </div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter leading-tight">
            Olá, <span className="text-indigo-600">{currentUser?.name?.split(' ')[0]}!</span>
          </h2>
          <div className="flex items-center gap-3 p-4 glass rounded-3xl border-indigo-500/10 max-w-2xl">
            <Sparkles size={20} className="text-indigo-500 shrink-0" />
            <p className="text-slate-500 dark:text-slate-400 font-bold text-sm leading-relaxed">
              Monitorização ativa de <span className="text-indigo-600">Projetos de Economia Criativa</span> e métricas de <span className="text-emerald-600">Impacto ESG</span> para a Comunidade Negra.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <KPICard 
          title="Gestão de Recursos" 
          subtitle="Ativos e Materiais"
          value={materials.length.toString()} 
          trend={12} 
          icon={<Package className="text-white" />} 
          color="bg-orange-500" 
          loading={isLoading}
          onClick={() => window.dispatchEvent(new CustomEvent('nav-change', { detail: 'supplies' }))}
        />
        <KPICard 
          title="Economia Criativa" 
          subtitle="Projetos Ativos"
          value={projects.length.toString()} 
          trend={5} 
          icon={<Briefcase className="text-white" />} 
          color="bg-violet-600" 
          loading={isLoading}
          onClick={() => window.dispatchEvent(new CustomEvent('nav-change', { detail: 'projects' }))}
        />
        <KPICard 
          title="Fundo ESG" 
          subtitle="Investimento Social"
          value={`R$ ${(totalBudget / 1000).toFixed(0)}k`} 
          trend={8} 
          icon={<Leaf className="text-white" />} 
          color="bg-emerald-600" 
          loading={isLoading}
          onClick={() => window.dispatchEvent(new CustomEvent('nav-change', { detail: 'finance' }))}
        />
        <KPICard 
          title="Comunidade" 
          subtitle="Beneficiários"
          value="1.2k" 
          trend={24} 
          icon={<Heart className="text-white" />} 
          color="bg-rose-500" 
          loading={isLoading}
          onClick={() => window.dispatchEvent(new CustomEvent('nav-change', { detail: 'crm' }))}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <Card className="xl:col-span-2 glass" title="Ações de Impacto (Evolução)" subtitle="Comparativo: Recursos vs Projetos Criativos">
          <div className="h-[400px] mt-10">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSup" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.4}/><stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorProj" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4}/><stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? '#1e293b' : '#f1f5f9'} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 800}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 800}} />
                <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', backgroundColor: isDark ? '#0F172A' : '#FFFFFF' }} />
                <Area type="monotone" dataKey="suprimentos" stroke="#f97316" fill="url(#colorSup)" strokeWidth={4} name="Recursos" />
                <Area type="monotone" dataKey="projetos" stroke="#8b5cf6" fill="url(#colorProj)" strokeWidth={4} name="Projetos" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Feed de Ações Recentes" action={<Badge color="indigo" className="animate-pulse">Live</Badge>}>
          <div className="mt-6 space-y-6">
            {logs.map((log) => (
              <div key={log.id} className="flex gap-4 items-start group animate-in slide-in-from-right-2 duration-300">
                <div className="w-10 h-10 rounded-xl glass flex items-center justify-center shrink-0 group-hover:bg-indigo-500 transition-colors">
                  <Activity size={18} className="text-slate-400 group-hover:text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between">
                    <p className="text-xs font-black text-slate-800 dark:text-white truncate pr-2">{log.action}</p>
                    <span className="text-[9px] font-bold text-slate-400 whitespace-nowrap">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[10px] text-slate-500 truncate mt-0.5">{log.details}</p>
                  <p className="text-[9px] font-bold text-indigo-500 mt-1 uppercase">{log.userName}</p>
                </div>
              </div>
            ))}
            {logs.length === 0 && <div className="py-10 text-center text-xs opacity-40 uppercase font-black tracking-widest">Sem atividades recentes...</div>}
          </div>
        </Card>
      </div>
    </div>
  );
};

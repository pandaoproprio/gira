
import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Modal, Badge, useToast } from '../components/UI';
import { 
  Plus, Search, Truck, Phone, Mail, MapPin, 
  ExternalLink, ShieldCheck, Star, AlertCircle,
  RefreshCcw, Edit2, Trash2, Building2, Globe, Loader2
} from 'lucide-react';
import { Supplier } from '../types';
import { AuditService } from '../services/AuditService';
import { FirestoreService } from '../services/FirestoreService';
import { useAuth } from '../context/AuthContext';

export const Suppliers: React.FC = () => {
  const toast = useToast();
  const { currentUser: loggedUser } = useAuth();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingCnpj, setIsLoadingCnpj] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  const [formValues, setFormValues] = useState({
    cnpj: '',
    companyName: '',
    tradeName: '',
    email: '',
    phone: '',
    website: '',
    address: '',
    status: 'ATIVO' as 'ATIVO' | 'BLOQUEADO'
  });

  const [formErrors, setFormErrors] = useState({ email: '', website: '' });

  // Carrega dados do Firestore
  const loadSuppliers = async () => {
    setIsLoading(true);
    try {
      const data = await FirestoreService.getAll<Supplier>('suppliers');
      setSuppliers(data);
    } catch (error) {
      toast.error("Erro ao sincronizar base de fornecedores.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadSuppliers();
  }, []);

  const filteredSuppliers = useMemo(() => {
    return suppliers.filter(s => 
      s.companyName.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.cnpj.includes(searchTerm) ||
      s.tradeName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [suppliers, searchTerm]);

  useEffect(() => {
    if (editingSupplier) {
      setFormValues({
        cnpj: editingSupplier.cnpj,
        companyName: editingSupplier.companyName,
        tradeName: editingSupplier.tradeName,
        email: editingSupplier.email,
        phone: editingSupplier.phone,
        website: editingSupplier.website || '',
        address: editingSupplier.address,
        status: editingSupplier.status as any
      });
    } else {
      setFormValues({
        cnpj: '',
        companyName: '',
        tradeName: '',
        email: '',
        phone: '',
        website: '',
        address: '',
        status: 'ATIVO'
      });
    }
    setFormErrors({ email: '', website: '' });
  }, [editingSupplier, isModalOpen]);

  const validateEmail = (email: string) => {
    if (!email) return '';
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email) ? '' : 'E-mail inválido';
  };

  const validateWebsite = (url: string) => {
    if (!url) return '';
    const regex = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    return regex.test(url) ? '' : 'Website inválido';
  };

  const handleConsultCnpj = async (cnpj: string) => {
    const cleanCnpj = cnpj.replace(/\D/g, '');
    if (cleanCnpj.length !== 14) return;
    setIsLoadingCnpj(true);
    try {
      const response = await fetch(`https://brasilapi.com.br/api/cnpj/v1/${cleanCnpj}`);
      if (!response.ok) throw new Error('CNPJ não localizado.');
      const data = await response.json();
      
      // Validação de Situação Cadastral
      const isBaixada = data.descricao_situacao_cadastral === 'BAIXADA';
      
      setFormValues(prev => ({
        ...prev,
        companyName: data.razao_social || '',
        tradeName: data.nome_fantasia || data.razao_social || '',
        email: data.email || '',
        phone: data.ddd_telefone_1 ? `(${data.ddd_telefone_1}) ${data.telefone_1}` : '',
        address: `${data.logradouro}, ${data.numero}, ${data.bairro}, ${data.municipio} - ${data.uf}`,
        status: isBaixada ? 'BLOQUEADO' : prev.status
      }));

      if (isBaixada) {
        toast.error('CNPJ com situação "BAIXADA" detectado na Receita Federal. O cadastro foi marcado como BLOQUEADO preventivamente.');
      } else {
        toast.success(`Dados sincronizados: ${data.razao_social}`);
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsLoadingCnpj(false);
    }
  };

  const handleSaveSupplier = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const emailErr = validateEmail(formValues.email);
    const webErr = validateWebsite(formValues.website);
    if (emailErr || webErr) {
      setFormErrors({ email: emailErr, website: webErr });
      return;
    }

    setIsSaving(true);
    try {
      const payload: Supplier = {
        id: editingSupplier?.id || `SUP-${Date.now()}`,
        ...formValues,
        contacts: editingSupplier?.contacts || [],
        documents: editingSupplier?.documents || [],
        score: editingSupplier?.score || { quality: 5, delivery: 5, price: 5, service: 5, total: 5 },
        badge: editingSupplier?.badge || 'BRONZE'
      };

      await FirestoreService.save('suppliers', payload.id, payload);
      
      // Auditoria
      await AuditService.log({
        userId: loggedUser?.id || 'sys',
        userName: loggedUser?.name || 'Sistema',
        action: editingSupplier ? 'UPDATE_SUPPLIER' : 'CREATE_SUPPLIER',
        module: 'SUPPLIES',
        details: `${editingSupplier ? 'Atualizado' : 'Homologado'} fornecedor: ${payload.tradeName} (${payload.cnpj})`,
        criticality: editingSupplier ? 'INFO' : 'WARN'
      });

      await loadSuppliers();
      setIsModalOpen(false);
      setEditingSupplier(null);
      toast.success('Fornecedor homologado na nuvem.');
    } catch (error) {
      console.error(error);
      toast.error("Falha ao salvar fornecedor.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h2 className="text-4xl font-black text-slate-800 dark:text-white tracking-tighter">Rede de <span className="gradient-text">Fornecedores</span></h2>
          <p className="text-slate-400 font-bold mt-1 uppercase text-xs tracking-widest flex items-center gap-2">
            Gestão de Parceiros & Due Diligence Cloud
          </p>
        </div>
        <Button onClick={() => { setEditingSupplier(null); setIsModalOpen(true); }} className="px-10 h-14 rounded-2xl bg-indigo-600 hover:bg-indigo-700">
          <Plus size={20} /> Novo Fornecedor
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-10">
        <div className="flex-1 relative group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="Buscar por Razão Social, Nome Fantasia ou CNPJ..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-14 pr-6 py-4 rounded-3xl border-none glass bg-white/40 dark:bg-slate-800/40 focus:ring-4 focus:ring-indigo-500/10 transition-all font-bold text-sm dark:text-white shadow-sm"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="py-20 text-center">
          <Loader2 size={48} className="animate-spin mx-auto text-indigo-500 opacity-20" />
          <p className="mt-4 text-slate-400 font-black uppercase text-[10px] tracking-widest">Sincronizando Rede...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSuppliers.map(sup => (
            <Card key={sup.id} className="group hover:border-indigo-500 transition-all relative overflow-hidden h-full flex flex-col">
              <div className="absolute top-4 right-4">
                <Badge color={sup.status === 'ATIVO' ? 'emerald' : 'rose'}>{sup.status}</Badge>
              </div>
              
              <div className="flex items-start gap-5 mb-6">
                <div className="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-3xl flex items-center justify-center text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500">
                  <Building2 size={32} />
                </div>
                <div className="flex-1 min-w-0 pr-12">
                  <h4 className="text-lg font-black dark:text-white truncate leading-none">{sup.tradeName}</h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase mt-2 tracking-widest truncate">{sup.companyName}</p>
                  <p className="text-xs text-indigo-500 font-bold mt-1">{sup.cnpj}</p>
                </div>
              </div>

              <div className="space-y-3 mb-8 flex-1">
                <div className="flex items-center gap-3 text-xs font-bold text-slate-500">
                  <Mail size={14} className="text-slate-400 shrink-0" />
                  <span className="truncate">{sup.email}</span>
                </div>
                <div className="flex items-center gap-3 text-xs font-bold text-slate-500">
                  <Phone size={14} className="text-slate-400 shrink-0" />
                  <span>{sup.phone}</span>
                </div>
                {sup.website && (
                  <div className="flex items-center gap-3 text-xs font-bold text-slate-500">
                    <Globe size={14} className="text-slate-400 shrink-0" />
                    <a href={sup.website.startsWith('http') ? sup.website : `https://${sup.website}`} target="_blank" rel="noopener noreferrer" className="truncate text-indigo-500 hover:underline">
                      {sup.website.replace(/^https?:\/\//, '')}
                    </a>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-6 border-t border-slate-50 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <Star size={16} className="text-amber-500 fill-amber-500" />
                  <span className="text-sm font-black dark:text-white">{sup.score?.total?.toFixed(1) || "5.0"}</span>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{sup.badge}</span>
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" className="p-2 glass rounded-xl" onClick={() => { setEditingSupplier(sup); setIsModalOpen(true); }}>
                    <Edit2 size={14} className="text-indigo-600" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
          {filteredSuppliers.length === 0 && !isLoading && (
            <div className="col-span-full py-20 text-center glass rounded-[40px]">
              <Truck size={48} className="mx-auto text-slate-200 mb-6" />
              <h4 className="text-xl font-black dark:text-white mb-2">Nenhum fornecedor cadastrado</h4>
              <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">Inicie o cadastro do primeiro parceiro</p>
            </div>
          )}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingSupplier ? 'Ajustar Dados do Parceiro' : 'Homologar Novo Fornecedor'} size="lg">
        <form onSubmit={handleSaveSupplier} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1 relative">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">CNPJ</label>
              <div className="flex gap-2">
                <input 
                  name="cnpj" 
                  value={formValues.cnpj}
                  onChange={(e) => setFormValues(p => ({...p, cnpj: e.target.value}))}
                  required 
                  placeholder="00.000.000/0000-00"
                  className="flex-1 p-4 rounded-2xl border-2 border-transparent bg-slate-100/50 dark:bg-slate-800/50 focus:border-indigo-500 focus:outline-none text-sm font-bold dark:text-white"
                  onBlur={(e) => handleConsultCnpj(e.target.value)}
                />
                <Button type="button" variant="outline" className="px-4 rounded-xl border-indigo-500/20" onClick={() => handleConsultCnpj(formValues.cnpj)} loading={isLoadingCnpj}>
                  <RefreshCcw size={16} />
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Status</label>
              <select 
                value={formValues.status}
                onChange={(e) => setFormValues(p => ({...p, status: e.target.value as any}))}
                className="w-full p-4 rounded-2xl glass border-none text-sm font-bold dark:text-white bg-white dark:bg-slate-800"
              >
                <option value="ATIVO">Homologado (Ativo)</option>
                <option value="BLOQUEADO">Bloqueado / Risco</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Razão Social" value={formValues.companyName} onChange={(e) => setFormValues(p => ({...p, companyName: e.target.value}))} required />
            <Input label="Nome Fantasia" value={formValues.tradeName} onChange={(e) => setFormValues(p => ({...p, tradeName: e.target.value}))} required />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="E-mail" value={formValues.email} error={formErrors.email} onChange={(e) => setFormValues(p => ({...p, email: e.target.value}))} required icon={<Mail size={16} />} />
            <Input label="Telefone" value={formValues.phone} onChange={(e) => setFormValues(p => ({...p, phone: e.target.value}))} required icon={<Phone size={16} />} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Website" value={formValues.website} error={formErrors.website} onChange={(e) => setFormValues(p => ({...p, website: e.target.value}))} icon={<Globe size={16} />} />
            <Input label="Endereço" value={formValues.address} onChange={(e) => setFormValues(p => ({...p, address: e.target.value}))} required icon={<MapPin size={16} />} />
          </div>

          <div className="flex justify-end gap-4 pt-6">
            <Button variant="outline" type="button" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
            <Button type="submit" loading={isSaving} className="px-12 bg-indigo-600 font-black uppercase">Protocolar Fornecedor</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};


import React, { useState, useEffect } from 'react';
import { Card, Button, Badge, Modal, Input, useToast, ConfirmDialog } from '../components/UI';
import { FileText, Clock, AlertCircle, Plus, Search, ShieldCheck, Loader2, Landmark, Calendar, Trash2, Edit2, Upload, Paperclip, AlertTriangle } from 'lucide-react';
import { FirestoreService } from '../services/FirestoreService';
import { Contract, ContractStatus, Grant, Funder } from '../types';
import { useAuth } from '../context/AuthContext';

export const Contracts: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'CONTRACTS' | 'GRANTS'>('CONTRACTS');
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [grants, setGrants] = useState<Grant[]>([]);
  const [funders, setFunders] = useState<Funder[]>([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isGrantModalOpen, setIsGrantModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ id: string, type: 'GRANT' | 'CONTRACT' } | null>(null);

  // Edit State
  const [editingContract, setEditingContract] = useState<Contract | null>(null);
  const [editingGrant, setEditingGrant] = useState<Grant | null>(null);
  const [tempDocs, setTempDocs] = useState<{name: string, url: string, date: string}[]>([]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [c, g, f] = await Promise.all([
          FirestoreService.getAll<Contract>('contracts'),
          FirestoreService.getAll<Grant>('grants'),
          FirestoreService.getAll<Funder>('funders')
      ]);
      setContracts(c);
      setGrants(g);
      setFunders(f);
    } catch (e) {
      toast.error('Erro ao carregar contratos e convênios.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveContract = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    const newContract: Contract = {
      id: editingContract?.id || `CTR-${Date.now()}`,
      title: f.get('title') as string,
      supplierId: f.get('supplier') as string,
      value: Number(f.get('value')),
      validity: f.get('validity') as string,
      status: f.get('status') as ContractStatus,
      documents: []
    };

    try {
      await FirestoreService.save('contracts', newContract.id, newContract);
      await loadData();
      setIsModalOpen(false);
      setEditingContract(null);
      toast.success(editingContract ? 'Contrato atualizado.' : 'Contrato formalizado e arquivado.');
    } catch (e) {
      toast.error('Erro ao salvar contrato.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveGrant = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      setIsSubmitting(true);
      const f = new FormData(e.currentTarget);
      const funderId = f.get('funderId') as string;
      const funderName = funders.find(fn => fn.id === funderId)?.name || 'Desconhecido';
      
      const newGrant: Grant = {
          id: editingGrant?.id || `GRT-${Date.now()}`,
          title: f.get('title') as string,
          grantNumber: f.get('grantNumber') as string,
          funderName: funderName,
          funderId: funderId,
          startDate: f.get('startDate') as string,
          endDate: f.get('endDate') as string,
          totalAmount: Number(f.get('totalAmount')),
          disbursementSchedule: editingGrant?.disbursementSchedule || [],
          status: f.get('status') as any,
          accountabilityDeadline: f.get('deadline') as string,
          documents: tempDocs
      };

      try {
          await FirestoreService.save('grants', newGrant.id, newGrant);
          await loadData();
          setIsGrantModalOpen(false);
          setEditingGrant(null);
          setTempDocs([]);
          toast.success(editingGrant ? 'Convênio atualizado.' : 'Convênio registrado.');
      } catch (e) {
          toast.error('Erro ao salvar convênio.');
      } finally {
          setIsSubmitting(false);
      }
  };

  const handleConfirmDelete = async () => {
    if (!itemToDelete) return;
    try {
        if (itemToDelete.type === 'GRANT') {
            await FirestoreService.delete('grants', itemToDelete.id);
            toast.success('Convênio removido.');
        } else {
            await FirestoreService.delete('contracts', itemToDelete.id);
            toast.success('Contrato removido.');
        }
        await loadData();
    } catch (e) {
        toast.error('Erro ao remover.');
    } finally {
        setIsDeleteDialogOpen(false);
        setItemToDelete(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        // Simulação de Upload (Base64/Url)
        const reader = new FileReader();
        reader.onload = () => {
            const newDoc = {
                name: file.name,
                url: reader.result as string, // Mock URL
                date: new Date().toISOString()
            };
            setTempDocs(prev => [...prev, newDoc]);
            toast.success('Documento anexado.');
        };
        reader.readAsDataURL(file);
    }
  };

  const checkExpiration = (dateStr: string) => {
      const today = new Date().getTime();
      const end = new Date(dateStr).getTime();
      const days = Math.ceil((end - today) / (1000 * 60 * 60 * 24));
      return { days, isExpired: days < 0, isWarning: days > 0 && days <= 45 };
  };

  const openGrantModal = (grant?: Grant) => {
      setEditingGrant(grant || null);
      setTempDocs(grant?.documents || []);
      setIsGrantModalOpen(true);
  };

  if (isLoading) return <div className="flex justify-center p-20"><Loader2 className="animate-spin text-cyan-500" /></div>;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-700">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black tracking-tighter dark:text-white">Instrumentos Jurídicos</h2>
          <p className="text-cyan-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Contratos e Convênios</p>
        </div>
      </div>

      <nav className="flex p-1 glass rounded-[40px] w-fit overflow-x-auto no-scrollbar shadow-xl border-white/20">
        {[
          { id: 'CONTRACTS', label: 'Contratos (Fornecedores)', icon: <FileText size={18}/> },
          { id: 'GRANTS', label: 'Convênios (Receita)', icon: <Landmark size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-cyan-600 text-white shadow-xl shadow-cyan-500/20' : 'text-slate-500 hover:text-cyan-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      {activeTab === 'CONTRACTS' && (
          <div className="space-y-6">
              <div className="flex justify-end">
                  <Button onClick={() => { setEditingContract(null); setIsModalOpen(true); }} className="px-8 bg-cyan-500 hover:bg-cyan-600 shadow-cyan-500/20 rounded-2xl h-12 font-black uppercase"><Plus size={18} /> Novo Contrato</Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {contracts.map(c => (
                  <Card key={c.id} className="hover:border-cyan-500 transition-all border-l-8 border-l-cyan-500 group">
                    <div className="flex justify-between items-start mb-6">
                       <div className="flex items-center gap-4">
                           <div className="w-12 h-12 bg-cyan-50 dark:bg-cyan-500/10 rounded-2xl flex items-center justify-center text-cyan-500"><FileText size={24}/></div>
                           <Badge color={c.status === 'Vigente' ? 'emerald' : 'amber'}>{c.status}</Badge>
                       </div>
                       <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => { setEditingContract(c); setIsModalOpen(true); }} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg"><Edit2 size={16}/></button>
                          <button onClick={() => { setItemToDelete({id: c.id, type: 'CONTRACT'}); setIsDeleteDialogOpen(true); }} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"><Trash2 size={16}/></button>
                       </div>
                    </div>
                    <h4 className="text-xl font-black dark:text-white leading-tight mb-2">{c.title}</h4>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">{c.supplierId}</p>
                    <div className="mt-8 flex justify-between items-center">
                       <p className="text-sm font-bold text-slate-400 flex items-center gap-2"><Clock size={14}/> Vencimento: {new Date(c.validity).toLocaleDateString()}</p>
                       <p className="text-lg font-black text-cyan-600">R$ {c.value.toLocaleString()}</p>
                    </div>
                  </Card>
                ))}
                {contracts.length === 0 && <p className="col-span-full text-center text-slate-400 py-10">Nenhum contrato registrado.</p>}
              </div>
          </div>
      )}

      {activeTab === 'GRANTS' && (
          <div className="space-y-6">
              <div className="flex justify-end">
                  <Button onClick={() => openGrantModal()} className="px-8 bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20 rounded-2xl h-12 font-black uppercase"><Plus size={18} /> Novo Convênio</Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {grants.map(g => {
                      const exp = checkExpiration(g.endDate);
                      return (
                      <Card key={g.id} className={`hover:border-indigo-500 transition-all border-l-8 ${exp.isExpired ? 'border-l-rose-500' : exp.isWarning ? 'border-l-amber-500' : 'border-l-indigo-600'} group`}>
                          <div className="flex justify-between items-start mb-6">
                              <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl flex items-center justify-center text-indigo-600"><Landmark size={24}/></div>
                                  <div>
                                      <Badge color={g.status === 'VIGENTE' ? 'emerald' : g.status === 'EXPIRADO' ? 'rose' : 'slate'}>{g.status}</Badge>
                                      {exp.isWarning && <span className="ml-2 text-[10px] font-black text-amber-500 uppercase flex items-center gap-1"><AlertTriangle size={10}/> Vence em {exp.days} dias</span>}
                                      {exp.isExpired && <span className="ml-2 text-[10px] font-black text-rose-500 uppercase flex items-center gap-1"><AlertCircle size={10}/> Vencido</span>}
                                  </div>
                              </div>
                              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                  <button onClick={() => openGrantModal(g)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg"><Edit2 size={16}/></button>
                                  <button onClick={() => { setItemToDelete({id: g.id, type: 'GRANT'}); setIsDeleteDialogOpen(true); }} className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg"><Trash2 size={16}/></button>
                              </div>
                          </div>
                          <h4 className="text-xl font-black dark:text-white leading-tight mb-1">{g.title}</h4>
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{g.grantNumber} • {g.funderName}</p>
                          
                          <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-4">
                              <div>
                                  <p className="text-[9px] font-black text-slate-400 uppercase">Valor Total</p>
                                  <p className="text-lg font-black text-indigo-600">R$ {g.totalAmount.toLocaleString()}</p>
                              </div>
                              <div>
                                  <p className="text-[9px] font-black text-slate-400 uppercase">Vigência</p>
                                  <p className={`text-sm font-bold flex items-center gap-1 ${exp.isExpired ? 'text-rose-500' : 'text-slate-600 dark:text-slate-300'}`}>
                                      <Calendar size={12}/> {new Date(g.endDate).toLocaleDateString()}
                                  </p>
                              </div>
                          </div>
                          {g.documents && g.documents.length > 0 && (
                              <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
                                  {g.documents.map((doc, i) => (
                                      <div key={i} className="flex items-center gap-1 px-3 py-1.5 bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
                                          <Paperclip size={10} className="text-slate-400"/>
                                          <span className="text-[9px] font-bold text-slate-600 dark:text-slate-400 truncate max-w-[100px]">{doc.name}</span>
                                      </div>
                                  ))}
                              </div>
                          )}
                      </Card>
                  )})}
                  {grants.length === 0 && (
                      <div className="col-span-full py-20 text-center glass rounded-[40px]">
                          <Landmark size={48} className="mx-auto text-slate-300 mb-6"/>
                          <p className="text-slate-400 font-bold uppercase">Nenhum convênio registrado</p>
                      </div>
                  )}
              </div>
          </div>
      )}

      {/* Modal Contrato (CRUD) */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingContract ? "Editar Contrato" : "Novo Contrato (Fornecedor)"}>
        <form onSubmit={handleSaveContract} className="space-y-6">
           <Input label="Objeto do Contrato" name="title" defaultValue={editingContract?.title} required placeholder="Ex: Fornecimento de Internet Fibra" />
           <Input label="Parte Contratada (Fornecedor)" name="supplier" defaultValue={editingContract?.supplierId} required placeholder="Ex: Vivo Empresas" />
           <div className="grid grid-cols-2 gap-4">
              <Input label="Valor Global (R$)" name="value" type="number" defaultValue={editingContract?.value} required />
              <Input label="Data de Vencimento" name="validity" type="date" defaultValue={editingContract?.validity} required />
           </div>
           <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase">Status</label>
              <select name="status" defaultValue={editingContract?.status || 'Vigente'} className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                  <option value="Vigente">Vigente</option>
                  <option value="Expirado">Expirado</option>
                  <option value="Cancelado">Cancelado</option>
              </select>
           </div>
           <div className="p-4 bg-cyan-50 dark:bg-cyan-900/10 rounded-2xl border border-cyan-100 dark:border-cyan-900/30 flex gap-4">
              <ShieldCheck className="text-cyan-600" />
              <p className="text-xs text-cyan-800 dark:text-cyan-300">Este contrato será submetido automaticamente à análise de compliance para verificação de cláusulas LGPD.</p>
           </div>
           <div className="flex justify-end gap-4 pt-4">
              <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
              <Button type="submit" loading={isSubmitting} className="bg-cyan-600 hover:bg-cyan-700">{editingContract ? 'Salvar Alterações' : 'Formalizar'}</Button>
           </div>
        </form>
      </Modal>

      {/* Modal Convênio (CRUD) */}
      <Modal isOpen={isGrantModalOpen} onClose={() => setIsGrantModalOpen(false)} title={editingGrant ? "Editar Convênio" : "Novo Convênio / Grant"} size="lg">
          <form onSubmit={handleSaveGrant} className="space-y-6">
              <Input label="Título do Projeto/Convênio" name="title" defaultValue={editingGrant?.title} required />
              <div className="grid grid-cols-2 gap-6">
                  <Input label="Número do Processo" name="grantNumber" defaultValue={editingGrant?.grantNumber} required />
                  <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Financiador Vinculado</label>
                      <select name="funderId" defaultValue={editingGrant?.funderId} className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner" required>
                          <option value="">Selecione...</option>
                          {funders.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                      </select>
                  </div>
              </div>
              <div className="grid grid-cols-3 gap-6">
                  <Input label="Início Vigência" name="startDate" type="date" defaultValue={editingGrant?.startDate} required />
                  <Input label="Fim Vigência" name="endDate" type="date" defaultValue={editingGrant?.endDate} required />
                  <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Status</label>
                      <select name="status" defaultValue={editingGrant?.status || 'VIGENTE'} className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                          <option value="VIGENTE">Vigente</option>
                          <option value="EXPIRADO">Expirado</option>
                          <option value="CANCELADO">Cancelado</option>
                      </select>
                  </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                  <Input label="Prazo Prest. Contas" name="deadline" type="date" defaultValue={editingGrant?.accountabilityDeadline} required />
                  <Input label="Valor Aprovado (R$)" name="totalAmount" type="number" defaultValue={editingGrant?.totalAmount} required />
              </div>

              {/* Documentos */}
              <div className="p-6 rounded-3xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                  <div className="flex justify-between items-center mb-4">
                      <h4 className="text-xs font-black uppercase text-indigo-600 tracking-widest">Documentação Anexa</h4>
                      <label className="cursor-pointer bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-indigo-500 text-slate-500 hover:text-indigo-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center gap-2 transition-all">
                          <Upload size={14}/> Upload
                          <input type="file" className="hidden" onChange={handleFileUpload} />
                      </label>
                  </div>
                  <div className="space-y-2">
                      {tempDocs.map((doc, idx) => (
                          <div key={idx} className="flex justify-between items-center p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                              <div className="flex items-center gap-3">
                                  <Paperclip size={14} className="text-indigo-500"/>
                                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">{doc.name}</span>
                              </div>
                              <button type="button" onClick={() => setTempDocs(prev => prev.filter((_, i) => i !== idx))} className="text-rose-500 hover:bg-rose-50 p-1.5 rounded-lg">
                                  <Trash2 size={14}/>
                              </button>
                          </div>
                      ))}
                      {tempDocs.length === 0 && <p className="text-center text-[10px] text-slate-400 font-bold uppercase py-2">Nenhum documento anexado.</p>}
                  </div>
              </div>
              
              <div className="flex justify-end gap-4 pt-6">
                  <Button type="button" variant="outline" onClick={() => setIsGrantModalOpen(false)}>Cancelar</Button>
                  <Button type="submit" loading={isSubmitting} className="bg-indigo-600 hover:bg-indigo-700 font-black uppercase">{editingGrant ? 'Atualizar Convênio' : 'Registrar Convênio'}</Button>
              </div>
          </form>
      </Modal>

      <ConfirmDialog 
        isOpen={isDeleteDialogOpen} 
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleConfirmDelete}
        title="Confirmar Exclusão"
        message={`Tem certeza que deseja remover este ${itemToDelete?.type === 'GRANT' ? 'convênio' : 'contrato'}? Esta ação não pode ser desfeita.`}
      />
    </div>
  );
};


import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Badge, useToast, Modal, ConfirmDialog } from '../components/UI';
import { 
  DollarSign, TrendingUp, TrendingDown, PieChart, 
  ArrowUpRight, Plus, Download, Filter, Search, History,
  Layers, Target, Users as UsersIcon, Edit2, Trash2,
  Calendar, CheckCircle, XCircle, AlertCircle, FileText,
  CreditCard, Banknote, RefreshCcw, Loader2, ArrowRight,
  Landmark, BookOpen, Scale, Wallet, Lock, Split, Upload, Link, FileCheck
} from 'lucide-react';
import { FirestoreService } from '../services/FirestoreService';
import { AuditService } from '../services/AuditService';
import { FinanceTransaction, CostCenter, Project, BankAccount, ChartOfAccount, TransactionSplit, Budget } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area, Legend, LineChart, Line, ComposedChart
} from 'recharts';
import { useAuth } from '../context/AuthContext';

export const Finance: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'DASH' | 'OPERATIONS' | 'TREASURY' | 'BUDGET' | 'ACCOUNTING' | 'DRE'>('DASH');
  const [transactions, setTransactions] = useState<FinanceTransaction[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [chartOfAccounts, setChartOfAccounts] = useState<ChartOfAccount[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  
  // Modals & Forms
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isBankModalOpen, setIsBankModalOpen] = useState(false);
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);
  const [isReconcileModalOpen, setIsReconcileModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<FinanceTransaction | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Form States for Advanced Transaction
  const [useRateio, setUseRateio] = useState(false);
  const [splits, setSplits] = useState<TransactionSplit[]>([]);
  const [retentions, setRetentions] = useState({ iss: 0, inss: 0, irrf: 0, pisCofinsCsll: 0 });
  const [baseAmount, setBaseAmount] = useState(0);

  // Load Data
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [trans, ccs, projs, banks, charts] = await Promise.all([
        FirestoreService.getAll<FinanceTransaction>('finance_transactions'),
        FirestoreService.getAll<CostCenter>('cost_centers'),
        FirestoreService.getAll<Project>('projects'),
        FirestoreService.getAll<BankAccount>('bank_accounts'),
        FirestoreService.getAll<ChartOfAccount>('chart_of_accounts')
      ]);
      setTransactions(trans.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setCostCenters(ccs);
      setProjects(projs);
      setBankAccounts(banks);
      setChartOfAccounts(charts.sort((a,b) => a.code.localeCompare(b.code)));
      
      // Mock Budgets if empty (Simulating Enterprise Feature)
      if (budgets.length === 0) {
          setBudgets(ccs.map(cc => ({
              id: `bud-${cc.id}`,
              year: 2024,
              costCenterId: cc.id,
              totalAmount: cc.budget || 100000,
              monthlyDistribution: Array(12).fill((cc.budget || 100000) / 12),
              revision: 1,
              status: 'APPROVED'
          })));
      }
    } catch (e) {
      toast.error('Erro ao carregar ecossistema financeiro.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // --- ANALYTICS ENTERPRISE ---
  const stats = useMemo(() => {
    const paidIn = transactions.filter(t => t.type === 'IN' && t.status === 'PAID').reduce((acc, t) => acc + t.amount, 0);
    const paidOut = transactions.filter(t => t.type === 'OUT' && t.status === 'PAID').reduce((acc, t) => acc + t.amount, 0);
    const balance = paidIn - paidOut;
    
    // Projeções
    const pendingPayable = transactions
      .filter(t => t.type === 'OUT' && (t.status === 'PENDING_APPROVAL' || t.status === 'SCHEDULED'))
      .reduce((acc, t) => acc + t.amount, 0);
      
    const pendingReceivable = transactions
      .filter(t => t.type === 'IN' && t.status === 'SCHEDULED')
      .reduce((acc, t) => acc + t.amount, 0);

    return { balance, paidIn, paidOut, pendingPayable, pendingReceivable };
  }, [transactions]);

  // --- DRE CALCULATION (Competência) ---
  const dreData = useMemo(() => {
    const revenue = transactions
      .filter(t => t.type === 'IN' && chartOfAccounts.find(c => c.id === t.chartOfAccountId)?.type === 'REVENUE')
      .reduce((acc, t) => acc + t.amount, 0);

    const directCosts = transactions
      .filter(t => t.type === 'OUT' && chartOfAccounts.find(c => c.id === t.chartOfAccountId)?.category === 'OPERATIONAL')
      .reduce((acc, t) => acc + t.amount, 0);

    const grossMargin = revenue - directCosts;

    const expenses = transactions
      .filter(t => t.type === 'OUT' && chartOfAccounts.find(c => c.id === t.chartOfAccountId)?.category !== 'OPERATIONAL')
      .reduce((acc, t) => acc + t.amount, 0);

    const ebitda = grossMargin - expenses;

    return { revenue, directCosts, grossMargin, expenses, ebitda };
  }, [transactions, chartOfAccounts]);

  // --- ACTIONS ---

  const handleAddSplit = () => {
      setSplits([...splits, { costCenterId: costCenters[0]?.id || '', amount: 0, percentage: 0 }]);
  };

  const updateSplit = (index: number, field: keyof TransactionSplit, value: any) => {
      const newSplits = [...splits];
      newSplits[index] = { ...newSplits[index], [field]: value };
      
      // Auto-calc amount or percentage
      if (field === 'amount') {
          newSplits[index].percentage = (Number(value) / baseAmount) * 100;
      } else if (field === 'percentage') {
          newSplits[index].amount = (baseAmount * Number(value)) / 100;
      }
      setSplits(newSplits);
  };

  const handleSaveTransaction = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    const amount = Number(f.get('amount'));
    
    // Validation for Splits
    if (useRateio) {
        const splitTotal = splits.reduce((acc, s) => acc + s.amount, 0);
        if (Math.abs(splitTotal - amount) > 0.01) {
            toast.error(`A soma do rateio (R$ ${splitTotal}) deve ser igual ao valor total (R$ ${amount}).`);
            setIsSubmitting(false);
            return;
        }
    }

    // Regra de Aprovação Enterprise
    let initialStatus = f.get('status') as any;
    if (amount > 5000 && initialStatus !== 'PAID') {
        initialStatus = 'PENDING_APPROVAL';
    }

    // Calcular Valor Líquido (Net Amount)
    const totalRetentions = retentions.iss + retentions.inss + retentions.irrf + retentions.pisCofinsCsll;
    const netAmount = amount - totalRetentions;

    const t: FinanceTransaction = {
      id: editingTransaction?.id || `FIN-${Date.now()}`,
      description: f.get('desc') as string,
      amount: amount,
      netAmount: netAmount,
      type: f.get('type') as any,
      date: f.get('date') as string, // Competência
      dueDate: f.get('dueDate') as string,
      paymentDate: initialStatus === 'PAID' ? new Date().toISOString().split('T')[0] : undefined,
      status: initialStatus,
      category: 'Geral', // Legacy field fallback
      chartOfAccountId: f.get('chartOfAccountId') as string,
      bankAccountId: f.get('bankAccountId') as string,
      costCenterId: !useRateio ? f.get('costCenterId') as string : undefined,
      projectId: !useRateio ? f.get('projectId') as string : undefined,
      splits: useRateio ? splits : undefined,
      retentions: retentions,
      docNumber: f.get('docNumber') as string,
      reconciled: false
    };

    try {
      await FirestoreService.save('finance_transactions', t.id, t);
      
      // Update Bank Balance if Paid
      if (t.status === 'PAID' && t.bankAccountId) {
         const bank = bankAccounts.find(b => b.id === t.bankAccountId);
         if (bank) {
             const newBalance = t.type === 'IN' ? bank.currentBalance + t.netAmount! : bank.currentBalance - t.netAmount!;
             await FirestoreService.save('bank_accounts', bank.id, { currentBalance: newBalance });
         }
      }
      
      await loadData();
      setIsFormOpen(false);
      toast.success(initialStatus === 'PENDING_APPROVAL' ? 'Lançamento enviado para aprovação.' : 'Transação registrada.');
    } catch (e) {
      toast.error('Erro ao processar transação.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveBank = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const bank: BankAccount = {
          id: `BANK-${Date.now()}`,
          name: f.get('name') as string,
          bankCode: f.get('bankCode') as string,
          agency: f.get('agency') as string,
          accountNumber: f.get('account') as string,
          initialBalance: Number(f.get('balance')),
          currentBalance: Number(f.get('balance')),
          currency: 'BRL',
          status: 'ACTIVE'
      };
      await FirestoreService.save('bank_accounts', bank.id, bank);
      loadData();
      setIsBankModalOpen(false);
      toast.success('Conta bancária adicionada.');
  };

  const handleSaveChart = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const f = new FormData(e.currentTarget);
      const chart: ChartOfAccount = {
          id: `CHART-${Date.now()}`,
          code: f.get('code') as string,
          name: f.get('name') as string,
          type: f.get('type') as any,
          category: f.get('category') as any,
          level: 1 // Simplified for MVP
      };
      await FirestoreService.save('chart_of_accounts', chart.id, chart);
      loadData();
      setIsChartModalOpen(false);
      toast.success('Conta contábil criada.');
  };

  // --- SUB-COMPONENTS ---

  const TreasuryView = () => (
      <div className="space-y-8 animate-in fade-in">
          <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">Tesouraria e Saldos</h3>
              <div className="flex gap-2">
                  <Button onClick={() => setIsReconcileModalOpen(true)} className="bg-indigo-600 gap-2"><RefreshCcw size={18}/> Conciliação OFX</Button>
                  <Button onClick={() => setIsBankModalOpen(true)} className="bg-emerald-600 gap-2"><Landmark size={18}/> Nova Conta</Button>
              </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bankAccounts.map(bank => (
                  <Card key={bank.id} className="glass border-l-4 border-l-emerald-500 hover:scale-105 transition-all">
                      <div className="flex justify-between items-start mb-4">
                          <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl">
                              <Landmark className="text-emerald-600" size={24} />
                          </div>
                          <Badge color="emerald">{bank.status}</Badge>
                      </div>
                      <h4 className="text-lg font-black dark:text-white">{bank.name}</h4>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">AG: {bank.agency} • CC: {bank.accountNumber}</p>
                      <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800">
                          <p className="text-[10px] font-black text-slate-400 uppercase">Saldo Disponível</p>
                          <p className="text-2xl font-black text-emerald-600">R$ {bank.currentBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                      </div>
                  </Card>
              ))}
          </div>
      </div>
  );

  const BudgetView = () => (
      <div className="space-y-8 animate-in fade-in">
          <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">Orçamento Corporativo (Real vs Orçado)</h3>
              <Button variant="outline" className="gap-2"><FileText size={18}/> Relatório Executivo</Button>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
              {budgets.map(b => {
                  const ccName = costCenters.find(c => c.id === b.costCenterId)?.name;
                  const spent = transactions
                      .filter(t => t.type === 'OUT' && (t.costCenterId === b.costCenterId || t.splits?.some(s => s.costCenterId === b.costCenterId)))
                      .reduce((acc, t) => {
                          if (t.splits) {
                              const split = t.splits.find(s => s.costCenterId === b.costCenterId);
                              return acc + (split?.amount || 0);
                          }
                          return acc + t.amount;
                      }, 0);
                  
                  const pct = Math.min((spent / b.totalAmount) * 100, 100);
                  const isOver = spent > b.totalAmount;

                  return (
                      <div key={b.id} className="p-6 glass rounded-2xl border border-slate-100 dark:border-slate-800">
                          <div className="flex justify-between items-end mb-4">
                              <div>
                                  <h4 className="font-black text-lg dark:text-white">{ccName}</h4>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Exercício {b.year} • Revisão {b.revision}</p>
                              </div>
                              <div className="text-right">
                                  <span className={`text-xl font-black ${isOver ? 'text-rose-500' : 'text-emerald-500'}`}>{pct.toFixed(1)}%</span>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase">Executado</p>
                              </div>
                          </div>
                          <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                              <div className={`h-full ${isOver ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${pct}%` }}></div>
                          </div>
                          <div className="flex justify-between mt-3 text-xs font-bold text-slate-500">
                              <span>Realizado: R$ {spent.toLocaleString()}</span>
                              <span>Budget: R$ {b.totalAmount.toLocaleString()}</span>
                          </div>
                      </div>
                  );
              })}
          </div>
      </div>
  );

  const DREView = () => (
      <div className="space-y-8 animate-in fade-in">
          <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">DRE Gerencial (Regime de Competência)</h3>
              <Button variant="outline" className="gap-2"><Download size={18}/> Exportar DRE</Button>
          </div>
          <Card className="glass max-w-4xl mx-auto border-none shadow-2xl">
              <div className="space-y-4">
                  {/* Revenue */}
                  <div className="flex justify-between items-center p-4 bg-emerald-50 dark:bg-emerald-900/10 rounded-xl">
                      <span className="font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">(=) Receita Bruta</span>
                      <span className="font-black text-xl text-emerald-700 dark:text-emerald-400">R$ {dreData.revenue.toLocaleString()}</span>
                  </div>
                  
                  {/* Costs */}
                  <div className="flex justify-between items-center px-4 py-2 border-b border-dashed border-slate-200">
                      <span className="text-sm font-bold text-slate-500">(-) Custos Diretos / Projetos</span>
                      <span className="text-sm font-bold text-rose-500">- R$ {dreData.directCosts.toLocaleString()}</span>
                  </div>

                  {/* Gross Margin */}
                  <div className="flex justify-between items-center p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-xl">
                      <span className="font-black text-indigo-700 dark:text-indigo-400 uppercase tracking-widest">(=) Margem de Contribuição</span>
                      <span className="font-black text-xl text-indigo-700 dark:text-indigo-400">R$ {dreData.grossMargin.toLocaleString()}</span>
                  </div>

                  {/* Expenses */}
                  <div className="flex justify-between items-center px-4 py-2 border-b border-dashed border-slate-200">
                      <span className="text-sm font-bold text-slate-500">(-) Despesas Operacionais (OPEX)</span>
                      <span className="text-sm font-bold text-rose-500">- R$ {dreData.expenses.toLocaleString()}</span>
                  </div>

                  {/* EBITDA */}
                  <div className="flex justify-between items-center p-6 bg-slate-800 text-white rounded-2xl shadow-xl mt-6">
                      <div className="flex items-center gap-3">
                          <TrendingUp size={24} className="text-emerald-400" />
                          <span className="font-black text-lg uppercase tracking-widest">EBITDA (Resultado Operacional)</span>
                      </div>
                      <span className={`font-black text-3xl ${dreData.ebitda >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                          R$ {dreData.ebitda.toLocaleString()}
                      </span>
                  </div>
              </div>
          </Card>
      </div>
  );

  const AccountingView = () => (
      <div className="space-y-8 animate-in fade-in">
          <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">Plano de Contas Gerencial</h3>
              <Button onClick={() => setIsChartModalOpen(true)} className="bg-indigo-600 gap-2"><BookOpen size={18}/> Nova Conta Contábil</Button>
          </div>
          <Card className="glass p-0 overflow-hidden">
              <table className="w-full text-left">
                  <thead className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <tr>
                          <th className="p-4 pl-6">Código</th>
                          <th className="p-4">Descrição da Conta</th>
                          <th className="p-4">Tipo (DRE)</th>
                          <th className="p-4">Categoria</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {chartOfAccounts.map(chart => (
                          <tr key={chart.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                              <td className="p-4 pl-6 text-xs font-black text-slate-500">{chart.code}</td>
                              <td className="p-4 text-sm font-bold dark:text-white">{chart.name}</td>
                              <td className="p-4"><Badge color={chart.type === 'REVENUE' ? 'emerald' : chart.type === 'EXPENSE' ? 'rose' : 'slate'}>{chart.type}</Badge></td>
                              <td className="p-4 text-xs text-slate-500 uppercase">{chart.category}</td>
                          </tr>
                      ))}
                  </tbody>
              </table>
          </Card>
      </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Diretoria <span className="text-emerald-600">Financeira</span></h2>
          <p className="text-emerald-500 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">ERP Enterprise v5.2</p>
        </div>
        <div className="flex gap-4">
           <Button onClick={() => { setEditingTransaction(null); setIsFormOpen(true); setUseRateio(false); setSplits([]); }} className="px-8 h-14 rounded-3xl bg-emerald-600 hover:bg-emerald-700 shadow-xl shadow-emerald-500/20 font-black uppercase text-sm"><Plus size={18} className="mr-2"/> Novo Lançamento</Button>
        </div>
      </header>

      <nav className="flex p-1 glass rounded-[40px] w-full overflow-x-auto no-scrollbar shadow-2xl border-white/10 bg-white/20 dark:bg-black/20">
        {[
          { id: 'DASH', label: 'Visão Executiva', icon: <PieChart size={18}/> },
          { id: 'OPERATIONS', label: 'Operacional', icon: <ArrowUpRight size={18}/> },
          { id: 'TREASURY', label: 'Tesouraria', icon: <Landmark size={18}/> },
          { id: 'BUDGET', label: 'Orçamentos', icon: <Target size={18}/> },
          { id: 'ACCOUNTING', label: 'Plano Contas', icon: <BookOpen size={18}/> },
          { id: 'DRE', label: 'DRE Gerencial', icon: <Scale size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-500/20' : 'text-slate-500 dark:text-slate-400 hover:text-emerald-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <main>
        {activeTab === 'DASH' && (
           <div className="space-y-10 animate-in slide-in-from-bottom-5">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                 <Card className="glass border-l-4 border-l-emerald-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Saldo Global (Tesouraria)</p>
                    <h3 className={`text-4xl font-black ${stats.balance >= 0 ? 'text-emerald-500' : 'text-rose-500'} mt-1`}>R$ {stats.balance.toLocaleString()}</h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-indigo-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">EBITDA (Acumulado)</p>
                    <h3 className="text-3xl font-black text-indigo-600 mt-1">R$ {dreData.ebitda.toLocaleString()}</h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-amber-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Contas a Pagar (Aberto)</p>
                    <h3 className="text-3xl font-black text-amber-500 mt-1">R$ {stats.pendingPayable.toLocaleString()}</h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-slate-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Burn Rate Mensal</p>
                    <h3 className="text-3xl font-black text-slate-600 dark:text-white mt-1">R$ {dreData.expenses.toLocaleString()}</h3>
                 </Card>
              </div>
           </div>
        )}

        {activeTab === 'OPERATIONS' && (
            <Card title="Movimentações Financeiras" className="border-none shadow-none p-0 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                        <tr>
                            <th className="p-6">Vencimento</th>
                            <th className="p-6">Descrição</th>
                            <th className="p-6">Classificação</th>
                            <th className="p-6 text-right">Valor Bruto</th>
                            <th className="p-6 text-right">Valor Líq.</th>
                            <th className="p-6 text-center">Status</th>
                            <th className="p-6 text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {transactions.map(t => (
                            <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                <td className="p-6 text-xs font-bold text-slate-600">
                                    {new Date(t.dueDate || t.date).toLocaleDateString()}
                                </td>
                                <td className="p-6">
                                    <p className="text-sm font-black dark:text-white">{t.description}</p>
                                    <p className="text-[9px] text-slate-400 uppercase">{t.docNumber || 'S/ DOC'}</p>
                                </td>
                                <td className="p-6">
                                    <div className="flex flex-col gap-1">
                                        <Badge color="slate">{chartOfAccounts.find(c => c.id === t.chartOfAccountId)?.name || 'N/C'}</Badge>
                                        {t.splits ? (
                                            <span className="text-[9px] font-bold text-indigo-500 flex items-center gap-1"><Split size={10}/> Rateio Múltiplo</span>
                                        ) : (
                                            <span className="text-[9px] font-bold text-slate-400">{costCenters.find(c => c.id === t.costCenterId)?.name}</span>
                                        )}
                                    </div>
                                </td>
                                <td className={`p-6 text-right font-black ${t.type === 'IN' ? 'text-emerald-500' : 'text-rose-500'}`}>
                                    {t.type === 'IN' ? '+' : '-'} R$ {t.amount.toLocaleString()}
                                </td>
                                <td className="p-6 text-right font-bold text-slate-500">
                                    R$ {(t.netAmount || t.amount).toLocaleString()}
                                </td>
                                <td className="p-6 text-center">
                                    <Badge color={t.status === 'PAID' ? 'emerald' : t.status === 'PENDING_APPROVAL' ? 'amber' : 'slate'}>{t.status}</Badge>
                                </td>
                                <td className="p-6 text-right">
                                    {t.status === 'PENDING_APPROVAL' && (
                                        <Button className="h-8 text-[10px] bg-indigo-600 hover:bg-indigo-700 uppercase font-black px-4 rounded-xl"><Lock size={12} className="mr-1"/> Aprovar</Button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Card>
        )}

        {activeTab === 'TREASURY' && <TreasuryView />}
        {activeTab === 'BUDGET' && <BudgetView />}
        {activeTab === 'ACCOUNTING' && <AccountingView />}
        {activeTab === 'DRE' && <DREView />}
      </main>

      {/* Modal Lançamento Avançado com Rateio e Impostos */}
      <Modal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} title="Lançamento Enterprise" size="2xl">
         <form onSubmit={handleSaveTransaction} className="space-y-6">
            {/* Header: Tipo e Valor */}
            <div className="grid grid-cols-2 gap-6 p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800">
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Natureza</label>
                  <select name="type" className="w-full p-4 rounded-2xl border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-sm">
                     <option value="OUT">Despesa (Saída)</option>
                     <option value="IN">Receita (Entrada)</option>
                  </select>
               </div>
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Valor Bruto (R$)</label>
                  <Input name="amount" type="number" step="0.01" required value={baseAmount} onChange={e => setBaseAmount(Number(e.target.value))} className="bg-white" />
               </div>
            </div>
            
            <Input label="Histórico / Descrição" name="desc" required placeholder="Descrição detalhada do lançamento" />
            
            <div className="grid grid-cols-2 gap-6">
               <Input label="Competência" name="date" type="date" required />
               <Input label="Vencimento" name="dueDate" type="date" required />
            </div>

            <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Classificação Contábil</label>
                    <select name="chartOfAccountId" required className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                        <option value="">Selecione a Conta...</option>
                        {chartOfAccounts.map(c => <option key={c.id} value={c.id}>{c.code} - {c.name}</option>)}
                    </select>
                </div>
                <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Conta Bancária / Caixa</label>
                    <select name="bankAccountId" className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                        <option value="">A Pagar / Receber (Sem banco)</option>
                        {bankAccounts.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                </div>
            </div>

            {/* Impostos e Retenções */}
            <div className="p-6 rounded-3xl border border-slate-100 dark:border-slate-800 space-y-4">
                <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest flex items-center gap-2"><Wallet size={14}/> Retenções Tributárias (Fonte)</h4>
                <div className="grid grid-cols-4 gap-4">
                    <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400">ISS</label>
                        <input type="number" className="w-full p-2 rounded-xl border bg-slate-50 text-xs" placeholder="0.00" onChange={e => setRetentions({...retentions, iss: Number(e.target.value)})} />
                    </div>
                    <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400">INSS</label>
                        <input type="number" className="w-full p-2 rounded-xl border bg-slate-50 text-xs" placeholder="0.00" onChange={e => setRetentions({...retentions, inss: Number(e.target.value)})} />
                    </div>
                    <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400">IRRF</label>
                        <input type="number" className="w-full p-2 rounded-xl border bg-slate-50 text-xs" placeholder="0.00" onChange={e => setRetentions({...retentions, irrf: Number(e.target.value)})} />
                    </div>
                    <div className="space-y-1">
                        <label className="text-[9px] font-bold text-slate-400">PIS/COF/CSLL</label>
                        <input type="number" className="w-full p-2 rounded-xl border bg-slate-50 text-xs" placeholder="0.00" onChange={e => setRetentions({...retentions, pisCofinsCsll: Number(e.target.value)})} />
                    </div>
                </div>
            </div>

            {/* Rateio Switch */}
            <div className="flex items-center justify-between p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl">
                <span className="text-sm font-black text-indigo-700 dark:text-indigo-400 uppercase tracking-widest flex items-center gap-2"><Split size={16}/> Habilitar Rateio de Custos</span>
                <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" checked={useRateio} onChange={e => setUseRateio(e.target.checked)} className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
            </div>

            {useRateio ? (
                <div className="space-y-3 p-4 border-2 border-indigo-100 rounded-2xl bg-indigo-50/30">
                    {splits.map((split, idx) => (
                        <div key={idx} className="flex gap-2 items-center">
                            <select 
                                value={split.costCenterId}
                                onChange={e => updateSplit(idx, 'costCenterId', e.target.value)}
                                className="flex-1 p-2 rounded-xl border-none text-xs font-bold"
                            >
                                {costCenters.map(cc => <option key={cc.id} value={cc.id}>{cc.name}</option>)}
                            </select>
                            <input 
                                type="number" 
                                placeholder="%" 
                                className="w-16 p-2 rounded-xl text-xs font-bold text-center"
                                value={split.percentage}
                                onChange={e => updateSplit(idx, 'percentage', e.target.value)}
                            />
                            <input 
                                type="number" 
                                placeholder="R$" 
                                className="w-24 p-2 rounded-xl text-xs font-bold text-right"
                                value={split.amount}
                                onChange={e => updateSplit(idx, 'amount', e.target.value)}
                            />
                            <button type="button" onClick={() => setSplits(splits.filter((_, i) => i !== idx))} className="p-2 text-rose-500"><Trash2 size={14}/></button>
                        </div>
                    ))}
                    <Button type="button" onClick={handleAddSplit} variant="ghost" className="text-xs text-indigo-600">+ Adicionar Centro de Custo</Button>
                    <p className="text-right text-xs font-black text-indigo-600">Total Rateado: R$ {splits.reduce((acc, s) => acc + s.amount, 0).toFixed(2)}</p>
                </div>
            ) : (
                <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Centro de Custo</label>
                        <select name="costCenterId" className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                            <option value="">Selecione...</option>
                            {costCenters.map(cc => <option key={cc.id} value={cc.id}>{cc.name}</option>)}
                        </select>
                    </div>
                    <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Projeto (Opcional)</label>
                        <select name="projectId" className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                            <option value="">Nenhum</option>
                            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                    </div>
                </div>
            )}

            <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Status Inicial</label>
                <select name="status" className="w-full p-4 rounded-2xl border-none bg-slate-100 dark:bg-slate-800 text-sm font-bold shadow-inner">
                    <option value="SCHEDULED">Agendado</option>
                    <option value="PAID">Realizado (Baixado)</option>
                </select>
            </div>

            <div className="flex justify-end gap-4 pt-6 border-t border-slate-100 dark:border-slate-800">
               <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="px-8 h-14 rounded-2xl">Cancelar</Button>
               <Button type="submit" loading={isSubmitting} className="bg-emerald-600 hover:bg-emerald-700 px-10 h-14 rounded-2xl shadow-xl shadow-emerald-500/20 font-black uppercase">Processar Lançamento</Button>
            </div>
         </form>
      </Modal>

      {/* Modal Banco */}
      <Modal isOpen={isBankModalOpen} onClose={() => setIsBankModalOpen(false)} title="Cadastro de Domicílio Bancário">
          <form onSubmit={handleSaveBank} className="space-y-6">
              <Input label="Apelido da Conta" name="name" placeholder="Ex: Itaú Principal" required />
              <div className="grid grid-cols-3 gap-4">
                  <Input label="Banco (Cód)" name="bankCode" placeholder="341" required />
                  <Input label="Agência" name="agency" required />
                  <Input label="Conta Corrente" name="account" required />
              </div>
              <Input label="Saldo Inicial (R$)" name="balance" type="number" step="0.01" required />
              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 h-14 rounded-2xl font-black uppercase">Ativar Conta</Button>
          </form>
      </Modal>

      {/* Modal Plano de Contas */}
      <Modal isOpen={isChartModalOpen} onClose={() => setIsChartModalOpen(false)} title="Nova Rubrica Contábil">
          <form onSubmit={handleSaveChart} className="space-y-6">
              <Input label="Código Estruturado" name="code" placeholder="Ex: 3.1.01.002" required />
              <Input label="Nome da Conta" name="name" placeholder="Ex: Receita com Doações PF" required />
              <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Grupo (DRE)</label>
                      <select name="type" className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                          <option value="REVENUE">Receita (+)</option>
                          <option value="EXPENSE">Despesa (-)</option>
                          <option value="ASSET">Ativo</option>
                          <option value="LIABILITY">Passivo</option>
                      </select>
                  </div>
                  <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Natureza</label>
                      <select name="category" className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                          <option value="OPERATIONAL">Operacional (Custo)</option>
                          <option value="FINANCIAL">Financeira</option>
                          <option value="PERSONNEL">Pessoal</option>
                          <option value="TAX">Impostos</option>
                      </select>
                  </div>
              </div>
              <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 h-14 rounded-2xl font-black uppercase">Criar Conta</Button>
          </form>
      </Modal>

      {/* Modal Conciliação (Simulação) */}
      <Modal isOpen={isReconcileModalOpen} onClose={() => setIsReconcileModalOpen(false)} title="Conciliação Bancária Inteligente" size="lg">
          <div className="space-y-8 text-center py-10">
              <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Upload size={32} className="text-indigo-600"/>
              </div>
              <div>
                  <h4 className="text-xl font-black text-slate-800 dark:text-white">Importar Extrato OFX</h4>
                  <p className="text-sm text-slate-500 mt-2">O sistema irá comparar automaticamente as datas e valores para sugerir o matching.</p>
              </div>
              <div className="border-2 border-dashed border-slate-200 rounded-3xl p-10 cursor-pointer hover:bg-slate-50 transition-colors">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Arraste o arquivo .OFX ou clique aqui</p>
              </div>
              <div className="flex gap-4 justify-center">
                  <Button variant="outline" onClick={() => setIsReconcileModalOpen(false)}>Cancelar</Button>
                  <Button className="bg-indigo-600" disabled>Processar (Simulado)</Button>
              </div>
          </div>
      </Modal>
    </div>
  );
};


/* projects.tsx_backup_v5.2_2023 */
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Card, Button, Input, Modal, Badge, useToast } from '../components/UI';
import { 
  Plus, Search, Layout, ChevronRight, Activity, FileText, 
  ListTree, Calendar, TrendingUp, ShieldAlert, UserCheck, 
  Target, Award, BrainCircuit, Share2, Send, History, 
  CheckCircle2, Zap, Clock, CheckCircle, UploadCloud, 
  Sparkles, Loader2, FileSearch, X, FileUp, AlertTriangle,
  BarChart, Layers, Users, Trash2, Edit2, Info, GitPullRequest,
  ClipboardCheck, BarChart2, Wallet, UserPlus, ArrowRightLeft,
  Check, XCircle, BookOpen, Camera, Trophy
} from 'lucide-react';
import { mockDB } from '../services/mockDB'; 
import { Project, ProjectPhase, ProjectTask, ProjectRisk, TaskDependencyType, ChangeRequest, QualityItem, Stakeholder, Beneficiary, FinanceTransaction, ProjectBaseline, LessonLearned, ProjectScoring } from '../types';
import { useAuth } from '../context/AuthContext';
import { FirestoreService } from '../services/FirestoreService';
import { GoogleGenAI, Type } from "@google/genai";
import { GanttChart } from '../components/GanttChart';
import { TermoAbertura } from '../components/TermoAbertura';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  ComposedChart, Line, Bar
} from 'recharts';

export const Projects: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [projects, setProjects] = useState<Project[]>([]);
  const [financeTransactions, setFinanceTransactions] = useState<FinanceTransaction[]>([]);
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [baselines, setBaselines] = useState<ProjectBaseline[]>([]);
  const [lessons, setLessons] = useState<LessonLearned[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'DASHBOARD' | 'TAP' | 'WBS' | 'GANTT' | 'EVM' | 'FINANCE' | 'RISKS' | 'CHANGES' | 'QUALITY' | 'STAKEHOLDERS' | 'BENEFICIARIES' | 'BASELINES' | 'LESSONS'>('DASHBOARD');
  const [portfolioView, setPortfolioView] = useState<'CARDS' | 'TABLE'>('CARDS');
  const [search, setSearch] = useState('');
  
  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isRiskModalOpen, setIsRiskModalOpen] = useState(false);
  const [isChangeModalOpen, setIsChangeModalOpen] = useState(false);
  const [isQualityModalOpen, setIsQualityModalOpen] = useState(false);
  const [isStakeholderModalOpen, setIsStakeholderModalOpen] = useState(false);
  const [isLinkBeneficiaryModalOpen, setIsLinkBeneficiaryModalOpen] = useState(false);
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);

  const [editingTask, setEditingTask] = useState<ProjectTask | null>(null);
  const [editingRisk, setEditingRisk] = useState<ProjectRisk | null>(null);
  const [editingChange, setEditingChange] = useState<ChangeRequest | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '', financer: '', description: '', budget: '', start: '', end: '',
    // Scoring fields
    strategicAlignment: '50', roi: '50', urgency: '50'
  });

  // Data Refresh
  const refresh = async () => {
    setIsLoading(true);
    try {
        const [projs, trans, bens, bases, less] = await Promise.all([
            FirestoreService.getAll<Project>('projects'),
            FirestoreService.getAll<FinanceTransaction>('finance_transactions'),
            FirestoreService.getAll<Beneficiary>('beneficiaries'),
            FirestoreService.getAll<ProjectBaseline>('baselines'),
            FirestoreService.getAll<LessonLearned>('lessons_learned')
        ]);
        setProjects(projs);
        setFinanceTransactions(trans);
        setBeneficiaries(bens);
        setBaselines(bases);
        setLessons(less);
    } catch (e) {
        toast.error('Erro ao sincronizar dados de projetos.');
        console.error(e);
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const selectedProject = useMemo(() => 
    projects.find(p => p.id === selectedProjectId) || null, 
    [projects, selectedProjectId]
  );

  // --- INTEGRATIONS & HELPERS ---

  // Calculate Weighted Score
  const calculateScore = (alignment: number, roi: number, urgency: number) => {
    return Math.round((alignment * 0.4) + (roi * 0.3) + (urgency * 0.3));
  };

  // 1. Finance Integration
  const projectTransactions = useMemo(() => {
    if (!selectedProjectId) return [];
    return financeTransactions.filter(t => t.projectId === selectedProjectId);
  }, [selectedProjectId, financeTransactions]);

  const actualCostTotal = useMemo(() => {
    return projectTransactions
      .filter(t => t.type === 'OUT')
      .reduce((acc, t) => acc + t.amount, 0);
  }, [projectTransactions]);

  // 2. CRM Integration (Beneficiaries)
  const projectBeneficiaries = useMemo(() => {
    if (!selectedProjectId) return [];
    return beneficiaries.filter(b => b.projectsLinked?.includes(selectedProjectId));
  }, [selectedProjectId, beneficiaries]);

  const availableBeneficiaries = useMemo(() => {
    if (!selectedProjectId) return [];
    return beneficiaries.filter(b => !b.projectsLinked?.includes(selectedProjectId));
  }, [selectedProjectId, beneficiaries]);

  // 3. Baselines Integration
  const projectBaselines = useMemo(() => {
    if (!selectedProjectId) return [];
    return baselines.filter(b => b.projectId === selectedProjectId).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [selectedProjectId, baselines]);

  // 4. Lessons Integration
  const projectLessons = useMemo(() => {
    if (!selectedProjectId) return [];
    return lessons.filter(l => l.projectId === selectedProjectId).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [selectedProjectId, lessons]);


  // --- EVM & ANALYTICS ---

  const evm = useMemo(() => {
    if (!selectedProject) return null;
    const tasks = selectedProject.tasks || [];
    const BAC = selectedProject.approvedValue || 0;
    
    // AC comes from Finance Module Integration
    const AC = actualCostTotal > 0 ? actualCostTotal : (selectedProject.executedValue || 0);
    
    // EV = sum(Planned Cost * % Progress)
    const EV = tasks.reduce((acc, t) => acc + (t.costEstimate * (t.progress / 100)), 0);
    
    // PV = sum(Planned Cost that should have been spent by now)
    const now = new Date();
    const PV = tasks.reduce((acc, t) => {
      const start = new Date(t.startDate);
      const end = new Date(t.endDate);
      if (now > end) return acc + t.costEstimate;
      if (now < start) return acc;
      const totalDays = Math.max(1, (end.getTime() - start.getTime()) / (1000 * 3600 * 24));
      const passedDays = Math.max(0, (now.getTime() - start.getTime()) / (1000 * 3600 * 24));
      return acc + (t.costEstimate * (passedDays / totalDays));
    }, 0);

    const CPI = AC > 0 ? EV / AC : 1.0;
    const SPI = PV > 0 ? EV / PV : 1.0;
    const CV = EV - AC;
    const SV = EV - PV;
    const EAC = CPI > 0 ? BAC / CPI : BAC;

    // S-Curve Data Generation
    const sCurveData = [];
    const start = new Date(selectedProject.startDate);
    const end = new Date(selectedProject.endDate);
    const totalDuration = Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24 * 30)); // Months

    let cumulativePV = 0;
    let cumulativeEV = 0;
    let cumulativeAC = 0;

    for (let i = 0; i <= totalDuration; i++) {
        const monthDate = new Date(start);
        monthDate.setMonth(start.getMonth() + i);
        const label = monthDate.toLocaleDateString('pt-BR', { month: 'short' });
        
        cumulativePV += (BAC / (totalDuration + 1));
        
        if (monthDate <= now) {
            cumulativeEV = EV * ((i + 1) / (totalDuration * 0.6)); // Simulated curve
            cumulativeAC = AC * ((i + 1) / (totalDuration * 0.6));
        }

        sCurveData.push({
            name: label,
            PV: Math.min(cumulativePV, BAC),
            EV: monthDate <= now ? Math.min(cumulativeEV, BAC) : null,
            AC: monthDate <= now ? cumulativeAC : null
        });
    }

    return { BAC, AC, EV, PV, CPI, SPI, CV, SV, EAC, sCurveData };
  }, [selectedProject, actualCostTotal]);

  // --- ACTIONS ---

  const handleSaveProject = async (proj: Project) => {
    try {
        await FirestoreService.save('projects', proj.id, proj);
        await refresh();
    } catch (e) {
        toast.error("Erro ao salvar projeto.");
    }
  };

  const handleChangeStatus = async (changeId: string, newStatus: 'APPROVED' | 'REJECTED') => {
    if (!selectedProject) return;
    const updatedChanges = selectedProject.changes.map(c => 
      c.id === changeId ? { ...c, status: newStatus } : c
    );
    await handleSaveProject({ ...selectedProject, changes: updatedChanges });
    toast.success(`Solicitação ${newStatus === 'APPROVED' ? 'Aprovada' : 'Rejeitada'}`);
  };

  const handleLinkBeneficiary = async (beneficiaryId: string) => {
    if (!selectedProjectId) return;
    const beneficiary = beneficiaries.find(b => b.id === beneficiaryId);
    if (beneficiary) {
      const updatedBen = {
          ...beneficiary,
          projectsLinked: [...(beneficiary.projectsLinked || []), selectedProjectId]
      };
      await FirestoreService.save('beneficiaries', beneficiary.id, updatedBen);
      toast.success('Beneficiário vinculado ao projeto.');
      refresh();
    }
  };

  const handleUnlinkBeneficiary = async (beneficiaryId: string) => {
    if (!selectedProjectId) return;
    const beneficiary = beneficiaries.find(b => b.id === beneficiaryId);
    if (beneficiary) {
      const updatedBen = {
          ...beneficiary,
          projectsLinked: beneficiary.projectsLinked.filter(id => id !== selectedProjectId)
      };
      await FirestoreService.save('beneficiaries', beneficiary.id, updatedBen);
      toast.success('Vínculo removido.');
      refresh();
    }
  };

  const handleCreateBaseline = async () => {
    if (!selectedProject) return;
    const newBaseline: ProjectBaseline = {
      id: `bl-${Date.now()}`,
      projectId: selectedProject.id,
      version: `v${projectBaselines.length + 1}.0`,
      createdAt: new Date().toISOString(),
      createdBy: currentUser?.name || 'Sistema',
      snapshot: {
        tasks: selectedProject.tasks,
        budget: selectedProject.approvedValue,
        startDate: selectedProject.startDate,
        endDate: selectedProject.endDate
      },
      varianceCost: 0,
      varianceSchedule: 0
    };
    
    // Calculate variance against previous baseline if exists
    if (projectBaselines.length > 0) {
      const prev = projectBaselines[0];
      newBaseline.varianceCost = selectedProject.approvedValue - prev.snapshot.budget;
      // Simple logic for schedule variance (days diff)
      const prevEnd = new Date(prev.snapshot.endDate).getTime();
      const currEnd = new Date(selectedProject.endDate).getTime();
      newBaseline.varianceSchedule = (currEnd - prevEnd) / (1000 * 3600 * 24);
    }

    await FirestoreService.save('baselines', newBaseline.id, newBaseline);
    await handleSaveProject({ ...selectedProject, baselineSet: true, baselineDate: new Date().toISOString() });
    toast.success('Linha de base (Baseline) congelada com sucesso.');
    refresh();
  };

  const handleCreateLesson = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.currentTarget);
    const newLesson: LessonLearned = {
      id: `LL-${Date.now()}`,
      projectId: selectedProject.id,
      phase: selectedProject.phase,
      category: f.get('category') as any,
      description: f.get('description') as string,
      impact: f.get('impact') as any,
      recommendation: f.get('recommendation') as string,
      createdAt: new Date().toISOString()
    };
    await FirestoreService.save('lessons_learned', newLesson.id, newLesson);
    setIsLessonModalOpen(false);
    toast.success('Lição aprendida registrada na base de conhecimento.');
    refresh();
  };

  // --- FORM HANDLERS (Existing) ---
  const handleTaskAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.target as HTMLFormElement);
    const newTask: ProjectTask = {
      id: editingTask?.id || `task-${Date.now()}`,
      wbsCode: f.get('wbsCode') as string,
      name: f.get('name') as string,
      type: 'TASK',
      startDate: f.get('startDate') as string,
      endDate: f.get('endDate') as string,
      durationPlanned: 0, // Should be calc
      progress: Number(f.get('progress')),
      costEstimate: Number(f.get('costEstimate')),
      actualCost: Number(f.get('actualCost') || 0),
      dependencies: [],
      status: Number(f.get('progress')) === 100 ? 'COMPLETED' : Number(f.get('progress')) > 0 ? 'IN_PROGRESS' : 'NOT_STARTED',
      isCritical: false,
      assignedHours: Number(f.get('assignedHours') || 0)
    };

    const updatedTasks = editingTask 
      ? selectedProject.tasks.map(t => t.id === editingTask.id ? newTask : t)
      : [...selectedProject.tasks, newTask];

    await handleSaveProject({ ...selectedProject, tasks: updatedTasks });
    setIsTaskModalOpen(false);
    setEditingTask(null);
    toast.success('Cronograma atualizado.');
  };

  // ... (handleRiskAction, handleCreateChangeRequest, handleCreateQualityItem, handleCreateStakeholder remain the same) ...
  const handleRiskAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.target as HTMLFormElement);
    const prob = Number(f.get('probability'));
    const impactVal = Number(f.get('impact'));
    
    const newRisk: ProjectRisk = {
      id: editingRisk?.id || `risk-${Date.now()}`,
      title: f.get('title') as string,
      description: f.get('description') as string,
      category: f.get('category') as any,
      probability: prob,
      impact: { schedule: impactVal, cost: impactVal, scope: impactVal, quality: impactVal },
      overallImpact: impactVal,
      score: prob * impactVal,
      strategy: f.get('strategy') as any,
      responsePlan: f.get('responsePlan') as string,
      contingencyPlan: '',
      ownerId: currentUser?.id || 'sys',
      ownerName: currentUser?.name || 'Sistema',
      status: 'IDENTIFICADO',
      contingencyBudget: 0
    };

    const updatedRisks = editingRisk 
      ? selectedProject.risks.map(r => r.id === editingRisk.id ? newRisk : r)
      : [...selectedProject.risks, newRisk];

    await handleSaveProject({ ...selectedProject, risks: updatedRisks });
    setIsRiskModalOpen(false);
    setEditingRisk(null);
    toast.success('Matriz de riscos atualizada.');
  };

  const handleCreateChangeRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.target as HTMLFormElement);
    const newChange: ChangeRequest = {
        id: `CR-${Date.now()}`,
        seq: (selectedProject.changes?.length || 0) + 1,
        title: f.get('title') as string,
        description: f.get('description') as string,
        requesterId: currentUser?.id || 'sys',
        requesterName: currentUser?.name || 'Sistema',
        date: new Date().toISOString(),
        justification: f.get('justification') as string,
        type: ['SCOPE'],
        impact: { scope: 'Impacto Moderado', scheduleDays: 5, cost: 1000, risks: 'Baixo' },
        status: 'SUBMITTED',
        approvals: []
    };
    const updatedChanges = [...(selectedProject.changes || []), newChange];
    await handleSaveProject({ ...selectedProject, changes: updatedChanges });
    setIsChangeModalOpen(false);
    toast.success('Solicitação de mudança (CR) criada.');
  };

  const handleCreateQualityItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.target as HTMLFormElement);
    const newItem: QualityItem = {
        id: `QI-${Date.now()}`,
        deliverable: f.get('deliverable') as string,
        criteria: f.get('criteria') as string,
        status: 'PENDING',
        inspectorId: currentUser?.id
    };
    const updatedQuality = [...(selectedProject.qualityPlan || []), newItem];
    await handleSaveProject({ ...selectedProject, qualityPlan: updatedQuality });
    setIsQualityModalOpen(false);
    toast.success('Critério de qualidade adicionado.');
  };

  const handleCreateStakeholder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const f = new FormData(e.target as HTMLFormElement);
    const newStakeholder: Stakeholder = {
        id: `SH-${Date.now()}`,
        name: f.get('name') as string,
        organization: f.get('org') as string,
        role: f.get('role') as string,
        interest: f.get('interest') as any,
        influence: f.get('influence') as any,
        engagementLevel: { current: 'Resistant', desired: 'Supportive' },
        expectations: '',
        commRequirements: ''
    };
    const updatedStakeholders = [...(selectedProject.stakeholders || []), newStakeholder];
    await handleSaveProject({ ...selectedProject, stakeholders: updatedStakeholders });
    setIsStakeholderModalOpen(false);
    toast.success('Stakeholder registrado.');
  };

  const handleAiAnalysis = async () => {
    if (!selectedProject || !evm) return;
    setIsAiProcessing(true);
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `Analise o projeto "${selectedProject.name}".
        Dados EVM: CPI=${evm.CPI.toFixed(2)}, SPI=${evm.SPI.toFixed(2)}, BAC=${evm.BAC}, EAC=${evm.EAC}.
        Riscos: ${selectedProject.risks.length} riscos identificados.
        Financeiro Real: R$ ${actualCostTotal} executados.
        Score Governança: ${selectedProject.scoring?.totalScore || 0}.
        Forneça um parecer executivo sobre a saúde do projeto e recomendações em 3 tópicos curtos.`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt
        });
        toast.info("Parecer IA: " + response.text?.substring(0, 150) + "...");
    } catch (e) {
        toast.error("IA indisponível.");
    } finally {
        setIsAiProcessing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAiProcessing(true);
    toast.info('IA GIRA analisando documento estratégico...');
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-lite',
          contents: [{ inlineData: { data: base64Data, mimeType: file.type }}, { text: "Extraia nome, financiador, descrição, orçamento (apenas número), data_inicio (YYYY-MM-DD), data_fim (YYYY-MM-DD) deste projeto em JSON." }],
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: { name: { type: Type.STRING }, financer: { type: Type.STRING }, description: { type: Type.STRING }, budget: { type: Type.NUMBER }, data_inicio: { type: Type.STRING }, data_fim: { type: Type.STRING } }
            }
          }
        });
        const extracted = JSON.parse(response.text || '{}');
        setFormData({
          ...formData,
          name: extracted.name || '', financer: extracted.financer || '', description: extracted.description || '', budget: extracted.budget?.toString() || '', start: extracted.data_inicio || '', end: extracted.data_fim || ''
        });
        setIsAiProcessing(false);
        toast.success('Campos sincronizados.');
      };
      reader.readAsDataURL(file);
    } catch (err) {
      toast.error('Erro na leitura neural.');
      setIsAiProcessing(false);
    }
  };

  const handleCreateProject = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const budget = Number(f.get('budget'));
    
    // Scoring Calculation
    const strat = Number(f.get('strategicAlignment'));
    const roi = Number(f.get('roi'));
    const urg = Number(f.get('urgency'));
    const totalScore = calculateScore(strat, roi, urg);

    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name: f.get('name') as string,
      description: f.get('description') as string,
      phase: ProjectPhase.IDEATION,
      status: 'IDEAÇÃO',
      justification: '',
      objectives_smart: [],
      scope_included: [], scope_excluded: [], assumptions: [], constraints: [],
      managerId: currentUser?.id || 'sys',
      managerName: currentUser?.name || 'Sistema',
      sponsorId: '', sponsorName: '',
      financerId: '', financerName: f.get('financer') as string,
      approvedValue: budget,
      managementReserve: budget * 0.1,
      contingencyReserve: budget * 0.05,
      executedValue: 0,
      startDate: f.get('start') as string,
      endDate: f.get('end') as string,
      baselineSet: false,
      tasks: [], risks: [], changes: [], stakeholders: [], theoryOfChange: [], odsIndicators: [], qualityPlan: [],
      scoring: {
        strategicAlignment: strat,
        roi: roi,
        urgency: urg,
        totalScore: totalScore
      },
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    await handleSaveProject(newProj);
    setIsFormOpen(false);
    toast.success('Nodo estratégico protocolado.');
  };

  if (isLoading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-12 h-12 text-violet-500 animate-spin opacity-20" />
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Sincronizando Portfólio...</p>
    </div>
  );

  // --- RENDERERS ---
  const RenderPortfolioView = () => {
    const sortedProjects = [...projects].sort((a,b) => (b.scoring?.totalScore || 0) - (a.scoring?.totalScore || 0));

    if (portfolioView === 'TABLE') {
      return (
        <Card className="p-0 glass border-none overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                <th className="p-6">Projeto</th>
                <th className="p-6 text-center">Score Priorização</th>
                <th className="p-6 text-center">Alinhamento Est.</th>
                <th className="p-6 text-center">ROI Social</th>
                <th className="p-6 text-center">Urgência</th>
                <th className="p-6 text-right">Budget</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sortedProjects.map(p => (
                <tr key={p.id} className="hover:bg-violet-500/[0.02] cursor-pointer" onClick={() => { setSelectedProjectId(p.id); setActiveTab('DASHBOARD'); }}>
                  <td className="p-6">
                    <p className="font-bold text-sm dark:text-white">{p.name}</p>
                    <p className="text-[9px] text-slate-400 uppercase tracking-widest">{p.financerName}</p>
                  </td>
                  <td className="p-6 text-center">
                    <Badge color={(p.scoring?.totalScore || 0) > 70 ? 'emerald' : 'amber'}>{p.scoring?.totalScore || 0}</Badge>
                  </td>
                  <td className="p-6 text-center text-xs font-bold text-slate-500">{p.scoring?.strategicAlignment || 0}</td>
                  <td className="p-6 text-center text-xs font-bold text-slate-500">{p.scoring?.roi || 0}</td>
                  <td className="p-6 text-center text-xs font-bold text-slate-500">{p.scoring?.urgency || 0}</td>
                  <td className="p-6 text-right font-black text-violet-600">R$ {p.approvedValue.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        {sortedProjects.filter(p => p.name?.toLowerCase().includes(search.toLowerCase())).map(p => (
          <Card key={p.id} className="group hover:border-violet-500 transition-all cursor-pointer h-[420px] flex flex-col justify-between glass border-white/20 p-10 hover:-translate-y-3 duration-500" onClick={() => { setSelectedProjectId(p.id); setActiveTab('DASHBOARD'); }}>
              <div className="flex justify-between items-start">
                <Badge color="indigo">{p.phase}</Badge>
                <div className="w-12 h-12 rounded-xl bg-violet-50 dark:bg-violet-900/30 text-violet-600 flex items-center justify-center font-black">{p.scoring?.totalScore || 0}</div>
              </div>
              <div>
                <h4 className="text-2xl font-black dark:text-white leading-tight mb-2 truncate">{p.name}</h4>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{p.financerName}</p>
              </div>
              <div className="space-y-4">
                <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-widest">
                  <span>Estratégia</span>
                  <span>{p.scoring?.strategicAlignment || 0}%</span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full bg-violet-500" style={{ width: `${p.scoring?.strategicAlignment || 0}%` }}></div>
                </div>
              </div>
              <div className="pt-6 border-t border-slate-100 dark:border-white/5 flex justify-between items-center">
                <p className="text-sm font-black text-violet-600">R$ {p.approvedValue.toLocaleString()}</p>
                <ChevronRight size={20} className="text-slate-300" />
              </div>
          </Card>
        ))}
      </div>
    );
  };

  const RenderBaselines = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Linhas de Base (Snapshots)</h3>
        <Button onClick={handleCreateBaseline} className="bg-indigo-600 gap-2"><Camera size={18}/> Congelar Nova Baseline</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {projectBaselines.map(bl => (
          <Card key={bl.id} className="glass border-l-4 border-l-indigo-500" title={`Baseline ${bl.version}`}>
             <p className="text-xs text-slate-400 font-bold uppercase mb-4 tracking-widest">Criado em: {new Date(bl.createdAt).toLocaleString()} por {bl.createdBy}</p>
             <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl">
                   <p className="text-[9px] font-black text-slate-400 uppercase">Budget Congelado</p>
                   <p className="text-lg font-black text-slate-700 dark:text-white">R$ {bl.snapshot.budget.toLocaleString()}</p>
                </div>
                <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl">
                   <p className="text-[9px] font-black text-slate-400 uppercase">Prazo Congelado</p>
                   <p className="text-sm font-bold text-slate-700 dark:text-white">{new Date(bl.snapshot.endDate).toLocaleDateString()}</p>
                </div>
             </div>
             {(bl.varianceCost !== 0 || bl.varianceSchedule !== 0) && (
               <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] font-black text-slate-400 uppercase mb-2">Variação vs Anterior</p>
                  <div className="flex gap-4">
                     <Badge color={bl.varianceCost! > 0 ? 'rose' : 'emerald'}>Custo: {bl.varianceCost! > 0 ? '+' : ''}{bl.varianceCost?.toLocaleString()}</Badge>
                     <Badge color={bl.varianceSchedule! > 0 ? 'rose' : 'emerald'}>Prazo: {bl.varianceSchedule! > 0 ? '+' : ''}{bl.varianceSchedule?.toFixed(0)} dias</Badge>
                  </div>
               </div>
             )}
          </Card>
        ))}
        {projectBaselines.length === 0 && (
          <div className="col-span-2 py-20 text-center glass rounded-[40px] border-2 border-dashed border-indigo-200">
             <Camera size={48} className="mx-auto text-slate-300 mb-4"/>
             <p className="text-slate-400 font-bold uppercase">Nenhuma baseline definida.</p>
          </div>
        )}
      </div>
    </div>
  );

  const RenderLessons = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Lições Aprendidas</h3>
        <Button onClick={() => setIsLessonModalOpen(true)} className="bg-emerald-600 gap-2"><BookOpen size={18}/> Nova Lição</Button>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {projectLessons.map(lesson => (
          <Card key={lesson.id} className={`glass border-l-4 ${lesson.impact === 'POSITIVO' ? 'border-l-emerald-500' : 'border-l-rose-500'}`}>
             <div className="flex justify-between items-start mb-2">
                <Badge color={lesson.impact === 'POSITIVO' ? 'emerald' : 'rose'}>{lesson.impact}</Badge>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{new Date(lesson.createdAt).toLocaleDateString()}</span>
             </div>
             <h4 className="font-bold text-lg dark:text-white mb-2">{lesson.category}</h4>
             <p className="text-sm text-slate-600 dark:text-slate-300 mb-4">"{lesson.description}"</p>
             <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl">
                <p className="text-[9px] font-black text-slate-400 uppercase mb-1">Recomendação Futura</p>
                <p className="text-xs font-bold text-indigo-600 italic">{lesson.recommendation}</p>
             </div>
          </Card>
        ))}
        {projectLessons.length === 0 && (
          <div className="py-20 text-center glass rounded-[40px]">
             <BookOpen size={48} className="mx-auto text-slate-300 mb-4"/>
             <p className="text-slate-400 font-bold uppercase">Nenhuma lição aprendida registrada.</p>
          </div>
        )}
      </div>
    </div>
  );

  // Reusing existing renderers for other tabs...
  const RenderWBS = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
         <h3 className="text-2xl font-black dark:text-white">EAP — Estrutura Analítica do Projeto</h3>
         <Button onClick={() => { setEditingTask(null); setIsTaskModalOpen(true); }} className="bg-violet-600 gap-2"><Plus size={18}/> Nova Atividade</Button>
      </div>
      <Card className="p-0 glass border-none overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
              <th className="p-6 w-96">Hierarquia WBS</th>
              <th className="p-6">Prazos</th>
              <th className="p-6">Orçamento</th>
              <th className="p-6 text-center">Progresso</th>
              <th className="p-6 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {selectedProject?.tasks.sort((a,b) => a.wbsCode.localeCompare(b.wbsCode, undefined, { numeric: true })).map(task => {
              const depth = task.wbsCode.split('.').length - 1;
              return (
                <tr key={task.id} className="hover:bg-violet-500/[0.02] group transition-colors">
                  <td className="p-6">
                     <div className="flex items-center" style={{ paddingLeft: `${depth * 24}px` }}>
                        <span className="font-black text-violet-600 text-xs mr-3">{task.wbsCode}</span>
                        <div>
                           <p className={`font-bold text-sm dark:text-white flex items-center gap-2 ${depth === 0 ? 'uppercase tracking-widest' : ''}`}>
                             {task.name}
                             {task.isCritical && <Badge color="rose">Crítico</Badge>}
                           </p>
                           <p className="text-[9px] text-slate-400 uppercase font-bold">{task.type}</p>
                        </div>
                     </div>
                  </td>
                  <td className="p-6">
                     <p className="text-xs font-bold dark:text-slate-300">{new Date(task.startDate).toLocaleDateString()} → {new Date(task.endDate).toLocaleDateString()}</p>
                  </td>
                  <td className="p-6">
                     <p className="text-xs font-black text-indigo-600">R$ {task.costEstimate.toLocaleString()}</p>
                     <p className="text-[9px] text-slate-400 uppercase font-bold">Real: R$ {task.actualCost.toLocaleString()}</p>
                  </td>
                  <td className="p-6">
                     <div className="flex items-center gap-3">
                        <div className="flex-1 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                           <div className={`h-full ${task.progress === 100 ? 'bg-emerald-500' : 'bg-violet-500'}`} style={{ width: `${task.progress}%` }}></div>
                        </div>
                        <span className="text-[10px] font-black text-violet-600">{task.progress}%</span>
                     </div>
                  </td>
                  <td className="p-6 text-right">
                     <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" className="p-2 text-violet-600" onClick={() => { setEditingTask(task); setIsTaskModalOpen(true); }}><Edit2 size={14}/></Button>
                        <Button variant="ghost" className="p-2 text-rose-500" onClick={() => {}}><Trash2 size={14}/></Button>
                     </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );

  // ... (Other Render functions RenderRisks, RenderEVM, RenderChanges, RenderQuality, RenderStakeholders, RenderBeneficiaries, RenderProjectFinance remain unchanged from backup, just assume they are here) ...
  const RenderRisks = () => (
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10 animate-in fade-in duration-500">
        <div className="space-y-8">
           <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">Matriz de Exposição de Riscos</h3>
              <Button onClick={() => { setEditingRisk(null); setIsRiskModalOpen(true); }} className="bg-violet-600"><Plus size={18}/> Novo Risco</Button>
           </div>
           <Card className="glass border-none" title="Mapa de Calor (P x I)">
              <div className="flex flex-col gap-2 mt-4">
                 {[5, 4, 3, 2, 1].map(p => (
                   <div key={p} className="flex gap-2 items-center">
                      <div className="w-10 text-[10px] font-black text-slate-400 uppercase">P{p}</div>
                      {[1, 2, 3, 4, 5].map(i => {
                        const score = p * i;
                        const risksInCell = selectedProject?.risks.filter(r => r.probability === p && r.overallImpact === i);
                        const getRiskColor = (score: number) => {
                            if (score >= 15) return 'bg-rose-500 shadow-rose-500/50';
                            if (score >= 8) return 'bg-amber-500 shadow-amber-500/50';
                            return 'bg-emerald-500 shadow-emerald-500/50';
                        };
                        return (
                          <div key={i} className={`flex-1 aspect-square rounded-xl flex items-center justify-center relative transition-all border-2 ${score >= 15 ? 'bg-rose-500/10 border-rose-500/20' : score >= 8 ? 'bg-amber-500/10 border-amber-500/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
                             {risksInCell && risksInCell.length > 0 && (
                               <div className={`w-8 h-8 rounded-full ${getRiskColor(score)} flex items-center justify-center text-white font-black text-xs animate-bounce-slow shadow-lg cursor-pointer`} title={`${risksInCell.length} riscos`}>
                                 {risksInCell.length}
                               </div>
                             )}
                          </div>
                        );
                      })}
                   </div>
                 ))}
                 <div className="flex gap-2 mt-2">
                    <div className="w-10"></div>
                    {[1, 2, 3, 4, 5].map(i => <div key={i} className="flex-1 text-center text-[10px] font-black text-slate-400 uppercase">I{i}</div>)}
                 </div>
              </div>
           </Card>
        </div>
        <div className="space-y-6">
           <h3 className="text-xl font-black dark:text-white px-2">Detalhamento dos Riscos</h3>
           {selectedProject?.risks.sort((a,b) => b.score - a.score).map(risk => (
             <Card key={risk.id} className={`glass group relative ${risk.score >= 15 ? 'border-l-rose-500' : 'border-l-amber-500'} border-l-4`}>
                <div className="flex justify-between items-start">
                   <div>
                      <h4 className="font-black text-lg dark:text-white leading-tight">{risk.title}</h4>
                      <p className="text-[10px] font-bold text-slate-400 uppercase mt-1 tracking-widest">{risk.category}</p>
                   </div>
                   <div className={`px-4 py-1.5 rounded-full text-white font-black text-[10px] uppercase tracking-widest`}>Score {risk.score}</div>
                </div>
                <p className="text-xs text-slate-500 mt-4 leading-relaxed line-clamp-2"><strong>Plano de Resposta:</strong> {risk.responsePlan}</p>
                <div className="mt-6 pt-4 border-t border-slate-50 dark:border-white/5 flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity">
                   <span className="text-[9px] font-black text-violet-600 uppercase">Estratégia: {risk.strategy}</span>
                   <div className="flex gap-2">
                      <Button variant="ghost" className="p-2 text-violet-600" onClick={() => { setEditingRisk(risk); setIsRiskModalOpen(true); }}><Edit2 size={14}/></Button>
                   </div>
                </div>
             </Card>
           ))}
        </div>
      </div>
  );

  const RenderEVM = () => {
    if (!evm) return null;
    return (
      <div className="space-y-10 animate-in fade-in duration-500">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
           <Card className="glass flex flex-col items-center py-10" title="CPI (Custo)" subtitle="Desempenho Financeiro">
              <div className={`text-6xl font-black mb-2 ${evm.CPI >= 1 ? 'text-emerald-500' : evm.CPI >= 0.9 ? 'text-amber-500' : 'text-rose-500'}`}>{evm.CPI.toFixed(2)}</div>
              <Badge color={evm.CPI >= 1 ? 'emerald' : 'rose'}>{evm.CPI >= 1 ? 'Dentro do Orçamento' : 'Estouro de Custo'}</Badge>
           </Card>
           <Card className="glass flex flex-col items-center py-10" title="SPI (Prazo)" subtitle="Desempenho de Cronograma">
              <div className={`text-6xl font-black mb-2 ${evm.SPI >= 1 ? 'text-emerald-500' : evm.SPI >= 0.9 ? 'text-amber-500' : 'text-rose-500'}`}>{evm.SPI.toFixed(2)}</div>
              <Badge color={evm.SPI >= 1 ? 'emerald' : 'rose'}>{evm.SPI >= 1 ? 'Dentro do Prazo' : 'Cronograma Atrasado'}</Badge>
           </Card>
           <Card className="glass border-l-4 border-l-violet-500">
              <p className="text-[10px] font-black text-slate-400 uppercase mb-1">EV - Valor Agregado</p>
              <p className="text-3xl font-black dark:text-white">R$ {evm.EV.toLocaleString('pt-BR', { notation: 'compact' })}</p>
              <div className="mt-6 flex justify-between items-center text-[10px] font-black uppercase">
                 <span className="text-slate-400">PV (Planejado):</span>
                 <span className="dark:text-white">R$ {evm.PV.toLocaleString('pt-BR', { notation: 'compact' })}</span>
              </div>
           </Card>
           <Card className="glass border-l-4 border-l-emerald-500">
              <p className="text-[10px] font-black text-slate-400 uppercase mb-1">EAC - Estimativa Final</p>
              <p className="text-3xl font-black dark:text-white">R$ {evm.EAC.toLocaleString('pt-BR', { notation: 'compact' })}</p>
              <div className="mt-6 flex justify-between items-center text-[10px] font-black uppercase">
                 <span className="text-slate-400">BAC (Original):</span>
                 <span className="dark:text-white">R$ {evm.BAC.toLocaleString('pt-BR', { notation: 'compact' })}</span>
              </div>
           </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card title="Curva S (EVM)" subtitle="Análise de Tendência de Valor">
               <div className="h-[300px] mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                     <ComposedChart data={evm.sCurveData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10}} />
                        <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `R$${v/1000}k`} tick={{fontSize: 10}} />
                        <RechartsTooltip />
                        <Line type="monotone" dataKey="PV" stroke="#94a3b8" strokeWidth={2} dot={false} name="Planejado (PV)" />
                        <Line type="monotone" dataKey="EV" stroke="#10b981" strokeWidth={3} name="Agregado (EV)" />
                        <Line type="monotone" dataKey="AC" stroke="#f43f5e" strokeWidth={2} strokeDasharray="5 5" name="Custo Real (AC)" />
                     </ComposedChart>
                  </ResponsiveContainer>
               </div>
            </Card>
            
            <Card title="Análise de Variância" subtitle="Desvios Monetários">
               <div className="space-y-6 p-4">
                  <div className="flex justify-between items-end p-4 glass rounded-2xl border border-slate-100">
                     <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CV - Variação de Custo</p>
                        <p className={`text-4xl font-black ${evm.CV >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>R$ {evm.CV.toLocaleString()}</p>
                     </div>
                     {evm.CV >= 0 ? <TrendingUp className="text-emerald-500" size={32}/> : <AlertTriangle className="text-rose-500" size={32}/>}
                  </div>
                  <div className="flex justify-between items-end p-4 glass rounded-2xl border border-slate-100">
                     <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">SV - Variação de Prazo</p>
                        <p className={`text-4xl font-black ${evm.SV >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>R$ {evm.SV.toLocaleString()}</p>
                     </div>
                     {evm.SV >= 0 ? <CheckCircle className="text-emerald-500" size={32}/> : <Clock className="text-rose-500" size={32}/>}
                  </div>
                  <p className="text-xs text-slate-400 italic text-center">Dados atualizados em tempo real via módulo financeiro.</p>
               </div>
            </Card>
        </div>
      </div>
    );
  };

  const RenderChanges = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black dark:text-white">Gestão Integrada de Mudanças (GMUD)</h3>
            <Button onClick={() => setIsChangeModalOpen(true)} className="bg-amber-500 hover:bg-amber-600 gap-2"><GitPullRequest size={18}/> Solicitar Mudança</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(selectedProject?.changes || []).map(change => (
                <Card key={change.id} className="glass border-l-4 border-l-amber-500" title={`CR #${change.seq}: ${change.title}`}>
                    <p className="text-sm text-slate-500 mb-4">{change.description}</p>
                    <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                        <div className="p-2 bg-slate-50 rounded-lg"><span className="font-bold">Impacto Custo:</span> R$ {change.impact.cost}</div>
                        <div className="p-2 bg-slate-50 rounded-lg"><span className="font-bold">Impacto Prazo:</span> {change.impact.scheduleDays} dias</div>
                    </div>
                    <div className="flex justify-between items-center mb-4">
                        <Badge color={change.status === 'APPROVED' ? 'emerald' : change.status === 'REJECTED' ? 'rose' : 'amber'}>{change.status}</Badge>
                        <span className="text-[10px] font-bold text-slate-400">{new Date(change.date).toLocaleDateString()}</p>
                    </div>
                    {change.status === 'SUBMITTED' && (
                      <div className="flex gap-2 pt-2 border-t border-slate-100">
                        <Button onClick={() => handleChangeStatus(change.id, 'APPROVED')} className="flex-1 h-8 text-[10px] bg-emerald-500 hover:bg-emerald-600"><Check size={12}/> Aprovar</Button>
                        <Button onClick={() => handleChangeStatus(change.id, 'REJECTED')} className="flex-1 h-8 text-[10px] bg-rose-500 hover:bg-rose-600"><XCircle size={12}/> Rejeitar</Button>
                      </div>
                    )}
                </Card>
            ))}
            {(selectedProject?.changes || []).length === 0 && (
                <div className="col-span-3 py-20 text-center glass rounded-[40px]">
                    <GitPullRequest size={48} className="mx-auto text-slate-200 mb-4"/>
                    <p className="text-slate-400 font-bold">Nenhuma solicitação de mudança registrada.</p>
                </div>
            )}
        </div>
    </div>
  );

  const RenderQuality = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black dark:text-white">Garantia da Qualidade (QA)</h3>
            <Button onClick={() => setIsQualityModalOpen(true)} className="bg-emerald-600 gap-2"><ClipboardCheck size={18}/> Adicionar Critério</Button>
        </div>
        <Card className="p-0 glass border-none overflow-hidden">
            <table className="w-full text-left">
                <thead>
                    <tr className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                        <th className="p-6">Entregável</th>
                        <th className="p-6">Critério de Aceitação</th>
                        <th className="p-6 text-center">Status</th>
                        <th className="p-6 text-right">Ação</th>
                    </tr>
                </thead>
                <tbody>
                    {(selectedProject?.qualityPlan || []).map(item => (
                        <tr key={item.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                            <td className="p-6 font-bold text-sm">{item.deliverable}</td>
                            <td className="p-6 text-sm text-slate-500">{item.criteria}</td>
                            <td className="p-6 text-center"><Badge color={item.status === 'PASSED' ? 'emerald' : item.status === 'FAILED' ? 'rose' : 'slate'}>{item.status}</Badge></td>
                            <td className="p-6 text-right"><Button variant="ghost" className="text-indigo-600"><CheckCircle2 size={16}/></Button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Card>
    </div>
  );

  const RenderStakeholders = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black dark:text-white">Matriz de Stakeholders</h3>
            <Button onClick={() => setIsStakeholderModalOpen(true)} className="bg-indigo-600 gap-2"><Users size={18}/> Novo Interessado</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {(selectedProject?.stakeholders || []).map(sh => (
                <div key={sh.id} className="p-6 glass rounded-3xl border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold">{sh.name.charAt(0)}</div>
                        <div>
                            <h4 className="font-bold text-slate-800 dark:text-white">{sh.name}</h4>
                            <p className="text-xs text-slate-500">{sh.role} @ {sh.organization}</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <Badge color="indigo">{sh.influence} Inf. / {sh.interest} Int.</Badge>
                        <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase">Engajamento: {sh.engagementLevel.current}</p>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );

  const RenderBeneficiaries = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-2xl font-black dark:text-white">Beneficiários e Comunidade</h3>
          <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest">Integração CRM Gira Vínculos</p>
        </div>
        <Button onClick={() => setIsLinkBeneficiaryModalOpen(true)} className="bg-pink-600 hover:bg-pink-700 gap-2"><UserPlus size={18}/> Vincular Beneficiário</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projectBeneficiaries.map(ben => (
          <div key={ben.id} className="p-5 rounded-3xl glass border border-slate-100 dark:border-slate-800 flex items-center justify-between group hover:border-pink-500 transition-all">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-pink-100 dark:bg-pink-900/30 text-pink-600 rounded-full flex items-center justify-center font-black">{ben.name.charAt(0)}</div>
                <div>
                   <p className="text-sm font-black dark:text-white">{ben.name}</p>
                   <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{ben.address.neighborhood}</p>
                </div>
             </div>
             <Button variant="ghost" onClick={() => handleUnlinkBeneficiary(ben.id)} className="text-slate-300 hover:text-rose-500"><XCircle size={18}/></Button>
          </div>
        ))}
        {projectBeneficiaries.length === 0 && (
          <div className="col-span-full py-12 text-center text-slate-400 font-bold uppercase text-xs tracking-widest border-2 border-dashed border-slate-200 rounded-3xl">
            Nenhum beneficiário vinculado a este projeto.
          </div>
        )}
      </div>
    </div>
  );

  const RenderProjectFinance = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Execução Orçamentária Real</h3>
        <Badge color={actualCostTotal > (selectedProject?.approvedValue || 0) ? 'rose' : 'emerald'}>
          {actualCostTotal > (selectedProject?.approvedValue || 0) ? 'Estouro de Budget' : 'Dentro do Orçamento'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <Card className="glass border-l-4 border-l-violet-500">
            <p className="text-[10px] font-black text-slate-400 uppercase">Orçado (BAC)</p>
            <p className="text-2xl font-black dark:text-white">R$ {selectedProject?.approvedValue.toLocaleString()}</p>
         </Card>
         <Card className="glass border-l-4 border-l-rose-500">
            <p className="text-[10px] font-black text-slate-400 uppercase">Executado (AC)</p>
            <p className="text-2xl font-black text-rose-500">R$ {actualCostTotal.toLocaleString()}</p>
         </Card>
         <Card className="glass border-l-4 border-l-emerald-500">
            <p className="text-[10px] font-black text-slate-400 uppercase">Saldo Disponível</p>
            <p className="text-2xl font-black text-emerald-500">R$ {((selectedProject?.approvedValue || 0) - actualCostTotal).toLocaleString()}</p>
         </Card>
      </div>

      <Card title="Transações Vinculadas" className="p-0 overflow-hidden">
         <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
               <tr>
                  <th className="p-4 pl-6">Data</th>
                  <th className="p-4">Descrição</th>
                  <th className="p-4">Categoria</th>
                  <th className="p-4 text-right pr-6">Valor</th>
               </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
               {projectTransactions.map(t => (
                 <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-4 pl-6 text-xs font-bold text-slate-500">{new Date(t.date).toLocaleDateString()}</td>
                    <td className="p-4 text-sm font-bold dark:text-white">{t.description}</td>
                    <td className="p-4"><Badge color="slate">{t.category}</Badge></td>
                    <td className={`p-4 pr-6 text-right font-black ${t.type === 'IN' ? 'text-emerald-500' : 'text-rose-500'}`}>
                       {t.type === 'IN' ? '+' : '-'} R$ {t.amount.toLocaleString()}
                    </td>
                 </tr>
               ))}
               {projectTransactions.length === 0 && (
                 <tr><td colSpan={4} className="p-8 text-center text-xs font-bold text-slate-400 uppercase">Nenhuma movimentação financeira registrada.</td></tr>
               )}
            </tbody>
         </table>
      </Card>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      {!selectedProjectId ? (
        <div className="space-y-10">
           <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <Badge color="indigo">ENTERPRISE CORE v5.2</Badge>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                </div>
                <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Projetos <span className="text-violet-500">Sociais</span></h2>
                <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.4em] mt-3">Gestão de Impacto Integrada ATIS</p>
              </div>
              <Button onClick={() => {
                setFormData({name: '', financer: '', description: '', budget: '', start: '', end: '', strategicAlignment: '50', roi: '50', urgency: '50'});
                setIsFormOpen(true);
              }} className="px-12 h-16 rounded-[28px] bg-violet-600 hover:bg-violet-700 shadow-xl shadow-violet-500/20 gap-3 text-lg font-black uppercase"><Plus size={24}/> Novo Nodo Estratégico</Button>
           </header>
           
           <div className="flex items-center justify-between gap-4">
              <div className="flex-1 relative group">
                  <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-violet-500 transition-colors" size={20} />
                  <input type="text" placeholder="Localizar nodo estratégico..." className="w-full pl-16 pr-6 py-5 rounded-[32px] border-none glass bg-white/40 dark:bg-slate-800/40 focus:ring-4 focus:ring-violet-500/10 transition-all font-bold text-sm dark:text-white shadow-lg" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <div className="flex gap-2 p-1.5 glass rounded-[32px]">
                  <button onClick={() => setPortfolioView('CARDS')} className={`px-6 py-3 rounded-[24px] text-xs font-black uppercase transition-all ${portfolioView === 'CARDS' ? 'bg-violet-600 text-white shadow-lg' : 'text-slate-500'}`}>Cards</button>
                  <button onClick={() => setPortfolioView('TABLE')} className={`px-6 py-3 rounded-[24px] text-xs font-black uppercase transition-all ${portfolioView === 'TABLE' ? 'bg-violet-600 text-white shadow-lg' : 'text-slate-500'}`}>Tabela</button>
              </div>
           </div>

           <RenderPortfolioView />
        </div>
      ) : (
        <div className="space-y-10 pb-20 animate-in fade-in duration-700">
           <div className="flex items-center gap-6">
              <button onClick={() => setSelectedProjectId(null)} className="p-4 rounded-2xl glass hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"><Layout size={24} className="text-violet-600"/></button>
              <div>
                <h3 className="text-3xl font-black dark:text-white tracking-tighter">{selectedProject.name}</h3>
                <div className="flex items-center gap-2 mt-1">
                   <Badge color="violet">Score: {selectedProject.scoring?.totalScore || 'N/A'}</Badge>
                   <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{selectedProject.financerName}</span>
                </div>
              </div>
           </div>
           <nav className="flex p-1.5 glass rounded-[40px] w-full overflow-x-auto no-scrollbar shadow-2xl border-white/10 bg-white/20 dark:bg-black/20">
              {[
                { id: 'DASHBOARD', label: 'Overview', icon: <Target size={14}/> },
                { id: 'TAP', label: 'Charter', icon: <FileSearch size={14}/> },
                { id: 'WBS', label: 'EAP', icon: <ListTree size={14}/> },
                { id: 'GANTT', label: 'Timeline', icon: <Calendar size={14}/> },
                { id: 'EVM', label: 'EVM & S-Curve', icon: <BarChart2 size={14}/> },
                { id: 'BASELINES', label: 'Baselines', icon: <Camera size={14}/> },
                { id: 'FINANCE', label: 'Financeiro', icon: <Wallet size={14}/> },
                { id: 'RISKS', label: 'Riscos', icon: <ShieldAlert size={14}/> },
                { id: 'CHANGES', label: 'Mudanças', icon: <GitPullRequest size={14}/> },
                { id: 'LESSONS', label: 'Lições', icon: <BookOpen size={14}/> },
                { id: 'QUALITY', label: 'Qualidade', icon: <ClipboardCheck size={14}/> },
                { id: 'STAKEHOLDERS', label: 'Stakeholders', icon: <Users size={14}/> },
                { id: 'BENEFICIARIES', label: 'Beneficiários', icon: <UserPlus size={14}/> },
              ].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex items-center gap-3 px-6 py-4 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-violet-600 text-white shadow-xl shadow-violet-500/20' : 'text-slate-500 hover:text-violet-600'}`}>
                  {tab.icon} {tab.label}
                </button>
              ))}
           </nav>
           <main>
              {activeTab === 'DASHBOARD' && (
                <div className="space-y-10 animate-in slide-in-from-bottom-5">
                   <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                      <Card title="Status Executivo">
                         <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-emerald-500/10 text-emerald-500 rounded-2xl flex items-center justify-center font-black text-xs">VIVO</div>
                            <div>
                               <p className="text-lg font-black dark:text-white">FASE: {selectedProject.phase}</p>
                               <p className="text-[10px] text-slate-400 font-bold uppercase">Ciclo de Vida v2</p>
                            </div>
                         </div>
                      </Card>
                      <Card title="Saúde Custo (CPI)">
                         <h3 className={`text-4xl font-black ${evm!.CPI >= 1 ? 'text-emerald-500' : 'text-rose-500'}`}>{evm!.CPI.toFixed(2)}</h3>
                      </Card>
                      <Card title="Saúde Prazo (SPI)">
                         <h3 className={`text-4xl font-black ${evm!.SPI >= 1 ? 'text-emerald-500' : 'text-rose-500'}`}>{evm!.SPI.toFixed(2)}</h3>
                      </Card>
                      <Card title="Budget Restante">
                         <h3 className="text-2xl font-black dark:text-white">R$ {((selectedProject.approvedValue || 0) - actualCostTotal).toLocaleString()}</h3>
                      </Card>
                   </div>
                   <div className="flex justify-end">
                      <Button onClick={handleAiAnalysis} disabled={isAiProcessing} className="bg-violet-600 gap-2 shadow-violet-500/20">
                        {isAiProcessing ? <Loader2 size={18} className="animate-spin"/> : <Sparkles size={18}/>}
                        Solicitar Parecer da IA
                      </Button>
                   </div>
                </div>
              )}
              {activeTab === 'TAP' && <TermoAbertura project={selectedProject} onUpdate={refresh} />}
              {activeTab === 'WBS' && <RenderWBS />}
              {activeTab === 'GANTT' && <GanttChart tasks={selectedProject.tasks} onUpdate={refresh} />}
              {activeTab === 'EVM' && <RenderEVM />}
              {activeTab === 'BASELINES' && <RenderBaselines />}
              {activeTab === 'FINANCE' && <RenderProjectFinance />}
              {activeTab === 'RISKS' && <RenderRisks />}
              {activeTab === 'CHANGES' && <RenderChanges />}
              {activeTab === 'LESSONS' && <RenderLessons />}
              {activeTab === 'QUALITY' && <RenderQuality />}
              {activeTab === 'STAKEHOLDERS' && <RenderStakeholders />}
              {activeTab === 'BENEFICIARIES' && <RenderBeneficiaries />}
           </main>
        </div>
      )}

      {/* MODAL NOVO PROJETO */}
      <Modal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} title="Abertura de Nodo Estratégico" size="xl">
         <div className="space-y-10">
            <div className="flex justify-between items-center bg-violet-50/50 p-6 rounded-[24px] border border-violet-100 dark:bg-violet-900/10 dark:border-violet-500/10">
               <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-2xl ${isAiProcessing ? 'bg-violet-600 animate-pulse' : 'bg-white shadow-lg'}`}>
                     {isAiProcessing ? <Loader2 className="text-white animate-spin" size={20} /> : <Sparkles className="text-violet-600" size={20} />}
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-violet-600 uppercase">Assistente de Configuração IA</p>
                    <p className="text-xs font-bold text-slate-500 dark:text-slate-400">Arraste edital ou proposta para preenchimento automático.</p>
                  </div>
               </div>
               <Button variant="outline" className="rounded-xl" onClick={() => fileInputRef.current?.click()} disabled={isAiProcessing}>
                 <FileUp size={16}/> Carregar Doc
               </Button>
               <input type="file" ref={fileInputRef} className="hidden" accept=".pdf,.docx,image/*" onChange={handleFileUpload} />
            </div>

            <form onSubmit={handleCreateProject} className="space-y-8">
               <div className="grid grid-cols-2 gap-8">
                  <Input label="Denominação" name="name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
                  <Input label="Financiador" name="financer" value={formData.financer} onChange={e => setFormData({...formData, financer: e.target.value})} required />
               </div>
               <Input label="Descrição do Propósito Social" name="description" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} required />
               <div className="grid grid-cols-3 gap-8">
                  <Input label="Budget BAC (R$)" name="budget" type="number" value={formData.budget} onChange={e => setFormData({...formData, budget: e.target.value})} required />
                  <Input label="Início" name="start" type="date" value={formData.start} onChange={e => setFormData({...formData, start: e.target.value})} required />
                  <Input label="Término" name="end" type="date" value={formData.end} onChange={e => setFormData({...formData, end: e.target.value})} required />
               </div>
               
               {/* Scoring Section */}
               <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 space-y-4">
                  <h4 className="text-xs font-black uppercase text-violet-600 tracking-widest">Matriz de Priorização (0-100)</h4>
                  <div className="grid grid-cols-3 gap-6">
                     <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">Alinhamento Estratégico</label>
                        <input type="range" name="strategicAlignment" min="0" max="100" value={formData.strategicAlignment} onChange={e => setFormData({...formData, strategicAlignment: e.target.value})} className="w-full accent-violet-600" />
                        <p className="text-right text-xs font-bold">{formData.strategicAlignment}</p>
                     </div>
                     <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">ROI / Impacto Social</label>
                        <input type="range" name="roi" min="0" max="100" value={formData.roi} onChange={e => setFormData({...formData, roi: e.target.value})} className="w-full accent-violet-600" />
                        <p className="text-right text-xs font-bold">{formData.roi}</p>
                     </div>
                     <div className="space-y-1">
                        <label className="text-[10px] font-black text-slate-400 uppercase">Urgência</label>
                        <input type="range" name="urgency" min="0" max="100" value={formData.urgency} onChange={e => setFormData({...formData, urgency: e.target.value})} className="w-full accent-violet-600" />
                        <p className="text-right text-xs font-bold">{formData.urgency}</p>
                     </div>
                  </div>
               </div>

               <div className="flex justify-end gap-4 pt-6 border-t border-slate-50">
                  <Button variant="outline" type="button" onClick={() => setIsFormOpen(false)}>Cancelar</Button>
                  <Button type="submit" className="bg-violet-600">Gravar Projeto</Button>
               </div>
            </form>
         </div>
      </Modal>

      {/* MODAL TAREFA */}
      <Modal isOpen={isTaskModalOpen} onClose={() => setIsTaskModalOpen(false)} title={editingTask ? "Editar Atividade" : "Nova Atividade na EAP"}>
         <form onSubmit={handleTaskAction} className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
               <div className="col-span-1"><Input label="Cód. WBS" name="wbsCode" defaultValue={editingTask?.wbsCode} required /></div>
               <div className="col-span-2"><Input label="Denominação" name="name" defaultValue={editingTask?.name} required /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
               <Input label="Início" name="startDate" type="date" defaultValue={editingTask?.startDate} required />
               <Input label="Fim" name="endDate" type="date" defaultValue={editingTask?.endDate} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
               <Input label="Orçado (BAC) R$" name="costEstimate" type="number" defaultValue={editingTask?.costEstimate} required />
               <Input label="Real (AC) R$" name="actualCost" type="number" defaultValue={editingTask?.actualCost} />
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Progresso (%)</label>
               <input type="range" name="progress" min="0" max="100" defaultValue={editingTask?.progress || 0} className="w-full accent-violet-600" />
            </div>
            {/* Resource Management Addition */}
            <Input label="Esforço Estimado (Horas)" name="assignedHours" type="number" defaultValue={editingTask?.assignedHours || 0} />
            
            <Button type="submit" className="w-full bg-violet-600">{editingTask ? 'Salvar Alterações' : 'Adicionar Atividade'}</Button>
         </form>
      </Modal>

      {/* MODAL LIÇÃO APRENDIDA */}
      <Modal isOpen={isLessonModalOpen} onClose={() => setIsLessonModalOpen(false)} title="Registrar Lição Aprendida">
         <form onSubmit={handleCreateLesson} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Categoria</label>
                  <select name="category" className="w-full p-3 rounded-xl glass border-none text-sm font-bold shadow-inner">
                     <option value="TECNICO">Técnico</option>
                     <option value="GERENCIAL">Gerencial</option>
                     <option value="EXTERNO">Externo</option>
                     <option value="PESSOAS">Pessoas</option>
                  </select>
               </div>
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Impacto</label>
                  <select name="impact" className="w-full p-3 rounded-xl glass border-none text-sm font-bold shadow-inner">
                     <option value="POSITIVO">Positivo (Sucesso)</option>
                     <option value="NEGATIVO">Negativo (Falha)</option>
                  </select>
               </div>
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Descrição da Ocorrência</label>
               <textarea name="description" required className="w-full p-4 rounded-xl glass border-none h-24 text-sm font-medium shadow-inner"></textarea>
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Recomendação Futura</label>
               <textarea name="recommendation" required className="w-full p-4 rounded-xl glass border-none h-24 text-sm font-medium shadow-inner"></textarea>
            </div>
            <Button type="submit" className="w-full bg-emerald-600">Arquivar Lição</Button>
         </form>
      </Modal>

      {/* ... Other modals (Risk, Change, Quality, Stakeholder, LinkBeneficiary) kept same as backup ... */}
      <Modal isOpen={isRiskModalOpen} onClose={() => setIsRiskModalOpen(false)} title={editingRisk ? "Editar Risco" : "Protocolar Novo Risco"}>
         <form onSubmit={handleRiskAction} className="space-y-6">
            <Input label="Título do Evento de Risco" name="title" defaultValue={editingRisk?.title} required />
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Probabilidade (1-5)</label>
                  <select name="probability" defaultValue={editingRisk?.probability || 1} className="w-full p-3 rounded-xl glass border-none font-bold text-sm bg-white dark:bg-slate-800 shadow-inner">
                     <option value="1">Muito Baixa</option><option value="2">Baixa</option><option value="3">Média</option><option value="4">Alta</option><option value="5">Muito Alta</option>
                  </select>
               </div>
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Impacto (1-5)</label>
                  <select name="impact" defaultValue={editingRisk?.overallImpact || 1} className="w-full p-3 rounded-xl glass border-none font-bold text-sm bg-white dark:bg-slate-800 shadow-inner">
                     <option value="1">Insignificante</option><option value="2">Menor</option><option value="3">Moderado</option><option value="4">Crítico</option><option value="5">Catastrófico</option>
                  </select>
               </div>
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Categoria</label>
               <select name="category" defaultValue={editingRisk?.category} className="w-full p-3 rounded-xl glass border-none font-bold text-sm bg-white dark:bg-slate-800 shadow-inner">
                  <option value="TECNICO">Técnico</option><option value="EXTERNO">Externo</option><option value="ORGANIZACIONAL">Organizacional</option><option value="GERENCIAL">Gerencial</option>
               </select>
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Estratégia</label>
               <select name="strategy" defaultValue={editingRisk?.strategy} className="w-full p-3 rounded-xl glass border-none font-bold text-sm bg-white dark:bg-slate-800 shadow-inner">
                  <option value="MITIGAR">Mitigar</option><option value="EVITAR">Evitar</option><option value="ACEITAR">Aceitar</option><option value="TRANSFERIR">Transferir</option>
               </select>
            </div>
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Plano de Resposta</label>
               <textarea name="responsePlan" defaultValue={editingRisk?.responsePlan} required className="w-full p-4 rounded-xl glass border-none bg-white dark:bg-slate-800 text-sm h-24 shadow-inner focus:ring-4 focus:ring-violet-500/10 transition-all"></textarea>
            </div>
            <Button type="submit" className="w-full bg-violet-600">Protocolar Risco</Button>
         </form>
      </Modal>

      <Modal isOpen={isChangeModalOpen} onClose={() => setIsChangeModalOpen(false)} title="Solicitação de Mudança (Change Request)">
         <form onSubmit={handleCreateChangeRequest} className="space-y-6">
            <Input label="Título da Mudança" name="title" required />
            <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase">Descrição</label>
                <textarea name="description" className="w-full p-4 rounded-xl glass border-none h-24 text-sm" required></textarea>
            </div>
            <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase">Justificativa</label>
                <textarea name="justification" className="w-full p-4 rounded-xl glass border-none h-24 text-sm" required></textarea>
            </div>
            <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600">Submeter para Aprovação</Button>
         </form>
      </Modal>

      <Modal isOpen={isQualityModalOpen} onClose={() => setIsQualityModalOpen(false)} title="Critério de Qualidade">
         <form onSubmit={handleCreateQualityItem} className="space-y-6">
            <Input label="Entregável" name="deliverable" placeholder="Ex: Relatório Final" required />
            <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase">Critério de Aceitação</label>
                <textarea name="criteria" className="w-full p-4 rounded-xl glass border-none h-24 text-sm" required placeholder="Ex: Deve conter todas as assinaturas e aprovação financeira"></textarea>
            </div>
            <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">Registrar Critério</Button>
         </form>
      </Modal>

      <Modal isOpen={isStakeholderModalOpen} onClose={() => setIsStakeholderModalOpen(false)} title="Registro de Stakeholder">
         <form onSubmit={handleCreateStakeholder} className="space-y-6">
            <Input label="Nome" name="name" required />
            <div className="grid grid-cols-2 gap-4">
                <Input label="Organização" name="org" required />
                <Input label="Papel" name="role" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase">Interesse</label>
                    <select name="interest" className="w-full p-3 rounded-xl glass border-none text-sm">
                        <option value="HIGH">Alto</option>
                        <option value="MEDIUM">Médio</option>
                        <option value="LOW">Baixo</option>
                    </select>
                </div>
                <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase">Influência</label>
                    <select name="influence" className="w-full p-3 rounded-xl glass border-none text-sm">
                        <option value="HIGH">Alta</option>
                        <option value="MEDIUM">Média</option>
                        <option value="LOW">Baixa</option>
                    </select>
                </div>
            </div>
            <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700">Adicionar Interessado</Button>
         </form>
      </Modal>

      <Modal isOpen={isLinkBeneficiaryModalOpen} onClose={() => setIsLinkBeneficiaryModalOpen(false)} title="Vincular Beneficiário (CRM)">
         <div className="space-y-6">
            <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input placeholder="Buscar no banco de dados geral..." className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-slate-100" />
            </div>
            <div className="max-h-[300px] overflow-y-auto space-y-2 pr-2">
               {availableBeneficiaries.map(ben => (
                 <div key={ben.id} className="flex justify-between items-center p-4 rounded-2xl bg-slate-50 border border-slate-100">
                    <div>
                       <p className="text-sm font-bold dark:text-black">{ben.name}</p>
                       <p className="text-[10px] text-slate-400 font-bold uppercase">{ben.address.neighborhood}</p>
                    </div>
                    <Button onClick={() => handleLinkBeneficiary(ben.id)} className="h-8 text-[10px] bg-pink-600 hover:bg-pink-700">Vincular</Button>
                 </div>
               ))}
               {availableBeneficiaries.length === 0 && <p className="text-center text-xs text-slate-400 py-4">Todos os beneficiários já estão vinculados ou base vazia.</p>}
            </div>
         </div>
      </Modal>
    </div>
  );
};

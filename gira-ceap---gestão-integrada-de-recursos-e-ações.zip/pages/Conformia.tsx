import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Badge, Input, Modal, useToast } from '../components/UI';
import { 
  ShieldCheck, Activity, BrainCircuit, Globe, FileText, 
  Users, AlertTriangle, Zap, Download, Plus, 
  Search, Filter, ChevronRight, Lock, CheckCircle2, 
  Clock, Eye, MessageSquare, Briefcase, Truck, Box,
  DollarSign, Terminal, Radar, Award, Info, Fingerprint,
  Share2, Network, Siren, Database, RefreshCw, ClipboardList,
  BarChart3
} from 'lucide-react';
import { 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, 
  Radar as RechartsRadar, ResponsiveContainer, AreaChart, Area, 
  XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Legend 
} from 'recharts';
import { mockDB } from '../services/mockDB';
import { FirestoreService } from '../services/FirestoreService';
import { GovernanceService } from '../services/GovernanceService';
import { 
  DataActivity, SubjectRequest, ConformiaIncident, 
  ConformiaPolicy, ConformiaTraining, DPIA, Supplier, User,
  ThirdPartyAssessment, DataSharingLog, BCPPlan, IncidentSimulation
} from '../types';

export const Conformia: React.FC = () => {
  const toast = useToast();
  // Extended Tabs
  const [activeTab, setActiveTab] = useState<'DASH' | 'INVENTORY' | 'RIGHTS' | 'THIRD' | 'TPRM' | 'ROPA' | 'INCIDENTS' | 'POLICIES' | 'TRAINING' | 'DPIA' | 'MATURITY' | 'BCP'>('DASH');
  
  // Existing Data States
  const [inventory, setInventory] = useState<DataActivity[]>(mockDB.getLGPDInventory());
  const [requests, setRequests] = useState<SubjectRequest[]>(mockDB.getSubjectRequests());
  const [incidents, setIncidents] = useState<ConformiaIncident[]>(mockDB.getConformiaIncidents());
  const [policies, setPolicies] = useState<ConformiaPolicy[]>(mockDB.getConformiaPolicies());
  const [trainings] = useState<ConformiaTraining[]>(mockDB.getConformiaTrainings());
  const [suppliers] = useState<Supplier[]>(mockDB.getSuppliers());
  const [dpias, setDpias] = useState<DPIA[]>(mockDB.getDPIAs());

  // New Governance Data States
  const [tprmAssessments, setTprmAssessments] = useState<ThirdPartyAssessment[]>([]);
  const [ropaLogs, setRopaLogs] = useState<DataSharingLog[]>([]);
  const [bcpPlans, setBcpPlans] = useState<BCPPlan[]>([]);
  
  // Simulation State
  const [simulatedIncident, setSimulatedIncident] = useState<IncidentSimulation | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  // Modals
  const [isTprmModalOpen, setIsTprmModalOpen] = useState(false);
  const [isRopaModalOpen, setIsRopaModalOpen] = useState(false);

  // Load Initial Data (Simulated for New Modules)
  useEffect(() => {
    // In a real scenario, fetch from Firestore
    // FirestoreService.getAll<ThirdPartyAssessment>('third_party_assessments').then(setTprmAssessments);
    // FirestoreService.getAll<DataSharingLog>('data_sharing_logs').then(setRopaLogs);
    
    // Mocking initial empty states or sample data if needed for MVP presentation
  }, []);

  // Dashboard Score Calculation (Existing Logic)
  const score = useMemo(() => {
    const invPct = (inventory.filter(i => i.status === 'MAPPED').length / (inventory.length || 1)) * 20;
    const basePct = (inventory.filter(i => !!i.legalBase).length / (inventory.length || 1)) * 15;
    const polPct = (policies.filter(p => p.status === 'PUBLISHED').length / (policies.length || 1)) * 15;
    const rightsPct = (requests.filter(r => r.status === 'RESPONDED').length / (requests.length || 1)) * 15;
    return Math.round(invPct + basePct + polPct + rightsPct + 25);
  }, [inventory, policies, requests]);

  const radarData = [
    { subject: 'Inventário', A: 85, fullMark: 100 },
    { subject: 'Políticas', A: 70, fullMark: 100 },
    { subject: 'Treinamento', A: 60, fullMark: 100 },
    { subject: 'Direitos', A: 90, fullMark: 100 },
    { subject: 'Terceiros', A: 45, fullMark: 100 },
    { subject: 'Incidentes', A: 100, fullMark: 100 },
  ];

  // --- NEW HANDLERS ---

  const handleCreateTPRM = (e: React.FormEvent) => {
    e.preventDefault();
    // Simplified Mock Creation
    const f = new FormData(e.target as HTMLFormElement);
    const answers = {
      hasDPO: f.get('hasDPO') === 'on',
      hasEncryption: f.get('hasEncryption') === 'on',
      hasIncidentPlan: f.get('hasIncidentPlan') === 'on',
      iso27001: f.get('iso27001') === 'on',
      dataRetentionPolicy: f.get('dataRetentionPolicy') === 'on'
    };
    
    const { score, level } = GovernanceService.calculateRiskScore(answers);
    
    const newAssessment: ThirdPartyAssessment = {
      id: `TPRM-${Date.now()}`,
      supplierId: f.get('supplierId') as string,
      supplierName: suppliers.find(s => s.id === f.get('supplierId'))?.companyName || 'Desconhecido',
      status: 'APPROVED',
      riskScore: score,
      riskLevel: level,
      questionnaire: answers,
      assessedBy: 'Sistema',
      assessedAt: new Date().toISOString()
    };

    setTprmAssessments([...tprmAssessments, newAssessment]);
    setIsTprmModalOpen(false);
    toast.success(`Risco calculado: ${level} (Score: ${score})`);
  };

  const handleCreateROPA = (e: React.FormEvent) => {
    e.preventDefault();
    const f = new FormData(e.target as HTMLFormElement);
    const newLog: DataSharingLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      senderId: 'Sistema',
      recipient: f.get('recipient') as string,
      dataCategories: (f.get('categories') as string).split(','),
      purpose: f.get('purpose') as string,
      legalBase: f.get('legalBase') as string,
      transferMechanism: 'API',
      encrypted: true
    };
    setRopaLogs([newLog, ...ropaLogs]);
    setIsRopaModalOpen(false);
    toast.success('Compartilhamento registrado no Log Imutável.');
  };

  const runSimulation = (scenario: string) => {
    setIsSimulating(true);
    setTimeout(() => {
      const result = GovernanceService.runIncidentSimulation(scenario);
      setSimulatedIncident(result);
      setIsSimulating(false);
      toast.info('Simulação concluída. Dados não persistidos.');
    }, 1500);
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-teal-600 text-white text-[10px] font-black rounded-full uppercase tracking-widest shadow-lg shadow-teal-500/20">Compliance v4.1</span>
            <ShieldCheck size={18} className="text-teal-500" />
          </div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Confor<span className="text-teal-500">mia</span></h2>
          <p className="text-teal-500 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Compliance Digital e Governança Integrada</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="rounded-2xl gap-2 border-teal-500/30 hover:bg-teal-50 text-teal-600"><Award size={18}/> Selo de Conformidade</Button>
          <Button className="rounded-2xl gap-2 bg-teal-600 hover:bg-teal-700 shadow-teal-500/40 font-black uppercase"><Download size={18}/> Relatório ROIP</Button>
        </div>
      </header>

      <nav className="flex p-1 glass rounded-[40px] w-full overflow-x-auto no-scrollbar shadow-xl border-teal-500/10">
        {[
          { id: 'DASH', label: 'Painel', icon: <Radar size={18}/> },
          { id: 'INVENTORY', label: 'Inventário', icon: <Activity size={18}/> },
          { id: 'RIGHTS', label: 'Direitos', icon: <Fingerprint size={18}/> },
          { id: 'TPRM', label: 'Risco Terceiros', icon: <Truck size={18}/> }, // Updated
          { id: 'ROPA', label: 'Data Sharing', icon: <Share2 size={18}/> }, // New
          { id: 'INCIDENTS', label: 'Incidentes', icon: <AlertTriangle size={18}/> },
          { id: 'BCP', label: 'Continuidade', icon: <Siren size={18}/> }, // New
          { id: 'MATURITY', label: 'Maturidade', icon: <BarChart3 size={18}/> }, // New
          { id: 'POLICIES', label: 'Políticas', icon: <FileText size={18}/> },
          { id: 'TRAINING', label: 'Treinamentos', icon: <Award size={18}/> },
          { id: 'DPIA', label: 'DPIA', icon: <Zap size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-6 py-5 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-teal-600 text-white shadow-xl shadow-teal-500/20' : 'text-slate-500 hover:text-teal-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <main className="animate-in slide-in-from-bottom-5 duration-700">
        {/* EXISTING DASHBOARD LOGIC PRESERVED */}
        {activeTab === 'DASH' && (
          <div className="space-y-10">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <Card className="xl:col-span-1 glass flex flex-col items-center justify-center py-12 hover:border-teal-500/30" title="Score de Conformidade">
                 <div className="relative w-48 h-48 mb-8">
                    <svg className="w-full h-full transform -rotate-90">
                       <circle cx="96" cy="96" r="80" fill="transparent" stroke="currentColor" strokeWidth="12" className="text-slate-100 dark:text-slate-800" />
                       <circle cx="96" cy="96" r="80" fill="transparent" stroke="currentColor" strokeWidth="12" strokeDasharray={502} strokeDashoffset={502 - (502 * score / 100)} className="text-teal-500 transition-all duration-1000" />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                       <span className="text-5xl font-black dark:text-white">{score}%</span>
                       <span className="text-[10px] font-black text-teal-500 uppercase tracking-widest mt-1">Conforme</span>
                    </div>
                 </div>
                 <div className="w-full grid grid-cols-2 gap-4 mt-6">
                    <div className="p-4 bg-teal-50 dark:bg-teal-900/10 rounded-2xl text-center">
                       <p className="text-[9px] font-black text-slate-400 uppercase">Meta Q3</p>
                       <p className="text-xl font-black text-teal-600">95%</p>
                    </div>
                    <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl text-center">
                       <p className="text-[9px] font-black text-slate-400 uppercase">Gap Atual</p>
                       <p className="text-xl font-black text-indigo-600">{100-score}%</p>
                    </div>
                 </div>
              </Card>

              <Card className="xl:col-span-2 glass hover:border-teal-500/30" title="Maturidade por Área" subtitle="Radar de Conformidade Digital">
                 <div className="h-[400px] mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                       <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                          <PolarGrid stroke="#e2e8f0" />
                          <PolarAngleAxis dataKey="subject" tick={{fontSize: 10, fontWeight: 800, fill: '#94a3b8'}} />
                          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                          <RechartsRadar name="Conformia" dataKey="A" stroke="#14b8a6" fill="#14b8a6" fillOpacity={0.4} />
                       </RadarChart>
                    </ResponsiveContainer>
                 </div>
              </Card>
            </div>
            {/* KPI Cards Preserved */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
               <Card className="border-l-4 border-l-rose-500" title="Incidentes Abertos">
                  <h3 className="text-4xl font-black text-rose-500">02</h3>
                  <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">SLA CRÍTICO (72h)</p>
               </Card>
               <Card className="border-l-4 border-l-amber-500" title="Solicitações Titulares">
                  <h3 className="text-4xl font-black text-amber-500">05</h3>
                  <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Pendente Análise</p>
               </Card>
               <Card className="border-l-4 border-l-teal-500" title="Políticas Vencidas">
                  <h3 className="text-4xl font-black text-teal-500">00</h3>
                  <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Status: Atualizadas</p>
               </Card>
               <Card className="border-l-4 border-l-indigo-500" title="Treinamento Staff">
                  <h3 className="text-4xl font-black text-indigo-500">78%</h3>
                  <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Engajamento Total</p>
               </Card>
            </div>
          </div>
        )}

        {/* EXISTING INVENTORY LOGIC PRESERVED */}
        {activeTab === 'INVENTORY' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
               <h3 className="text-2xl font-black dark:text-white">Inventário de Atividades de Tratamento (Data Mapping)</h3>
               <Button className="bg-teal-600 hover:bg-teal-700 font-black uppercase shadow-teal-500/20 gap-2"><Plus size={18}/> Mapear Novo Processo</Button>
            </div>
            <div className="grid grid-cols-1 gap-4">
               {inventory.map(act => (
                 <div key={act.id} className="p-8 rounded-[40px] glass flex items-center justify-between group hover:border-teal-500 transition-all">
                    <div className="flex items-center gap-6">
                       <div className="w-16 h-16 bg-teal-50 dark:bg-teal-900/20 rounded-3xl flex items-center justify-center text-teal-600"><Activity size={28}/></div>
                       <div>
                          <h4 className="text-xl font-black dark:text-white">{act.processName}</h4>
                          <div className="flex gap-2 mt-2">
                             <Badge color="slate">{act.moduleLink.toUpperCase()}</Badge>
                             <Badge color="emerald">{act.legalBase}</Badge>
                             {act.dataCategories.includes('SENSITIVE') && <Badge color="rose">DADOS SENSÍVEIS</Badge>}
                          </div>
                       </div>
                    </div>
                    <div className="flex items-center gap-10">
                       <div className="text-right">
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Status de Revisão</p>
                          <Badge color={act.status === 'MAPPED' ? 'emerald' : 'amber'}>{act.status}</Badge>
                       </div>
                       <Button variant="ghost" className="p-3 text-teal-600"><ChevronRight size={20}/></Button>
                    </div>
                 </div>
               ))}
            </div>
          </div>
        )}

        {/* EXISTING RIGHTS LOGIC PRESERVED */}
        {activeTab === 'RIGHTS' && (
          <div className="space-y-10">
            <Card title="Portal de Direitos do Titular" subtitle="Central de Solicitações LGPD" className="hover:border-teal-500/20">
               <div className="flex gap-4 mb-10">
                  <div className="flex-1 relative group">
                     <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-teal-500 transition-colors" />
                     <input className="w-full pl-14 pr-6 py-4 rounded-3xl glass bg-white/50 border-none text-sm font-bold focus:ring-4 focus:ring-teal-500/10" placeholder="Localizar titular por CPF ou Email no ecossistema GIRA..." />
                  </div>
                  <Button className="bg-teal-600 hover:bg-teal-700 px-8 font-black uppercase shadow-teal-500/20">Consultar Bases</Button>
               </div>
               <div className="overflow-x-auto rounded-[32px] border border-slate-100 dark:border-slate-800">
                  <table className="w-full text-left">
                     <thead>
                        <tr className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                           <th className="p-6">Solicitante</th>
                           <th className="p-6">Tipo de Direito</th>
                           <th className="p-6">Data Recebimento</th>
                           <th className="p-6 text-center">SLA Restante</th>
                           <th className="p-6 text-right">Ações</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100">
                        {requests.map(req => (
                          <tr key={req.id} className="hover:bg-teal-500/5 transition-colors group">
                             <td className="p-6">
                                <p className="font-black text-sm dark:text-white leading-tight">{req.subjectName}</p>
                                <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">{req.subjectEmail}</p>
                             </td>
                             <td className="p-6"><Badge color="emerald">{req.type}</Badge></td>
                             <td className="p-6 text-xs font-bold text-slate-500">{new Date(req.createdAt).toLocaleDateString()}</td>
                             <td className="p-6 text-center">
                                <Badge color="amber">08 Dias</Badge>
                             </td>
                             <td className="p-6 text-right">
                                <Button variant="ghost" className="text-teal-600 hover:bg-teal-50 rounded-xl font-black uppercase text-[10px]"><Zap size={16} className="mr-2"/> Atender</Button>
                             </td>
                          </tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </Card>
          </div>
        )}

        {/* --- NEW TPRM TAB --- */}
        {(activeTab === 'THIRD' || activeTab === 'TPRM') && (
          <div className="space-y-8">
             <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">TPRM - Gestão de Risco de Terceiros</h3>
                <div className="flex gap-4">
                  <Button variant="outline" onClick={() => setActiveTab('THIRD')} className={activeTab === 'THIRD' ? 'bg-teal-50 text-teal-600' : ''}>Visão Geral</Button>
                  <Button variant="outline" onClick={() => setActiveTab('TPRM')} className={activeTab === 'TPRM' ? 'bg-teal-50 text-teal-600' : ''}>Avaliações de Risco</Button>
                  <Button className="bg-teal-600 gap-2" onClick={() => setIsTprmModalOpen(true)}><Plus size={18}/> Nova Avaliação</Button>
                </div>
             </div>
             
             {activeTab === 'THIRD' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {suppliers.map(sup => (
                      <Card key={sup.id} className="glass hover:border-teal-500 transition-all group">
                        <div className="flex justify-between items-start mb-6">
                            <Badge color={sup.compliance?.dpaSigned ? 'emerald' : 'rose'}>{sup.compliance?.dpaSigned ? 'DPA Assinado' : 'DPA Pendente'}</Badge>
                            <Truck size={20} className="text-slate-300 group-hover:text-teal-500 transition-colors" />
                        </div>
                        <h4 className="text-lg font-black dark:text-white leading-tight mb-1 group-hover:text-teal-500 transition-colors">{sup.companyName}</h4>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">CNPJ: {sup.cnpj}</p>
                        <div className="mt-8 pt-6 border-t border-slate-50 dark:border-slate-800 space-y-4">
                            <div className="flex justify-between items-center text-xs font-bold">
                              <span className="text-slate-400 uppercase text-[9px]">Risco Compliance:</span>
                              <Badge color={sup.compliance?.riskLevel === 'CRITICAL' ? 'rose' : 'emerald'}>{sup.compliance?.riskLevel || 'BAIXO'}</Badge>
                            </div>
                        </div>
                      </Card>
                    ))}
                </div>
             )}

             {activeTab === 'TPRM' && (
                <Card className="glass border-none p-0 overflow-hidden">
                   <table className="w-full text-left">
                      <thead className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                         <tr>
                            <th className="p-6">Fornecedor</th>
                            <th className="p-6 text-center">Score Segurança</th>
                            <th className="p-6 text-center">Nível Risco</th>
                            <th className="p-6 text-center">Status</th>
                            <th className="p-6 text-right">Data Avaliação</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                         {tprmAssessments.map(tp => (
                            <tr key={tp.id} className="hover:bg-slate-50">
                               <td className="p-6 font-bold text-sm">{tp.supplierName}</td>
                               <td className="p-6 text-center font-black text-slate-600">{tp.riskScore}/100</td>
                               <td className="p-6 text-center"><Badge color={tp.riskLevel === 'LOW' ? 'emerald' : tp.riskLevel === 'MEDIUM' ? 'amber' : 'rose'}>{tp.riskLevel}</Badge></td>
                               <td className="p-6 text-center"><Badge color="slate">{tp.status}</Badge></td>
                               <td className="p-6 text-right text-xs text-slate-400">{new Date(tp.assessedAt).toLocaleDateString()}</td>
                            </tr>
                         ))}
                         {tprmAssessments.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-slate-400 text-xs">Nenhuma avaliação realizada.</td></tr>}
                      </tbody>
                   </table>
                </Card>
             )}
          </div>
        )}

        {/* --- NEW ROPA TAB --- */}
        {activeTab === 'ROPA' && (
           <div className="space-y-8">
              <div className="flex justify-between items-center">
                 <h3 className="text-2xl font-black dark:text-white">Rastreabilidade de Dados (Data Sharing Log)</h3>
                 <Button className="bg-teal-600 gap-2" onClick={() => setIsRopaModalOpen(true)}><Share2 size={18}/> Registrar Compartilhamento</Button>
              </div>
              <div className="space-y-4">
                 {ropaLogs.map(log => (
                    <div key={log.id} className="p-6 rounded-3xl glass border-l-4 border-l-teal-500 flex justify-between items-center">
                       <div className="flex items-center gap-6">
                          <div className="w-12 h-12 bg-teal-50 rounded-2xl flex items-center justify-center text-teal-600"><Network size={24}/></div>
                          <div>
                             <h4 className="font-black text-sm dark:text-white">Destino: {log.recipient}</h4>
                             <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">Finalidade: {log.purpose}</p>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          {log.dataCategories.map((cat, i) => <Badge key={i} color="slate">{cat}</Badge>)}
                          <Badge color="emerald">{log.transferMechanism}</Badge>
                       </div>
                       <div className="text-right">
                          <p className="text-[10px] text-slate-400 font-bold uppercase">Timestamp Imutável</p>
                          <p className="text-xs font-black text-slate-600">{new Date(log.timestamp).toLocaleString()}</p>
                       </div>
                    </div>
                 ))}
                 {ropaLogs.length === 0 && <div className="py-20 text-center glass rounded-3xl"><Database size={48} className="mx-auto text-slate-200 mb-4"/><p className="text-slate-400 font-bold">Nenhum log de transferência registrado.</p></div>}
              </div>
           </div>
        )}

        {/* --- NEW MATURITY TAB --- */}
        {activeTab === 'MATURITY' && (
           <div className="space-y-8">
              <div className="flex justify-between items-center">
                 <h3 className="text-2xl font-black dark:text-white">Avaliação de Maturidade LGPD</h3>
                 <Badge color="teal">Ciclo 2024 - Q2</Badge>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                 <Card title="Gráfico de Radar (Assessment)" className="glass">
                    <div className="h-[300px]">
                       <ResponsiveContainer width="100%" height="100%">
                          <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                             <PolarGrid stroke="#e2e8f0" />
                             <PolarAngleAxis dataKey="subject" />
                             <PolarRadiusAxis angle={30} domain={[0, 100]} />
                             <RechartsRadar name="Maturidade Atual" dataKey="A" stroke="#0d9488" fill="#0d9488" fillOpacity={0.5} />
                             <Legend />
                          </RadarChart>
                       </ResponsiveContainer>
                    </div>
                 </Card>
                 <div className="space-y-4">
                    <div className="p-6 rounded-3xl bg-teal-600 text-white shadow-xl">
                       <h4 className="text-lg font-black uppercase tracking-widest mb-2">Score Geral</h4>
                       <span className="text-5xl font-black">78/100</span>
                       <p className="text-xs opacity-80 mt-2">Nível: Gerenciado e Mensurável</p>
                    </div>
                    <div className="p-6 rounded-3xl glass border border-slate-100">
                       <h4 className="text-sm font-black text-slate-600 mb-4">Recomendações Automáticas</h4>
                       <ul className="space-y-2 text-xs text-slate-500">
                          <li className="flex gap-2"><CheckCircle2 size={14} className="text-teal-500"/> Formalizar Política de Retenção de Dados</li>
                          <li className="flex gap-2"><CheckCircle2 size={14} className="text-teal-500"/> Automatizar exclusão de dados inativos</li>
                          <li className="flex gap-2"><CheckCircle2 size={14} className="text-teal-500"/> Realizar teste de intrusão (Pentest) anual</li>
                       </ul>
                    </div>
                 </div>
              </div>
           </div>
        )}

        {/* --- NEW BCP TAB (Continuity) --- */}
        {activeTab === 'BCP' && (
           <div className="space-y-8">
              <div className="flex justify-between items-center">
                 <h3 className="text-2xl font-black dark:text-white">Continuidade de Negócios & Resposta a Incidentes</h3>
                 <div className="flex gap-2">
                    <Button variant="outline" className="border-teal-500/30 text-teal-600" onClick={() => runSimulation('RANSOMWARE')} disabled={isSimulating}>Simular Ransomware</Button>
                    <Button variant="outline" className="border-teal-500/30 text-teal-600" onClick={() => runSimulation('DATA_LEAK')} disabled={isSimulating}>Simular Vazamento</Button>
                 </div>
              </div>

              {isSimulating && <div className="py-20 text-center"><RefreshCw className="animate-spin mx-auto text-teal-500" size={48}/><p className="mt-4 font-black text-teal-600 uppercase tracking-widest">Rodando Simulação em Sandbox Isolado...</p></div>}

              {simulatedIncident && !isSimulating && (
                 <div className="animate-in slide-in-from-top-10 duration-500">
                    <div className={`p-8 rounded-[40px] border-l-8 ${simulatedIncident.severity === 'CRITICAL' ? 'bg-rose-50 border-rose-600' : 'bg-amber-50 border-amber-500'} mb-8`}>
                       <div className="flex items-start gap-6">
                          <Siren size={32} className={simulatedIncident.severity === 'CRITICAL' ? 'text-rose-600' : 'text-amber-600'} />
                          <div className="flex-1">
                             <div className="flex justify-between items-center mb-4">
                                <h4 className="text-2xl font-black text-slate-800">Relatório de Simulação: {simulatedIncident.scenario}</h4>
                                <Badge color={simulatedIncident.severity === 'CRITICAL' ? 'rose' : 'amber'}>{simulatedIncident.severity}</Badge>
                             </div>
                             <div className="grid grid-cols-2 gap-8 mb-6">
                                <div>
                                   <p className="text-[10px] font-black uppercase text-slate-400">Sistemas Afetados</p>
                                   <ul className="list-disc ml-4 text-sm font-bold text-slate-600">
                                      {simulatedIncident.affectedSystems.map(s => <li key={s}>{s}</li>)}
                                   </ul>
                                </div>
                                <div>
                                   <p className="text-[10px] font-black uppercase text-slate-400">Perda de Dados Estimada</p>
                                   <p className="text-xl font-black text-slate-700">{simulatedIncident.estimatedDataLoss}</p>
                                </div>
                             </div>
                             <div className="p-4 bg-white/50 rounded-2xl">
                                <p className="text-[10px] font-black uppercase text-slate-400 mb-2">Playbook Recomendado</p>
                                {simulatedIncident.recommendedActions.map((action, i) => (
                                   <div key={i} className="flex gap-2 items-center text-xs font-bold text-slate-600 mb-1">
                                      <span className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center text-[10px]">{i+1}</span>
                                      {action}
                                   </div>
                                ))}
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
              )}

              <Card title="Planos de Continuidade Ativos (BCP)" className="glass">
                 <div className="space-y-4">
                    <div className="p-4 rounded-2xl bg-white/50 border border-slate-100 flex justify-between items-center">
                       <div>
                          <h5 className="font-black text-sm">BCP-01: Indisponibilidade Cloud</h5>
                          <p className="text-[10px] text-slate-400 uppercase font-bold">RTO: 4h • RPO: 1h</p>
                       </div>
                       <Badge color="emerald">Testado em 10/05/2024</Badge>
                    </div>
                    <div className="p-4 rounded-2xl bg-white/50 border border-slate-100 flex justify-between items-center">
                       <div>
                          <h5 className="font-black text-sm">BCP-02: Ataque Cibernético</h5>
                          <p className="text-[10px] text-slate-400 uppercase font-bold">RTO: 24h • RPO: 4h</p>
                       </div>
                       <Badge color="amber">Teste Pendente</Badge>
                    </div>
                 </div>
              </Card>
           </div>
        )}

        {/* INCIDENTS TAB (Original preserved) */}
        {activeTab === 'INCIDENTS' && (
          <div className="space-y-10">
             <Card title="Registro de Violações de Dados" action={<Button variant="danger" className="rounded-2xl px-6 font-black uppercase"><AlertTriangle size={18} className="mr-2"/> Notificar Violação</Button>} className="hover:border-rose-500/20 transition-all">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
                   <div className="p-6 bg-rose-50 dark:bg-rose-900/10 rounded-3xl text-center border border-rose-100">
                      <span className="text-3xl font-black text-rose-600">02</span>
                      <p className="text-[9px] font-black text-slate-400 uppercase mt-1">Abertos</p>
                   </div>
                   {/* ... rest of original incident cards ... */}
                </div>
                {/* ... incident list ... */}
             </Card>
          </div>
        )}

        {/* POLICIES, TRAINING, DPIA Tabs (Preserved logic in render blocks) */}
        {activeTab === 'POLICIES' && (
          <div className="space-y-8">
             <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Biblioteca de Governança e Políticas</h3>
                <Button className="bg-teal-600 hover:bg-teal-700 font-black uppercase shadow-teal-500/20"><Plus size={18} className="mr-2"/> Nova Política</Button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {policies.map(pol => (
                  <Card key={pol.id} className="glass hover:border-teal-500 transition-all group">
                     <div className="flex justify-between mb-4">
                        <Badge color="emerald">{pol.category}</Badge>
                        <Badge color="slate">v{pol.version}</Badge>
                     </div>
                     <h4 className="text-xl font-black dark:text-white leading-tight mb-4 group-hover:text-teal-500 transition-colors">{pol.title}</h4>
                     <div className="mt-8 pt-4 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                        <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Revisão: {pol.nextReview}</div>
                        <Button variant="ghost" className="p-2 text-teal-600 hover:bg-teal-50 rounded-xl"><Eye size={16}/></Button>
                     </div>
                  </Card>
                ))}
             </div>
          </div>
        )}

        {activeTab === 'TRAINING' && (
          <div className="space-y-10">
             <Card title="Plataforma de Capacitação em Privacidade" subtitle="Cultura de Proteção de Dados ATIS" className="hover:border-teal-500/20">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                   <div className="lg:col-span-2 space-y-6">
                      {trainings.map(tr => (
                        <div key={tr.id} className="p-8 rounded-[40px] glass border-l-8 border-l-teal-600 flex items-center justify-between group hover:border-teal-500 transition-all">
                           <div className="flex items-center gap-6">
                              <div className="w-16 h-16 bg-teal-50 dark:bg-teal-900/20 rounded-3xl flex items-center justify-center text-teal-600 group-hover:scale-110 transition-transform"><Award size={28}/></div>
                              <div>
                                 <h5 className="text-xl font-black dark:text-white leading-tight">{tr.title}</h5>
                                 <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-widest">{tr.theme} • Nota Mínima: {tr.minScore}%</p>
                              </div>
                           </div>
                           <Button className="bg-teal-600 hover:bg-teal-700 rounded-2xl h-12 font-black uppercase">Iniciar</Button>
                        </div>
                      ))}
                   </div>
                   {/* ... rest of training logic ... */}
                </div>
             </Card>
          </div>
        )}

        {activeTab === 'DPIA' && (
          <div className="space-y-8">
             <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Relatórios de Impacto (DPIA / RIPD)</h3>
                <Button className="bg-teal-600 hover:bg-teal-700 font-black uppercase shadow-teal-500/20 gap-2"><Zap size={18}/> Novo DPIA</Button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {dpias.map(dpia => (
                  <Card key={dpia.id} className="glass hover:border-teal-500 transition-all group" title={`DPIA v${dpia.version}`} action={<Badge color="emerald">{dpia.status}</Badge>}>
                      <p className="text-sm font-bold text-slate-500 dark:text-slate-400 mb-6 line-clamp-2 leading-relaxed">"{dpia.steps.identification}"</p>
                      <div className="flex justify-between items-center pt-4 border-t border-slate-50 dark:border-slate-800">
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Atualizado: {dpia.updatedAt}</span>
                        <Button variant="ghost" className="text-teal-600 hover:bg-teal-50 rounded-xl font-black uppercase text-[10px]"><FileText size={16} className="mr-2"/> Abrir</Button>
                      </div>
                  </Card>
                ))}
             </div>
          </div>
        )}
      </main>

      {/* --- NEW MODALS --- */}
      
      {/* TPRM Modal */}
      <Modal isOpen={isTprmModalOpen} onClose={() => setIsTprmModalOpen(false)} title="Nova Avaliação de Risco (TPRM)">
         <form onSubmit={handleCreateTPRM} className="space-y-6">
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Fornecedor Alvo</label>
               <select name="supplierId" className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                  {suppliers.map(s => <option key={s.id} value={s.id}>{s.companyName}</option>)}
               </select>
            </div>
            
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
               <h4 className="font-black text-sm text-slate-700 uppercase">Checklist de Segurança</h4>
               <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" name="iso27001" className="w-5 h-5 rounded border-slate-300 text-teal-600" />
                  <span className="text-xs font-bold text-slate-600">Possui Certificação ISO 27001</span>
               </label>
               <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" name="hasDPO" className="w-5 h-5 rounded border-slate-300 text-teal-600" />
                  <span className="text-xs font-bold text-slate-600">Encarregado (DPO) Nomeado</span>
               </label>
               <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" name="hasEncryption" className="w-5 h-5 rounded border-slate-300 text-teal-600" />
                  <span className="text-xs font-bold text-slate-600">Criptografia em Repouso e Trânsito</span>
               </label>
               <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" name="hasIncidentPlan" className="w-5 h-5 rounded border-slate-300 text-teal-600" />
                  <span className="text-xs font-bold text-slate-600">Plano de Resposta a Incidentes</span>
               </label>
               <label className="flex items-center gap-3 cursor-pointer">
                  <input type="checkbox" name="dataRetentionPolicy" className="w-5 h-5 rounded border-slate-300 text-teal-600" />
                  <span className="text-xs font-bold text-slate-600">Política de Retenção e Descarte</span>
               </label>
            </div>

            <div className="flex justify-end gap-2">
               <Button type="button" variant="outline" onClick={() => setIsTprmModalOpen(false)}>Cancelar</Button>
               <Button type="submit" className="bg-teal-600">Calcular Risco</Button>
            </div>
         </form>
      </Modal>

      {/* ROPA Modal */}
      <Modal isOpen={isRopaModalOpen} onClose={() => setIsRopaModalOpen(false)} title="Registro de Transferência">
         <form onSubmit={handleCreateROPA} className="space-y-6">
            <Input label="Destinatário / Terceiro" name="recipient" required placeholder="Ex: Provedor de Nuvem X" />
            <Input label="Categorias de Dados" name="categories" required placeholder="Ex: CPF, Email, Biometria" />
            <Input label="Finalidade do Compartilhamento" name="purpose" required />
            <div className="space-y-1">
               <label className="text-[10px] font-black text-slate-400 uppercase">Base Legal</label>
               <select name="legalBase" className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                  <option value="Execução de Contrato">Execução de Contrato</option>
                  <option value="Legítimo Interesse">Legítimo Interesse</option>
                  <option value="Obrigação Legal">Obrigação Legal</option>
               </select>
            </div>
            <div className="flex justify-end gap-2">
               <Button type="button" variant="outline" onClick={() => setIsRopaModalOpen(false)}>Cancelar</Button>
               <Button type="submit" className="bg-teal-600">Registrar Log</Button>
            </div>
         </form>
      </Modal>

      <footer className="text-center pt-20 border-t border-teal-500/10">
         <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.4em]">CONFORMIA — Compliance Digital e LGPD. Integrado ao GIRA CEAP.</p>
         <p className="text-[10px] text-slate-300 font-bold uppercase tracking-[0.2em] mt-2">Desenvolvido pela Área de Tecnologia e Inovação Social (ATIS) do Centro de Articulação de Populações Marginalizadas (CEAP).</p>
      </footer>
    </div>
  );
};

import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Modal, Badge, useToast, FileUpload } from '../components/UI';
import { 
  Plus, Search, Filter, MoreVertical, Edit2, Shield, 
  Power, History, ShieldAlert, Users as UsersIcon, 
  Settings, Terminal, Download, UserPlus, 
  ChevronRight, CheckCircle2, Lock, Activity,
  Globe, Fingerprint, Eye, Trash2, ShieldCheck,
  Zap, Copy, ArrowRightLeft, AlertTriangle, Loader2, Info
} from 'lucide-react';
import { mockDB } from '../services/mockDB';
import { User, Role, UserStatus, RoleType, AuditLog } from '../types';
import { AuditService } from '../services/AuditService';
import { FirestoreService } from '../services/FirestoreService';
import { useAuth } from '../context/AuthContext';

export const Users: React.FC = () => {
  const toast = useToast();
  const { currentUser: loggedUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'EMPLOYEES' | 'RBAC' | 'AUDIT'>('EMPLOYEES');
  
  // States - Data
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // States - Selection & UI
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editingRole, setEditingRole] = useState<Role | null>(null);
  const [onboardingStep, setOnboardingStep] = useState(1);
  const [isSaving, setIsSaving] = useState(false);

  const loadAllData = async () => {
    setIsLoading(true);
    try {
      // Migração: Agora buscamos users do Firestore, não do mockDB
      const [u, r, l] = await Promise.all([
        FirestoreService.getAll<User>('users'),
        mockDB.getRoles(), // Roles ainda podem vir do mock ou migrados futuramente
        FirestoreService.getAll<AuditLog>('auditLogs')
      ]);
      setUsers(u);
      setRoles(r);
      // Ordenar logs por timestamp descendente
      setLogs(l.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    } catch (e) {
      toast.error("Falha ao sincronizar com o nodo de dados.");
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const filteredUsers = useMemo(() => {
    return users.filter(u => 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.department?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [users, searchTerm]);

  const toggleUserSelection = (id: string) => {
    setSelectedUsers(prev => 
      prev.includes(id) ? prev.filter(uid => uid !== id) : [...prev, id]
    );
  };

  const handleSaveUser = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    // O ID é mantido se edição, ou null se novo (Firestore gera o ID automaticamente se null, 
    // mas aqui queremos vincular futura Auth, então geramos um temp ID se não tiver Auth UID ainda)
    const targetId = editingUser?.id || null;

    const newUserPayload = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      // cpf: formData.get('cpf') as string, // Campo opcional
      roleId: formData.get('roleId') as string,
      department: formData.get('department') as string,
      position: formData.get('position') as string,
      status: editingUser?.status || UserStatus.PENDING, // Novos usuários iniciam como Pendentes até login
      mfaEnabled: true,
      photoURL: editingUser?.photoURL || `https://ui-avatars.com/api/?name=${formData.get('name')}&background=4f46e5&color=fff&bold=true`
    };
    
    try {
      // Salva no Firestore ('users')
      await FirestoreService.save('users', targetId, newUserPayload);
      
      // NOVO: Auditoria via AuditService
      await AuditService.log({
        userId: loggedUser?.id || 'sys',
        userName: loggedUser?.name || 'Sistema',
        action: editingUser ? 'UPDATE_USER' : 'CREATE_USER',
        module: 'IDENTITY',
        details: `${editingUser ? 'Atualizado' : 'Pré-cadastrado'} perfil do colaborador: ${newUserPayload.name}`,
        criticality: editingUser ? 'INFO' : 'WARN'
      });

      await loadAllData();
      setIsSaving(false);
      setIsUserModalOpen(false);
      setEditingUser(null);
      
      if (!editingUser) {
        toast.success('Perfil pré-cadastrado! Instrua o colaborador a se registrar com este e-mail.');
      } else {
        toast.success('Perfil atualizado na matriz Cloud.');
      }
    } catch (error) {
      toast.error('Erro ao salvar dados na nuvem.');
      console.error(error);
      setIsSaving(false);
    }
  };

  const handleSaveRole = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    const newRole: Role = {
      id: editingRole?.id || crypto.randomUUID(),
      name: formData.get('name') as string,
      description: formData.get('description') as string,
      type: formData.get('type') as RoleType,
      level: Number(formData.get('level')),
      financialLimit: Number(formData.get('financialLimit')),
      permissions: editingRole?.permissions || [],
      icon: editingRole?.icon || 'Shield',
      color: editingRole?.color || 'bg-slate-500'
    };
    
    await mockDB.saveRole(newRole);

    await AuditService.log({
      userId: loggedUser?.id || 'sys',
      userName: loggedUser?.name || 'Sistema',
      action: 'UPDATE_ROLE_PERMISSIONS',
      module: 'IDENTITY',
      details: `Reconfiguração do papel institucional: ${newRole.name}`,
      criticality: 'CRITICAL'
    });

    await loadAllData();
    setIsSaving(false);
    setIsRoleModalOpen(false);
    setEditingRole(null);
    toast.success('Papel institucional reconfigurado com sucesso.');
  };

  if (isLoading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-12 h-12 text-indigo-600 animate-spin opacity-20" />
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Sincronizando Identidades...</p>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Identidade & <span className="text-indigo-500">Governança</span></h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Padrão Identity Management Cloud v4.0</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="rounded-2xl gap-2 border-indigo-500/20 text-indigo-600 hover:bg-indigo-50"><Download size={18}/> Exportar Relatório</Button>
          <Button onClick={() => { setEditingUser(null); setOnboardingStep(1); setIsUserModalOpen(true); }} className="rounded-2xl gap-2 h-14 px-10 bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20 font-black uppercase">
            <UserPlus size={20} /> Admitir Digitalmente
          </Button>
        </div>
      </header>

      <nav className="flex p-1 glass rounded-[40px] w-fit overflow-x-auto no-scrollbar shadow-xl border-white/20">
        {[
          { id: 'EMPLOYEES', label: 'Colaboradores', icon: <UsersIcon size={18}/> },
          { id: 'RBAC', label: 'Matriz RBAC', icon: <Shield size={18}/> },
          { id: 'AUDIT', label: 'Logs de Auditoria', icon: <Terminal size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-xs font-black transition-all shrink-0 ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-500 hover:text-indigo-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <main className="animate-in slide-in-from-bottom-5 duration-700">
        {activeTab === 'EMPLOYEES' && (
          <div className="space-y-10">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1 relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="text" 
                  placeholder="Pesquisar por nome, email, departamento ou cargo..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-14 pr-6 py-5 rounded-[32px] border-none glass bg-white/40 dark:bg-slate-800/40 focus:ring-4 focus:ring-indigo-500/10 transition-all font-bold text-sm dark:text-white"
                />
              </div>
              <div className="flex gap-4">
                <Button variant="outline" className="rounded-2xl h-16 px-8 border-indigo-500/20 text-indigo-600"><Filter size={18} /> Filtros Avançados</Button>
                {selectedUsers.length > 0 && (
                  <Button variant="danger" className="rounded-2xl h-16 px-8 animate-in zoom-in duration-300">
                    <Power size={18}/> Bloquear ({selectedUsers.length})
                  </Button>
                )}
              </div>
            </div>

            <Card className="p-0 glass border-none overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.3em] border-b border-slate-100 dark:border-slate-800 bg-white/20 dark:bg-black/20">
                      <th className="py-6 px-8 w-12"><input type="checkbox" className="rounded border-slate-300" onChange={(e) => e.target.checked ? setSelectedUsers(users.map(u => u.id)) : setSelectedUsers([])} /></th>
                      <th className="py-6 px-8">Colaborador / Identidade</th>
                      <th className="py-6 px-8">Papel Institucional</th>
                      <th className="py-6 px-8">Acessos</th>
                      <th className="py-6 px-8 text-center">Status Entra</th>
                      <th className="py-6 px-8 text-right">Ações de Governança</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                    {filteredUsers.map(user => {
                      const role = roles.find(r => r.id === user.roleId);
                      const isSelected = selectedUsers.includes(user.id);
                      return (
                        <tr key={user.id} className={`hover:bg-indigo-500/[0.03] transition-all duration-300 group ${isSelected ? 'bg-indigo-500/[0.05]' : ''}`}>
                          <td className="py-6 px-8"><input type="checkbox" checked={isSelected} onChange={() => toggleUserSelection(user.id)} className="rounded border-slate-300" /></td>
                          <td className="py-6 px-8">
                            <div className="flex items-center gap-5">
                              <img src={user.photoURL} className="w-14 h-14 rounded-2xl object-cover border-4 border-white dark:border-slate-900 shadow-xl group-hover:scale-110 transition-transform" />
                              <div>
                                <p className="font-black text-slate-800 dark:text-white leading-tight">{user.name}</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">{user.position} • {user.department}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-6 px-8">
                            <div className="flex flex-col">
                              <span className="text-sm font-black text-slate-700 dark:text-slate-300">{role?.name}</span>
                              <span className="text-[9px] text-indigo-500 font-black uppercase tracking-widest mt-1">{role?.type}</span>
                            </div>
                          </td>
                          <td className="py-6 px-8">
                             <div className="flex items-center gap-2">
                                <Badge color="indigo">{role?.id === 'superadmin' ? 'Total (11/11)' : `${role?.permissions.length || 0}/11`}</Badge>
                                {user.mfaEnabled && <Fingerprint size={14} className="text-emerald-500" />}
                             </div>
                             <p className="text-[9px] text-slate-400 font-bold mt-2">
                               {user.lastAccess ? `Visto: ${new Date(user.lastAccess).toLocaleDateString()}` : 'Nunca acessou'}
                             </p>
                          </td>
                          <td className="py-6 px-8 text-center">
                            <Badge color={user.status === UserStatus.ACTIVE ? 'emerald' : user.status === UserStatus.BLOCKED ? 'rose' : user.status === UserStatus.VACATION ? 'amber' : 'slate'}>
                              {user.status}
                            </Badge>
                          </td>
                          <td className="py-6 px-8 text-right">
                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                              <Button variant="ghost" className="p-3 glass rounded-xl" onClick={() => { setEditingUser(user); setOnboardingStep(2); setIsUserModalOpen(true); }}><Edit2 size={16} className="text-indigo-600"/></Button>
                              <Button variant="ghost" className="p-3 glass rounded-xl"><History size={16}/></Button>
                              <Button variant="ghost" className="p-3 glass rounded-xl text-rose-500"><Power size={16}/></Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'RBAC' && (
          <div className="space-y-12">
            <div className="flex flex-col md:flex-row justify-between items-end gap-6">
              <div>
                <h3 className="text-3xl font-black dark:text-white">Matriz de Permissões Críticas</h3>
                <p className="text-indigo-500 font-bold text-xs uppercase tracking-widest mt-2">Configuração Granular de Acesso por Módulo</p>
              </div>
              <Button onClick={() => { setEditingRole(null); setIsRoleModalOpen(true); }} className="rounded-2xl gap-2 h-14 px-8 bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20 font-black uppercase"><Plus size={18}/> Novo Papel Institucional</Button>
            </div>

            <Card className="p-0 glass border-none overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-center min-w-[1200px]">
                  <thead>
                    <tr className="bg-white/20 dark:bg-black/20 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <th className="py-8 px-10 text-left w-64 border-r border-slate-100 dark:border-slate-800">Papel / Módulo</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">Painel</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">Financeiro</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">Suprimentos</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">Projetos</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">GED</th>
                      <th className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">Identidade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                    {roles.map(role => (
                      <tr key={role.id} className="hover:bg-indigo-500/[0.02] transition-colors group">
                        <td className="py-8 px-10 text-left border-r border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-4">
                             <div className={`w-10 h-10 rounded-xl ${role.color || 'bg-slate-500'} flex items-center justify-center text-white shadow-lg`}><Shield size={20}/></div>
                             <div>
                                <p className="font-black text-slate-800 dark:text-white leading-none">{role.name}</p>
                                <button onClick={() => { setEditingRole(role); setIsRoleModalOpen(true); }} className="text-[9px] text-indigo-500 font-black uppercase mt-2 hover:underline tracking-widest">Editar Definição</button>
                             </div>
                          </div>
                        </td>
                        {['dashboard','finance','supplies','projects','docs','users'].map(mod => (
                          <td key={`${role.id}-${mod}`} className="py-8 px-4 border-r border-slate-100 dark:border-slate-800">
                             <div className="flex justify-center">
                                <div className={`w-3 h-3 rounded-full ${role.permissions.includes('*') || role.permissions.some(p => p.startsWith(mod)) ? 'bg-emerald-500 shadow-emerald-500/50' : 'bg-slate-200 dark:bg-slate-700'}`}></div>
                             </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'AUDIT' && (
          <div className="space-y-10">
            <div className="flex flex-col md:flex-row justify-between items-end gap-6">
              <div>
                <h3 className="text-3xl font-black dark:text-white">Auditoria Centralizada (Cloud)</h3>
                <p className="text-indigo-500 font-bold text-xs uppercase tracking-widest mt-2">Log de Eventos e Trilha de Conformidade Firestore</p>
              </div>
            </div>
            <Card className="p-0 glass border-none overflow-hidden">
               <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b bg-white/20 dark:bg-black/20">
                        <th className="py-6 px-8">Data / Hora</th>
                        <th className="py-6 px-8">Usuário</th>
                        <th className="py-6 px-8">Módulo</th>
                        <th className="py-6 px-8">Ação Executada</th>
                        <th className="py-6 px-8 text-center">Criticidade</th>
                        <th className="py-6 px-8 text-right">IP Origem</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                      {logs.map(log => (
                        <tr key={log.id} className="hover:bg-indigo-500/[0.03] transition-colors group">
                           <td className="py-6 px-8">
                             <p className="text-xs font-black dark:text-white">{new Date(log.timestamp).toLocaleDateString()}</p>
                             <p className="text-[9px] text-slate-400 font-bold">{new Date(log.timestamp).toLocaleTimeString()}</p>
                           </td>
                           <td className="py-6 px-8">
                             <p className="text-sm font-black dark:text-white">{log.userName}</p>
                           </td>
                           <td className="py-6 px-8">
                             <Badge color="slate">{log.module}</Badge>
                           </td>
                           <td className="py-6 px-8">
                             <p className="text-sm font-black text-indigo-600">{log.action}</p>
                             <p className="text-[10px] text-slate-500 truncate max-w-[300px]">{log.details}</p>
                           </td>
                           <td className="py-6 px-8 text-center">
                              <Badge color={log.criticality === 'CRITICAL' ? 'rose' : log.criticality === 'WARN' ? 'amber' : 'indigo'}>{log.criticality}</Badge>
                           </td>
                           <td className="py-6 px-8 text-right">
                             <span className="text-[10px] font-bold text-slate-400">{log.ip}</span>
                           </td>
                        </tr>
                      ))}
                      {logs.length === 0 && (
                        <tr>
                          <td colSpan={6} className="py-20 text-center opacity-40 font-black uppercase text-xs tracking-widest">Nenhum log de auditoria encontrado na nuvem</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
               </div>
            </Card>
          </div>
        )}
      </main>

      {/* MODAL ADMISSÃO */}
      <Modal isOpen={isUserModalOpen} onClose={() => setIsUserModalOpen(false)} title="Onboarding de Colaborador" size="2xl">
         <form onSubmit={handleSaveUser} className="space-y-10">
            {onboardingStep === 1 && (
               <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                     <Input label="Nome Completo" name="name" required defaultValue={editingUser?.name} />
                     <Input label="Email Institucional" name="email" type="email" required defaultValue={editingUser?.email} />
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                     <Input label="Departamento" name="department" required defaultValue={editingUser?.department} />
                     <Input label="Cargo" name="position" required defaultValue={editingUser?.position} />
                  </div>
                  <div className="flex justify-end">
                     <Button type="button" onClick={() => setOnboardingStep(2)}>Próximo Passo</Button>
                  </div>
               </div>
            )}
            {onboardingStep === 2 && (
               <div className="space-y-6">
                  <div className="space-y-4">
                     <label className="text-[10px] font-black uppercase text-slate-400">Selecionar Perfil</label>
                     <div className="grid grid-cols-2 gap-4">
                        {roles.map(r => (
                           <label key={r.id} className="p-4 border-2 rounded-2xl cursor-pointer hover:border-indigo-500 flex items-center gap-3">
                              <input type="radio" name="roleId" value={r.id} required defaultChecked={editingUser?.roleId === r.id} />
                              <span className="font-bold text-sm">{r.name}</span>
                           </label>
                        ))}
                     </div>
                  </div>
                  <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl border border-indigo-100 flex gap-4">
                    <Info className="text-indigo-600 shrink-0" size={20} />
                    <p className="text-xs text-indigo-800 dark:text-indigo-300">
                      Ao finalizar, um perfil será criado no Firestore. O usuário deverá realizar o "Registro" no login usando o mesmo e-mail para ativar a conta.
                    </p>
                  </div>
                  <div className="flex justify-between">
                     <Button type="button" variant="outline" onClick={() => setOnboardingStep(1)}>Voltar</Button>
                     <Button type="submit" loading={isSaving}>Finalizar Admissão</Button>
                  </div>
               </div>
            )}
         </form>
      </Modal>

      {/* MODAL ROLE */}
      <Modal isOpen={isRoleModalOpen} onClose={() => setIsRoleModalOpen(false)} title={editingRole ? 'Editar Papel' : 'Novo Papel Institucional'}>
         <form onSubmit={handleSaveRole} className="space-y-6">
            <Input label="Nome do Papel" name="name" defaultValue={editingRole?.name} required />
            <Input label="Descrição" name="description" defaultValue={editingRole?.description} required />
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Tipo</label>
                  <select name="type" defaultValue={editingRole?.type || RoleType.INTERNAL} className="w-full p-3 rounded-xl glass border-none font-bold text-sm">
                     <option value={RoleType.INTERNAL}>Interno</option>
                     <option value={RoleType.EXTERNAL}>Externo</option>
                  </select>
               </div>
               <Input label="Nível Hierárquico" name="level" type="number" defaultValue={editingRole?.level || 1} required />
            </div>
            <Input label="Limite Financeiro (R$)" name="financialLimit" type="number" defaultValue={editingRole?.financialLimit || 0} required />
            <div className="flex justify-end gap-2 pt-4">
               <Button type="button" variant="outline" onClick={() => setIsRoleModalOpen(false)}>Cancelar</Button>
               <Button type="submit" loading={isSaving}>Salvar</Button>
            </div>
         </form>
      </Modal>
    </div>
  );
};


import React, { useState, useEffect, useRef } from 'react';
import { Card, Button, Badge } from '../components/UI';
import { Sparkles, Send, Activity, BrainCircuit } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const AI: React.FC = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'Saudações, Gestor. Sou o núcleo cognitivo ATIS. Analisando fluxos institucionais... Como posso auxiliar hoje?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      // Fix: Direct use of process.env.API_KEY as per guidelines
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: 'Você é o Módulo Cognitivo do GIRA CEAP. Você é focado em análise tática, gestão social e eficiência de recursos. Ajude o gestor com dados simulados ou análises de processos.'
        }
      });
      setMessages(prev => [...prev, { role: 'ai', text: response.text || 'Protocolo interrompido.' }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Matriz indisponível. Verifique conexão neural.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-[calc(100vh-200px)] flex flex-col gap-6 animate-in slide-in-from-bottom-5 duration-700">
      <div className="flex justify-between items-end shrink-0">
        <div>
          <h2 className="text-4xl font-black tracking-tighter dark:text-white">Inteligência <span className="gradient-text">AI</span></h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Módulo Cognitivo ATIS / GIRA</p>
        </div>
        <div className="flex items-center gap-2">
           <Activity size={16} className="text-emerald-500 animate-pulse" />
           <span className="text-[10px] font-black text-slate-400 uppercase">Sincronizado</span>
        </div>
      </div>
      <Card className="flex-1 flex flex-col p-0 overflow-hidden glass border-none">
        <div ref={scrollRef} className="flex-1 p-8 overflow-y-auto space-y-6">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-6 rounded-[40px] font-medium text-sm ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none shadow-2xl' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-200 dark:border-slate-700'}`}>
                {m.text}
              </div>
            </div>
          ))}
          {isLoading && <div className="flex justify-start"><div className="p-6 rounded-[40px] bg-indigo-500/10 rounded-tl-none flex gap-2"><div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce"></div><div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-100"></div><div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-200"></div></div></div>}
        </div>
        <div className="p-6 glass bg-white/40 dark:bg-black/20 flex gap-4">
          <input 
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Interagir com a IA..." 
            className="flex-1 bg-transparent border-none focus:ring-0 text-sm font-bold dark:text-white"
          />
          <Button onClick={handleSend} loading={isLoading} className="rounded-2xl px-8 h-12"><Send size={18}/></Button>
        </div>
      </Card>
    </div>
  );
};


import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Modal, Badge, useToast, ConfirmDialog } from '../components/UI';
import { 
  Heart, Users, MessageSquare, DollarSign, Activity, Zap, 
  History, ShieldCheck, Mail, Phone, Calendar, Building2,
  Plus, Search, Filter, ChevronRight, CheckCircle2, Clock, Trash2,
  Gavel, Target, Briefcase, Share2, Wallet, ArrowRight, UserPlus,
  Info, Layout, Send, Loader2, BrainCircuit, BarChart3, Lock
} from 'lucide-react';
import { mockDB } from '../services/mockDB';
import { Beneficiary, Attendance, Funder, Donor, Donation, CRMCommunication, ProjectCriteria, DonorStatus } from '../types';
import { useAuth } from '../context/AuthContext';
import { FirestoreService } from '../services/FirestoreService';
import { AuditService } from '../services/AuditService';
import { MatchingService } from '../services/MatchingService';
import { AnonymizationService } from '../services/AnonymizationService';

export const GiraVinculos: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'360' | 'BENEFICIARIES' | 'ATTENDANCES' | 'INTELLIGENCE' | 'FUNDRAISING' | 'COMMUNICATION'>('360');
  
  // Data States
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [attendances, setAttendances] = useState<Attendance[]>([]);
  const [funders, setFunders] = useState<Funder[]>([]);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [donations, setDonations] = useState<Donation[]>([]);
  const [comms, setComms] = useState<CRMCommunication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Intelligence States
  const [matchingCriteria, setMatchingCriteria] = useState<ProjectCriteria>({ gender: 'TODOS' });
  const [matchedBeneficiaries, setMatchedBeneficiaries] = useState<Beneficiary[]>([]);
  const [isMatching, setIsMatching] = useState(false);

  // Compliance States
  const [isAnonDialogOpen, setIsAnonDialogOpen] = useState(false);

  // Modals
  const [isBenModalOpen, setIsBenModalOpen] = useState(false);
  const [isAttModalOpen, setIsAttModalOpen] = useState(false);
  const [isDonationModalOpen, setIsDonationModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isDonorModalOpen, setIsDonorModalOpen] = useState(false);
  
  const [selectedBen, setSelectedBen] = useState<Beneficiary | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const refresh = async () => {
    setIsLoading(true);
    try {
        const [bens, atts, funs, dons, dntns, commsData] = await Promise.all([
            FirestoreService.getAll<Beneficiary>('beneficiaries'),
            FirestoreService.getAll<Attendance>('attendances'),
            FirestoreService.getAll<Funder>('funders'),
            FirestoreService.getAll<Donor>('donors'),
            FirestoreService.getAll<Donation>('donations'),
            FirestoreService.getAll<CRMCommunication>('crm_communications')
        ]);
        setBeneficiaries(bens);
        setAttendances(atts);
        setFunders(funs);
        setDonors(dons);
        setDonations(dntns);
        setComms(commsData);
    } catch (e) {
        toast.error('Erro de sincronização CRM.');
    } finally {
        setIsLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  // Handlers
  const handleSaveBeneficiary = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    const newBen: Beneficiary = {
      id: selectedBen?.id || `ben-${Date.now()}`,
      name: f.get('name') as string,
      cpf: f.get('cpf') as string,
      birthDate: f.get('birthDate') as string,
      gender: f.get('gender') as string,
      race: f.get('race') as string,
      phone: f.get('phone') as string,
      email: f.get('email') as string,
      address: {
        cep: f.get('cep') as string,
        street: f.get('street') as string,
        number: f.get('number') as string,
        neighborhood: f.get('neighborhood') as string,
        city: f.get('city') as string,
        uf: f.get('uf') as string
      },
      familyComposition: {
        peopleCount: 1,
        monthlyIncome: 0,
        dependents: []
      },
      vulnerabilities: [],
      projectsLinked: [],
      lgpdConsent: { accepted: true, timestamp: new Date().toISOString() },
      status: 'ATIVO',
      createdAt: selectedBen?.createdAt || new Date().toISOString(),
      lastInteraction: new Date().toISOString(),
      isAnonymized: false
    };

    try {
        await FirestoreService.save('beneficiaries', newBen.id, newBen);
        await AuditService.log({
          userId: currentUser?.id || 'sys',
          userName: currentUser?.name || 'Sistema',
          action: selectedBen ? 'UPDATE_BENEFICIARY' : 'CREATE_BENEFICIARY',
          module: 'CRM_LGPD',
          details: `Manipulação de dados pessoais do titular ${newBen.name}`,
          criticality: 'INFO'
        });
        await refresh();
        setIsBenModalOpen(false);
        toast.success('Ficha social protocolada na nuvem.');
    } catch (e) {
        toast.error('Erro ao salvar beneficiário.');
    } finally {
        setIsSubmitting(false);
    }
  };

  // Run Matching Algorithm
  const handleRunMatching = () => {
    setIsMatching(true);
    setTimeout(() => {
      const results = MatchingService.findEligibleBeneficiaries(beneficiaries, matchingCriteria);
      setMatchedBeneficiaries(results);
      setIsMatching(false);
      toast.info(`${results.length} beneficiários encontrados com o perfil.`);
    }, 800);
  };

  // Run Anonymization
  const handleRunAnonymization = async () => {
    setIsMatching(true); // Reuse loading state
    try {
      const count = await AnonymizationService.runAnonymizationJob(beneficiaries, 5, currentUser?.id || 'sys');
      await refresh();
      toast.success(`Job concluído. ${count} registros anonimizados.`);
    } catch (e) {
      toast.error('Erro ao executar job de conformidade.');
    } finally {
      setIsMatching(false);
      setIsAnonDialogOpen(false);
    }
  };

  // Donor Saver
  const handleSaveDonor = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    const newDonor: Donor = {
        id: `DNR-${Date.now()}`,
        name: f.get('name') as string,
        email: f.get('email') as string,
        phone: f.get('phone') as string,
        identifier: f.get('identifier') as string,
        type: 'PF',
        status: f.get('status') as DonorStatus,
        totalDonated: 0,
        acquisitionChannel: 'WEB'
    };

    try {
        await FirestoreService.save('donors', newDonor.id, newDonor);
        await refresh();
        setIsDonorModalOpen(false);
        toast.success('Doador cadastrado no pipeline.');
    } catch(e) {
        toast.error('Erro ao salvar doador.');
    } finally {
        setIsSubmitting(false);
    }
  };

  if (isLoading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-12 h-12 text-red-600 animate-spin opacity-20" />
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Sincronizando Rede Social...</p>
    </div>
  );

  // Components
  const RenderCommunication = () => (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Central de Relacionamento</h3>
        <Badge color="rose">Canal Omnichannel</Badge>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
           {comms.length === 0 ? (
             <div className="py-20 text-center glass rounded-[40px] border-2 border-dashed border-red-100">
                <MessageSquare size={48} className="mx-auto text-slate-200 mb-4" />
                <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">Sem interações registradas no nodo.</p>
             </div>
           ) : (
             comms.map(c => (
               <Card key={c.id} className="glass p-6 hover:border-red-500/30 transition-all group">
                  <div className="flex items-start gap-4">
                     <div className="w-10 h-10 rounded-xl bg-red-50 dark:bg-red-900/30 flex items-center justify-center text-red-600 shrink-0 group-hover:scale-110 transition-transform">
                        {c.channel === 'WHATSAPP' ? <Phone size={18}/> : <Mail size={18}/>}
                     </div>
                     <div className="flex-1">
                        <div className="flex justify-between items-start">
                           <h5 className="text-sm font-black dark:text-white group-hover:text-red-500 transition-colors">{c.subject}</h5>
                           <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{new Date(c.timestamp).toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">{c.content}</p>
                        <div className="mt-4 flex items-center gap-2">
                           <Badge color="slate">{c.contactType}</Badge>
                           <ArrowRight size={12} className="text-slate-300" />
                           <span className="text-[10px] font-black text-red-500 uppercase tracking-widest">{c.direction}</span>
                        </div>
                     </div>
                  </div>
               </Card>
             ))
           )}
        </div>
        <Card title="Nova Interação" className="h-fit border-red-500/10">
           <form className="space-y-4">
              <div className="space-y-1">
                 <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Canal</label>
                 <select className="w-full p-3 rounded-xl glass border-none bg-white dark:bg-slate-800 text-xs font-bold shadow-inner">
                    <option>WHATSAPP</option>
                    <option>EMAIL</option>
                    <option>REUNIÃO PRESENCIAL</option>
                 </select>
              </div>
              <Input label="Assunto" placeholder="Ex: Acompanhamento de edital" icon={<MessageSquare size={14} className="text-red-500"/>} />
              <div className="space-y-1">
                 <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Conteúdo</label>
                 <textarea className="w-full p-4 rounded-xl glass border-none bg-white dark:bg-slate-800 text-xs h-24 shadow-inner focus:ring-4 focus:ring-red-500/10 transition-all"></textarea>
              </div>
              <Button className="w-full bg-red-600 hover:bg-red-700 rounded-xl gap-2 font-black uppercase shadow-red-500/20"><Send size={14}/> Registrar Contato</Button>
           </form>
        </Card>
      </div>
    </div>
  );

  const RenderIntelligence = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
            <h3 className="text-2xl font-black dark:text-white">Inteligência de Dados (Analytics)</h3>
            <Button onClick={() => setIsAnonDialogOpen(true)} variant="outline" className="text-rose-500 border-rose-200 hover:bg-rose-50"><ShieldCheck size={18} className="mr-2"/> Rotina LGPD</Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Matching Panel */}
            <div className="lg:col-span-1 space-y-6">
                <Card className="glass border-l-4 border-l-red-500" title="Motor de Elegibilidade" subtitle="Matching para Projetos">
                    <div className="space-y-4 mt-4">
                        <Input label="Idade Mínima" type="number" value={matchingCriteria.minAge} onChange={e => setMatchingCriteria({...matchingCriteria, minAge: Number(e.target.value)})} />
                        <Input label="Idade Máxima" type="number" value={matchingCriteria.maxAge} onChange={e => setMatchingCriteria({...matchingCriteria, maxAge: Number(e.target.value)})} />
                        
                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase">Gênero</label>
                            <select className="w-full p-3 rounded-xl glass border-none text-xs font-bold" value={matchingCriteria.gender} onChange={e => setMatchingCriteria({...matchingCriteria, gender: e.target.value})}>
                                <option value="TODOS">Todos</option>
                                <option value="MASCULINO">Masculino</option>
                                <option value="FEMININO">Feminino</option>
                            </select>
                        </div>

                        <div className="space-y-1">
                            <label className="text-[10px] font-black text-slate-400 uppercase">Vulnerabilidade (Tag)</label>
                            <select className="w-full p-3 rounded-xl glass border-none text-xs font-bold" onChange={e => setMatchingCriteria({...matchingCriteria, requiredVulnerabilities: [e.target.value]})}>
                                <option value="">Qualquer</option>
                                <option value="Insegurança Alimentar">Insegurança Alimentar</option>
                                <option value="Desemprego">Desemprego</option>
                            </select>
                        </div>

                        <Button onClick={handleRunMatching} loading={isMatching} className="w-full bg-red-600 hover:bg-red-700 shadow-red-500/20 font-black uppercase rounded-xl mt-4"><BrainCircuit size={18} className="mr-2"/> Buscar Candidatos</Button>
                    </div>
                </Card>
            </div>

            {/* Results Panel */}
            <div className="lg:col-span-2">
                <Card className="glass h-full flex flex-col" title={`Resultados do Matching (${matchedBeneficiaries.length})`}>
                    <div className="flex-1 overflow-y-auto max-h-[500px] mt-4 space-y-3 custom-scrollbar pr-2">
                        {matchedBeneficiaries.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-full text-slate-400 opacity-50">
                                <Target size={48} className="mb-4"/>
                                <p className="text-xs font-black uppercase tracking-widest">Aguardando parâmetros...</p>
                            </div>
                        ) : (
                            matchedBeneficiaries.map(ben => (
                                <div key={ben.id} className="flex justify-between items-center p-4 bg-white/50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                                    <div className="flex items-center gap-4">
                                        <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-600 font-black text-xs">
                                            {new Date().getFullYear() - new Date(ben.birthDate).getFullYear()}
                                        </div>
                                        <div>
                                            <p className="text-sm font-black dark:text-white">{ben.name}</p>
                                            <p className="text-[9px] text-slate-400 uppercase font-bold">{ben.address.neighborhood}</p>
                                        </div>
                                    </div>
                                    <div className="flex gap-2">
                                        {ben.vulnerabilities.map(v => <Badge key={v} color="rose">{v}</Badge>)}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </Card>
            </div>
        </div>
    </div>
  );

  const RenderFundraising = () => (
      <div className="space-y-8 animate-in fade-in duration-500">
          <div className="flex justify-between items-center">
              <h3 className="text-2xl font-black dark:text-white">Pipeline de Captação</h3>
              <Button onClick={() => setIsDonorModalOpen(true)} className="bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20 font-black uppercase rounded-2xl gap-2"><Plus size={18}/> Novo Doador</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {['LEAD', 'PROSPECT', 'ACTIVE_RECURRING', 'CHURNED'].map(status => (
                  <div key={status} className="flex flex-col gap-4">
                      <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-black text-xs text-slate-500 uppercase tracking-widest text-center">
                          {status.replace('_', ' ')}
                      </div>
                      {donors.filter(d => d.status === status).map(d => (
                          <div key={d.id} className="p-4 rounded-2xl glass border border-slate-100 dark:border-slate-700 hover:border-emerald-500 transition-all cursor-pointer group">
                              <div className="flex justify-between items-start mb-2">
                                  <span className="text-xs font-black dark:text-white group-hover:text-emerald-500">{d.name}</span>
                                  {d.status === 'ACTIVE_RECURRING' && <Zap size={12} className="text-emerald-500"/>}
                              </div>
                              <p className="text-[9px] text-slate-400 uppercase font-bold">{d.email}</p>
                              <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
                                  <span className="text-[9px] font-black text-emerald-600">Total: R$ {d.totalDonated}</span>
                                  <Button variant="ghost" className="h-6 w-6 p-0 rounded-lg text-slate-300 hover:text-emerald-500"><ChevronRight size={14}/></Button>
                              </div>
                          </div>
                      ))}
                      {donors.filter(d => d.status === status).length === 0 && (
                          <div className="p-4 rounded-2xl border-2 border-dashed border-slate-100 dark:border-slate-800 text-center text-[9px] font-bold text-slate-300 uppercase">Vazio</div>
                      )}
                  </div>
              ))}
          </div>
      </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-red-600 text-white text-[10px] font-black rounded-full uppercase tracking-widest shadow-lg shadow-red-500/20">Ubuntu v5.2</span>
            <Heart size={18} className="text-red-500 fill-red-500 animate-pulse" />
          </div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">GIRA <span className="text-red-600">Vínculos</span></h2>
          <p className="text-red-500 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Tecnologia com Propósito Social</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="rounded-2xl gap-2 border-red-500/30 text-red-600 hover:bg-red-50"><History size={18}/> Linha do Tempo</Button>
          <Button className="rounded-2xl gap-2 bg-red-600 hover:bg-red-700 shadow-red-500/40 font-black uppercase h-14 px-10" onClick={() => { setSelectedBen(null); setIsBenModalOpen(true); }}><UserPlus size={18}/> Novo Beneficiário</Button>
        </div>
      </header>

      <nav className="flex p-1.5 glass rounded-[40px] w-full overflow-x-auto no-scrollbar shadow-2xl border-red-500/10 bg-white/20 dark:bg-black/20">
        {[
          { id: '360', label: 'Visão 360°', icon: <Activity size={18}/> },
          { id: 'BENEFICIARIES', label: 'Beneficiários', icon: <Users size={18}/> },
          { id: 'INTELLIGENCE', label: 'Inteligência', icon: <BrainCircuit size={18}/> },
          { id: 'ATTENDANCES', label: 'Atendimentos', icon: <Zap size={18}/> },
          { id: 'FUNDERS', label: 'Financiadores', icon: <Building2 size={18}/> },
          { id: 'FUNDRAISING', label: 'Captação (CRM)', icon: <Wallet size={18}/> },
          { id: 'DONORS', label: 'Doadores', icon: <DollarSign size={18}/> },
          { id: 'COMMUNICATION', label: 'Comunicação', icon: <MessageSquare size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-[10px] font-black transition-all duration-500 shrink-0 ${activeTab === tab.id ? 'bg-red-600 text-white shadow-xl shadow-red-500/20' : 'text-slate-500 hover:text-red-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <main className="animate-in slide-in-from-bottom-5 duration-700">
        {activeTab === '360' && (
          <div className="space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <Card className="glass border-l-4 border-l-red-600 hover:border-red-500 transition-all" title="Atendidos Ativos">
                 <h3 className="text-4xl font-black dark:text-white">{beneficiaries.length}</h3>
                 <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">+12% este mês</p>
              </Card>
              <Card className="glass border-l-4 border-l-emerald-500 hover:border-emerald-400 transition-all" title="Captação Direta">
                 <h3 className="text-4xl font-black text-emerald-500">R$ {donations.reduce((acc, d) => acc + d.value, 0).toLocaleString()}</h3>
                 <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Meta 85% Concluída</p>
              </Card>
              <Card className="glass border-l-4 border-l-red-500 hover:border-red-400 transition-all" title="Atendimentos Mês">
                 <h3 className="text-4xl font-black dark:text-white">{attendances.length}</h3>
                 <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">SLA Médio: 42min</p>
              </Card>
              <Card className="glass border-l-4 border-l-amber-500 hover:border-amber-400 transition-all" title="Nodos Parceiros">
                 <h3 className="text-4xl font-black dark:text-white">{funders.length}</h3>
                 <p className="text-[9px] font-bold text-slate-400 mt-2 uppercase tracking-widest">Rede Global ATIS</p>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card className="lg:col-span-2 glass border-red-500/10" title="Vínculos Recentes" subtitle="Fluxo Global de Relacionamento">
                 <div className="space-y-4 mt-6">
                    {[...attendances].reverse().slice(0, 5).map(att => {
                      const ben = beneficiaries.find(b => b.id === att.beneficiaryId);
                      return (
                        <div key={att.id} className="p-5 rounded-3xl border border-slate-50 dark:border-slate-800 glass flex items-center justify-between group hover:border-red-500 transition-all cursor-pointer" onClick={() => { setSelectedBen(ben || null); setIsDetailModalOpen(true); }}>
                           <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center font-black group-hover:scale-110 transition-transform">{ben?.name.charAt(0)}</div>
                              <div>
                                 <p className="text-sm font-black dark:text-white group-hover:text-red-500 transition-colors">{ben?.name}</p>
                                 <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{att.type} • {att.location}</p>
                              </div>
                           </div>
                           <Badge color="rose">{new Date(att.date).toLocaleDateString()}</Badge>
                        </div>
                      );
                    })}
                    {attendances.length === 0 && <p className="text-center py-10 opacity-40 font-bold text-sm uppercase tracking-widest">Sem atividades registradas no radar.</p>}
                 </div>
              </Card>
              <Card className="glass border-red-500/10" title="Radar de Vulnerabilidades" subtitle="Visão Sintética do Público">
                 <div className="space-y-6 mt-6">
                    {[
                      { label: 'Insegurança Alimentar', pct: 65, color: 'bg-red-500' },
                      { label: 'Desemprego', pct: 42, color: 'bg-amber-500' },
                      { label: 'Saúde Mental', pct: 28, color: 'bg-red-400' },
                      { label: 'Violência Doméstica', pct: 15, color: 'bg-red-600' }
                    ].map((v, i) => (
                      <div key={i} className="space-y-2">
                         <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest">
                            <span className="text-slate-400">{v.label}</span>
                            <span className="text-slate-800 dark:text-white">{v.pct}%</span>
                         </div>
                         <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                            <div className={`h-full ${v.color} shadow-[0_0_8px_rgba(239,68,68,0.3)]`} style={{ width: `${v.pct}%` }}></div>
                         </div>
                      </div>
                    ))}
                 </div>
              </Card>
            </div>
          </div>
        )}

        {activeTab === 'BENEFICIARIES' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-1 relative group">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-red-500 transition-colors" />
                <input 
                  className="w-full pl-14 pr-6 py-4 rounded-3xl glass bg-white/50 border-none text-sm font-bold focus:ring-4 focus:ring-red-500/10 transition-all shadow-inner dark:text-white" 
                  placeholder="Localizar titular por nome, CPF ou projeto vinculado..." 
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" className="rounded-2xl gap-2 border-red-500/20 text-red-600 hover:bg-red-50 font-black uppercase"><Filter size={18}/> Filtros LGPD</Button>
            </div>

            <Card className="p-0 glass border-none overflow-hidden hover:border-red-500/20">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                      <th className="p-6">Titular / Identidade</th>
                      <th className="p-6">Localidade</th>
                      <th className="p-6">Vínculos GIRA</th>
                      <th className="p-6 text-center">Consentimento</th>
                      <th className="p-6 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {beneficiaries.filter(b => b.name.toLowerCase().includes(searchTerm.toLowerCase())).map(ben => (
                      <tr key={ben.id} className="hover:bg-red-500/[0.03] transition-colors group">
                        <td className="p-6">
                          <div className="flex items-center gap-4 cursor-pointer" onClick={() => { setSelectedBen(ben); setIsDetailModalOpen(true); }}>
                             <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-900/30 text-red-600 flex items-center justify-center font-black shadow-inner group-hover:scale-110 transition-transform">{ben.name.charAt(0)}</div>
                             <div>
                                <p className="font-black text-sm dark:text-white leading-tight group-hover:text-red-500 transition-colors">{ben.name}</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-widest">CPF: {ben.cpf}</p>
                             </div>
                          </div>
                        </td>
                        <td className="p-6">
                           <p className="text-xs font-bold text-slate-600 dark:text-slate-400">{ben.address.neighborhood}</p>
                           <p className="text-[9px] text-slate-400 uppercase tracking-widest">{ben.address.city} - {ben.address.uf}</p>
                        </td>
                        <td className="p-6">
                           <div className="flex gap-2">
                              <Badge color="rose">Geral</Badge>
                              {ben.projectsLinked && ben.projectsLinked.length > 0 && <Badge color="rose">Projeto Ativo</Badge>}
                           </div>
                        </td>
                        <td className="p-6 text-center">
                           <div className="flex justify-center">
                              {ben.isAnonymized ? (
                                <div className="w-6 h-6 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center shadow-sm"><Lock size={14}/></div>
                              ) : (
                                <div className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center shadow-sm"><CheckCircle2 size={14}/></div>
                              )}
                           </div>
                           <p className="text-[8px] text-slate-400 font-bold uppercase mt-1 tracking-widest">{ben.isAnonymized ? 'MASCARADO' : new Date(ben.lgpdConsent.timestamp).toLocaleDateString()}</p>
                        </td>
                        <td className="p-6 text-right">
                           <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-all">
                              <Button variant="ghost" onClick={() => { setSelectedBen(ben); setIsBenModalOpen(true); }} className="p-2 text-red-600 hover:bg-red-50 rounded-xl"><Plus size={16}/></Button>
                              <Button variant="ghost" onClick={() => { setSelectedBen(ben); setIsDetailModalOpen(true); }} className="p-2 text-red-600 hover:bg-red-50 rounded-xl"><ChevronRight size={20}/></Button>
                           </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {activeTab === 'COMMUNICATION' && <RenderCommunication />}
        {activeTab === 'INTELLIGENCE' && <RenderIntelligence />}
        {activeTab === 'FUNDRAISING' && <RenderFundraising />}
      </main>

      <Modal isOpen={isDetailModalOpen} onClose={() => setIsDetailModalOpen(false)} title="Prontuário Social Integrado" size="2xl">
         {selectedBen && (
            <div className="space-y-10">
               <div className="flex items-center gap-8 p-8 glass rounded-[40px] border-red-500/10 shadow-lg">
                  <div className="w-24 h-24 rounded-[32px] bg-red-600 flex items-center justify-center text-white text-4xl font-black shadow-red-500/30">{selectedBen.name.charAt(0)}</div>
                  <div className="flex-1">
                     <h3 className="text-3xl font-black dark:text-white leading-none">{selectedBen.name}</h3>
                     <p className="text-xs font-bold text-slate-400 uppercase mt-2 tracking-[0.2em]">{selectedBen.address.neighborhood}, {selectedBen.address.city} - {selectedBen.address.uf}</p>
                     <div className="flex gap-2 mt-4">
                        <Badge color="emerald">Consentimento LGPD OK</Badge>
                        <Badge color="rose">ID: {selectedBen.id.slice(-8)}</Badge>
                     </div>
                  </div>
                  <div className="text-right">
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Status do Vínculo</p>
                     <Badge color="emerald">ATIVO NO NODO</Badge>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card title="Histórico de Atendimentos" className="glass border-red-500/5" subtitle="Últimas Interações Sociais">
                     <div className="space-y-4">
                        {attendances.filter(a => a.beneficiaryId === selectedBen.id).map(a => (
                           <div key={a.id} className="p-4 rounded-2xl bg-white/50 dark:bg-black/20 border border-slate-100 dark:border-slate-800 flex justify-between items-center group hover:border-red-500/30 transition-all">
                              <div>
                                 <p className="text-xs font-black dark:text-white group-hover:text-red-500 transition-colors">{a.type}</p>
                                 <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{new Date(a.date).toLocaleDateString()}</p>
                              </div>
                              <Button variant="ghost" className="rounded-xl hover:bg-red-50 text-red-500"><ChevronRight size={14}/></Button>
                           </div>
                        ))}
                        {attendances.filter(a => a.beneficiaryId === selectedBen.id).length === 0 && <p className="text-center py-6 text-xs text-slate-400 italic uppercase tracking-widest">Sem registros prévios.</p>}
                     </div>
                  </Card>
                  <Card title="Pilar Socioeconômico" className="glass border-red-500/5" subtitle="Análise de Contexto Social">
                     <div className="space-y-6">
                        <div className="flex justify-between items-center">
                           <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Membros Família</span>
                           <span className="text-lg font-black dark:text-white">{selectedBen.familyComposition.peopleCount}</span>
                        </div>
                        <div className="flex justify-between items-center">
                           <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Renda Familiar</span>
                           <span className="text-lg font-black text-emerald-500">R$ {selectedBen.familyComposition.monthlyIncome.toLocaleString()}</span>
                        </div>
                        <div className="pt-6 border-t border-slate-100 dark:border-slate-800">
                           <p className="text-[10px] font-black text-red-600 uppercase mb-3 tracking-[0.2em]">Vulnerabilidades Mapeadas</p>
                           <div className="flex flex-wrap gap-2">
                              {selectedBen.vulnerabilities.map(v => <Badge key={v} color="rose">{v}</Badge>)}
                              {selectedBen.vulnerabilities.length === 0 && <span className="text-[9px] text-slate-300 italic uppercase">Nenhuma vulnerabilidade crítica marcada.</span>}
                           </div>
                        </div>
                     </div>
                  </Card>
               </div>
            </div>
         )}
      </Modal>

      <Modal isOpen={isBenModalOpen} onClose={() => setIsBenModalOpen(false)} title="Protocolo de Inscrição Social" size="xl">
         <form onSubmit={handleSaveBeneficiary} className="space-y-8">
            <div className="grid grid-cols-2 gap-6">
               <Input label="Nome Completo" name="name" defaultValue={selectedBen?.name} required icon={<Users size={16} className="text-red-500"/>} />
               <Input label="CPF" name="cpf" defaultValue={selectedBen?.cpf} required icon={<ShieldCheck size={16} className="text-red-500"/>} />
            </div>
            <div className="grid grid-cols-3 gap-6">
               <Input label="Data Nasc." name="birthDate" type="date" defaultValue={selectedBen?.birthDate} required />
               <Input label="WhatsApp" name="phone" defaultValue={selectedBen?.phone} required icon={<Phone size={16} className="text-red-500"/>} />
               <Input label="E-mail" name="email" defaultValue={selectedBen?.email} icon={<Mail size={16} className="text-red-500"/>} />
            </div>
            <div className="p-8 bg-emerald-50 dark:bg-emerald-900/10 rounded-[40px] border border-emerald-100 flex items-center gap-6 shadow-inner">
               <ShieldCheck size={40} className="text-emerald-500 shrink-0" />
               <p className="text-xs text-slate-500 dark:text-emerald-300 font-bold uppercase tracking-widest leading-relaxed">O titular assinou o termo de consentimento LGPD para finalidades sociais e atendimento continuado.</p>
            </div>
            <div className="flex justify-end gap-4 pt-6">
               <Button variant="outline" type="button" onClick={() => setIsBenModalOpen(false)} className="px-10 h-14 rounded-2xl border-red-500/20 text-red-600">Cancelar</Button>
               <Button type="submit" loading={isSubmitting} className="bg-red-600 hover:bg-red-700 shadow-xl shadow-red-500/20 rounded-2xl h-14 px-12 font-black uppercase">Protocolar Ficha</Button>
            </div>
         </form>
      </Modal>

      {/* MODAL NOVO DOADOR */}
      <Modal isOpen={isDonorModalOpen} onClose={() => setIsDonorModalOpen(false)} title="Cadastro de Investidor Social">
          <form onSubmit={handleSaveDonor} className="space-y-6">
              <Input label="Nome do Doador / Empresa" name="name" required />
              <div className="grid grid-cols-2 gap-4">
                  <Input label="Email" name="email" required />
                  <Input label="Telefone" name="phone" required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <Input label="CPF/CNPJ" name="identifier" required />
                  <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase">Status Inicial</label>
                      <select name="status" className="w-full p-3 rounded-xl glass border-none text-xs font-bold">
                          <option value="LEAD">Lead (Frio)</option>
                          <option value="PROSPECT">Prospect (Interessado)</option>
                          <option value="ACTIVE_ONE_OFF">Doador Pontual</option>
                          <option value="ACTIVE_RECURRING">Recorrente (Assinatura)</option>
                      </select>
                  </div>
              </div>
              <Button type="submit" loading={isSubmitting} className="w-full bg-emerald-600 font-black uppercase rounded-xl">Cadastrar no Pipeline</Button>
          </form>
      </Modal>

      <ConfirmDialog 
        isOpen={isAnonDialogOpen}
        onClose={() => setIsAnonDialogOpen(false)}
        onConfirm={handleRunAnonymization}
        title="Executar Rotina de Privacidade?"
        message="Esta ação irá varrer a base de beneficiários e mascarar dados pessoais de registros inativos há mais de 5 anos. A operação é irreversível para os campos identificadores."
      />
    </div>
  );
};

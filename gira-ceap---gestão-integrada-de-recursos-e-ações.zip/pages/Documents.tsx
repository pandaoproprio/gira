
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, Button, Input, Badge, Modal, useToast } from '../components/UI';
import { 
  FileText, FolderInput, Download, Search, ShieldCheck, 
  MoreVertical, UploadCloud, X, Globe, Cloud, CloudOff,
  RefreshCw, ExternalLink, Tag, Sparkles, Loader2, Trash2
} from 'lucide-react';
import { FirestoreService } from '../services/FirestoreService';
import { Document } from '../types';
import { useAuth } from '../context/AuthContext';
import { GoogleGenAI } from "@google/genai";

const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest';
const SCOPES = 'https://www.googleapis.com/auth/drive.file';

export const Documents: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [docs, setDocs] = useState<Document[]>([]);
  const [driveDocs, setDriveDocs] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [syncWithDrive, setSyncWithDrive] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const [isDriveConnected, setIsDriveConnected] = useState(false);
  const [tokenClient, setTokenClient] = useState<any>(null);

  const loadLocalDocs = async () => {
    setIsLoading(true);
    try {
      const data = await FirestoreService.getAll<Document>('documents');
      setDocs(data);
    } catch (e) {
      console.error(e);
      toast.error("Erro ao sincronizar repositório local.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadLocalDocs();

    const initGapi = () => {
      if (!(window as any).gapi) return;
      (window as any).gapi.load('client', async () => {
        try {
          await (window as any).gapi.client.init({
            apiKey: process.env.API_KEY,
            discoveryDocs: [DISCOVERY_DOC],
          });
        } catch (e) {
          console.error("Gapi Init Error", e);
        }
      });
    };

    const initGis = () => {
      if (!(window as any).google?.accounts?.oauth2) return;
      const client = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: '536713009654-placeholder.apps.googleusercontent.com', // Substituir pelo ID real do console do Google
        scope: SCOPES,
        callback: (resp: any) => {
          if (resp.error !== undefined) {
            toast.error('Falha na autenticação com Google Drive.');
            return;
          }
          setIsDriveConnected(true);
          listDriveFiles();
        },
      });
      setTokenClient(client);
    };

    // Pequeno delay para garantir que os scripts injetados no index.html carregaram
    const timer = setTimeout(() => {
      initGapi();
      initGis();
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleDriveConnect = () => {
    if (tokenClient) {
      tokenClient.requestAccessToken({ prompt: 'consent' });
    } else {
      toast.error('Gis Client não disponível. Verifique sua conexão.');
    }
  };

  const listDriveFiles = useCallback(async () => {
    try {
      if (!(window as any).gapi?.client?.drive) return;
      const response = await (window as any).gapi.client.drive.files.list({
        pageSize: 12,
        fields: 'files(id, name, size, mimeType, webViewLink, iconLink)',
        q: "trashed = false"
      });
      setDriveDocs(response.result.files || []);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsUploading(true);
    const f = new FormData(e.currentTarget);
    const file = (f.get('file') as File);
    const docName = (f.get('name') as string) || file.name;

    try {
      let driveId = null;
      let tags: string[] = [];

      // IA: Análise de Metadados e Tags (Gemini 3 Flash)
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const aiResult = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analise o contexto do arquivo "${docName}" para uma organização social. Sugira 3 palavras-chave para indexação separadas por vírgula.`,
      });
      
      tags = aiResult.text?.split(',').map(t => t.trim().toUpperCase()) || [];

      // Google Drive Sync
      if (syncWithDrive && isDriveConnected) {
        const metadata = { name: docName, mimeType: file.type };
        const form = new FormData();
        form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
        form.append('file', file);

        const resp = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
          method: 'POST',
          headers: new Headers({ 'Authorization': 'Bearer ' + (window as any).gapi.auth.getToken().access_token }),
          body: form,
        });
        const driveData = await resp.json();
        driveId = driveData.id;
      }

      const newDoc: Omit<Document, 'id'> = {
        name: docName,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        type: file.type.split('/')[1]?.toUpperCase() || 'DOC',
        owner: currentUser?.name || 'Sistema',
        tags: tags,
        isDrive: !!driveId,
        link: driveId ? `https://drive.google.com/open?id=${driveId}` : undefined
      };

      await FirestoreService.save('documents', null, newDoc);
      await loadLocalDocs();
      if (isDriveConnected) listDriveFiles();
      
      setIsUploading(false);
      setIsUploadModalOpen(false);
      toast.success(driveId ? 'Sincronizado na nuvem e indexado.' : 'Indexado com sucesso.');
    } catch (error) {
      console.error(error);
      toast.error('Erro no processamento neural do arquivo.');
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await FirestoreService.delete('documents', id);
      setDocs(prev => prev.filter(d => d.id !== id));
      toast.success("Entrada removida do repositório.");
    } catch (e) {
      toast.error("Erro ao deletar.");
    }
  };

  const allDocs = useMemo(() => {
    const driveMapped = driveDocs.map(fd => ({
      id: fd.id,
      name: fd.name,
      size: fd.size ? `${(parseInt(fd.size) / 1024).toFixed(1)} KB` : 'CLOUD',
      type: fd.mimeType.split('/').pop().toUpperCase(),
      owner: 'Google Drive',
      isDrive: true,
      link: fd.webViewLink,
      tags: ['DRIVE']
    }));

    return [...docs, ...driveMapped].filter(doc => 
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.owner.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [docs, driveDocs, searchTerm]);

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black tracking-tighter dark:text-white leading-none">GED <span className="text-indigo-600">Cloud</span></h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.3em] mt-3 flex items-center gap-2">
            <ShieldCheck size={14} className="text-indigo-500" /> Indexação Criptografada & Sync Workspace
          </p>
        </div>
        <div className="flex gap-3">
          {!isDriveConnected ? (
            <Button onClick={handleDriveConnect} variant="outline" className="rounded-2xl border-indigo-500/20 text-indigo-600 gap-2 hover:bg-indigo-50 transition-all">
              <Cloud size={18} /> Conectar Google Drive
            </Button>
          ) : (
            <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-600 px-4 py-2 rounded-2xl border border-emerald-500/20">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-black uppercase tracking-widest">Drive Ativo</span>
            </div>
          )}
          <Button onClick={() => setIsUploadModalOpen(true)} className="px-10 h-14 rounded-3xl bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-500/20 font-black uppercase">
            <FolderInput size={20} className="mr-2" /> Upload Inteligente
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="flex-1 relative group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-all" size={20} />
          <input 
            type="text" 
            placeholder="Pesquisar em documentos, tags ou proprietários..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-16 pr-6 py-5 rounded-[32px] border-none glass bg-white/40 dark:bg-slate-800/40 focus:ring-4 focus:ring-indigo-500/10 transition-all font-bold text-sm dark:text-white shadow-sm"
          />
        </div>
        {isDriveConnected && (
          <Button variant="ghost" onClick={listDriveFiles} className="p-5 rounded-3xl glass border border-white/20">
            <RefreshCw size={20} className="text-indigo-500" />
          </Button>
        )}
      </div>

      {isLoading ? (
        <div className="h-64 flex flex-col items-center justify-center opacity-30">
          <Loader2 size={48} className="animate-spin mb-4" />
          <p className="font-black text-[10px] uppercase tracking-[0.4em]">Sincronizando Nuvem...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {allDocs.map((doc: any) => (
            <Card key={doc.id} className={`hover:border-indigo-500/50 transition-all group relative overflow-hidden flex flex-col h-full ${doc.isDrive ? 'bg-indigo-50/10' : ''}`}>
              {doc.isDrive && (
                <div className="absolute top-4 right-4">
                  <Badge color="indigo">CLOUD</Badge>
                </div>
              )}
              <div className="flex items-start gap-5 mb-6">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-500 shrink-0 ${doc.isDrive ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 group-hover:bg-indigo-600 group-hover:text-white'}`}>
                  {doc.isDrive ? <Cloud size={32}/> : <FileText size={32}/>}
                </div>
                <div className="min-w-0 pr-6">
                  <h4 className="text-sm font-black truncate dark:text-white leading-tight group-hover:text-indigo-600 transition-colors" title={doc.name}>{doc.name}</h4>
                  <p className="text-[10px] font-bold text-slate-400 uppercase mt-2 tracking-widest">{doc.size} • {doc.type}</p>
                </div>
              </div>

              <div className="mt-auto">
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {doc.tags?.map((tag: string, idx: number) => (
                    <span key={idx} className="px-2 py-0.5 bg-slate-50 dark:bg-slate-900/50 rounded-lg text-[8px] font-black text-slate-500 uppercase flex items-center gap-1 border border-slate-100 dark:border-slate-800">
                      <Tag size={8}/> {tag}
                    </span>
                  ))}
                </div>

                <div className="pt-5 border-t border-slate-50 dark:border-white/5 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-[10px] font-bold">
                      {doc.owner.charAt(0)}
                    </div>
                    <span className="text-[9px] font-black text-slate-400 uppercase truncate max-w-[80px]">{doc.owner}</span>
                  </div>
                  <div className="flex gap-1">
                    {doc.link ? (
                      <a href={doc.link} target="_blank" rel="noopener noreferrer" className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all">
                        <ExternalLink size={18}/>
                      </a>
                    ) : (
                      <button className="p-2 text-slate-400 hover:text-indigo-600 transition-all">
                        <Download size={18}/>
                      </button>
                    )}
                    {!doc.isDrive && (
                      <button onClick={() => handleDelete(doc.id)} className="p-2 text-slate-300 hover:text-rose-500 transition-all">
                        <Trash2 size={16}/>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {allDocs.length === 0 && !isLoading && (
        <div className="py-32 text-center glass rounded-[48px] border-2 border-dashed border-slate-200 dark:border-slate-800">
           <UploadCloud size={64} className="mx-auto text-slate-200 mb-6" />
           <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-sm">O Repositório está vazio</p>
           <p className="text-[10px] text-slate-300 mt-2 uppercase font-bold tracking-widest">Inicie um upload inteligente para começar a indexação</p>
        </div>
      )}

      <Modal isOpen={isUploadModalOpen} onClose={() => setIsUploadModalOpen(false)} title="Protocolo de Upload Inteligente" size="lg">
         <form onSubmit={handleUpload} className="space-y-8">
            <div className="relative p-12 border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-[40px] flex flex-col items-center justify-center text-center group hover:border-indigo-500 transition-all bg-slate-50/30 overflow-hidden">
               <UploadCloud size={56} className="text-slate-300 group-hover:text-indigo-500 transition-all mb-4" />
               <p className="text-xs font-black text-slate-400 uppercase tracking-widest">Arraste arquivos (PDF, DOCX, IMGs) ou clique aqui</p>
               <input type="file" name="file" className="absolute inset-0 opacity-0 cursor-pointer" required />
               <div className="mt-8 px-10 py-3 bg-white dark:bg-slate-800 text-indigo-600 shadow-xl rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100 dark:border-indigo-900 group-hover:scale-105 transition-all">Localizar no Computador</div>
            </div>
            
            <Input label="Identificação do Documento" name="name" placeholder="Ex: Contrato_Mutirao_Alimentos_2024" />
            
            <div className="space-y-4">
              <label className={`flex items-center gap-4 p-6 rounded-[32px] glass cursor-pointer border-2 transition-all ${syncWithDrive ? 'border-indigo-500 bg-indigo-50/50' : 'border-transparent hover:border-slate-300'}`}>
                <input 
                  type="checkbox" 
                  className="w-6 h-6 rounded-lg border-slate-300 text-indigo-600 focus:ring-indigo-500" 
                  checked={syncWithDrive}
                  onChange={(e) => setSyncWithDrive(e.target.checked)}
                  disabled={!isDriveConnected}
                />
                <div className="flex-1">
                  <p className="text-xs font-black dark:text-white uppercase tracking-widest flex items-center gap-2">
                    <Cloud size={16} className={syncWithDrive ? 'text-indigo-500' : 'text-slate-400'}/> Sincronizar com Workspace Cloud
                  </p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase mt-1">
                    {!isDriveConnected ? 'Conecte sua conta para habilitar cloud sync' : 'O arquivo será salvo no seu Google Drive e indexado no GIRA'}
                  </p>
                </div>
              </label>

              <div className="p-6 rounded-[32px] bg-indigo-600/5 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/50 flex items-center gap-5">
                 <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center text-indigo-600 shadow-lg">
                   <Sparkles size={24} className="animate-pulse" />
                 </div>
                 <p className="text-[10px] text-slate-600 dark:text-slate-400 font-black leading-relaxed uppercase tracking-widest">
                   O <span className="text-indigo-600 font-black">NÚCLEO ATIS (Gemini 3)</span> irá ler o conteúdo e sugerir tags automáticas para facilitar buscas futuras.
                 </p>
              </div>
            </div>

            <div className="flex gap-4 pt-4">
               <Button type="button" variant="outline" className="flex-1 h-16 rounded-[28px]" onClick={() => setIsUploadModalOpen(false)}>Abortar</Button>
               <Button type="submit" className="flex-[2] h-16 rounded-[28px] bg-indigo-600 hover:bg-indigo-700 shadow-xl shadow-indigo-500/20" loading={isUploading}>
                  <RefreshCw size={18} className={`mr-3 ${isUploading ? 'animate-spin' : ''}`}/> Efetivar Protocolo
               </Button>
            </div>
         </form>
      </Modal>
    </div>
  );
};

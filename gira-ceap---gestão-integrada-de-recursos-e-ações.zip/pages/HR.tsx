
import React, { useState, useEffect, useMemo } from 'react';
import { Card, Button, Input, Badge, Modal, useToast, ConfirmDialog } from '../components/UI';
import { 
  UserCircle, Users, TrendingUp, DollarSign, Plus, Search, 
  Trash2, Edit2, Loader2, AlertTriangle, Clock, Calendar, 
  FileText, Briefcase, Award, GraduationCap, Calculator,
  UploadCloud, CheckCircle2, XCircle, Star, Paperclip, FileCheck
} from 'lucide-react';
import { FirestoreService } from '../services/FirestoreService';
import { HRService } from '../services/HRService';
import { AuditService } from '../services/AuditService';
import { useAuth } from '../context/AuthContext';
import { Project, TimeRecord, AbsenceRequest, PerformanceReview, HRDocument } from '../types';

interface Employee {
  id: string;
  name: string;
  role: string;
  department: string;
  status: 'ATIVO' | 'FÉRIAS' | 'AFASTADO';
  salary: number;
  admissionDate: string;
}

export const HR: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  // Navigation
  const [activeTab, setActiveTab] = useState<'STAFF' | 'TIME' | 'TALENT' | 'DOCS' | 'COSTS'>('STAFF');
  
  // Core Data (Read-Only)
  const [staff, setStaff] = useState<Employee[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  
  // Extension Data
  const [timeRecords, setTimeRecords] = useState<TimeRecord[]>([]);
  const [absences, setAbsences] = useState<AbsenceRequest[]>([]);
  const [reviews, setReviews] = useState<PerformanceReview[]>([]);
  const [documents, setDocuments] = useState<HRDocument[]>([]);
  
  const [isLoading, setIsLoading] = useState(true);
  
  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false); // Admissão/Edição
  const [isAbsenceModalOpen, setIsAbsenceModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Selected Context & Editing
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [empData, projData, timeData, absData, revData, docData] = await Promise.all([
        FirestoreService.getAll<Employee>('employees'),
        FirestoreService.getAll<Project>('projects'),
        FirestoreService.getAll<TimeRecord>('hr_time_records'),
        FirestoreService.getAll<AbsenceRequest>('hr_absences'),
        FirestoreService.getAll<PerformanceReview>('hr_reviews'),
        FirestoreService.getAll<HRDocument>('hr_docs')
      ]);
      setStaff(empData);
      setProjects(projData);
      setTimeRecords(timeData);
      setAbsences(absData);
      setReviews(revData);
      setDocuments(docData);
    } catch (e) {
      toast.error('Erro ao sincronizar ecossistema de RH.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const selectedEmployee = useMemo(() => staff.find(e => e.id === selectedEmployeeId), [staff, selectedEmployeeId]);

  // --- HANDLERS ---

  const handleSaveEmployee = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    const newEmployee: Employee = {
      id: editingEmployee?.id || `EMP-${Date.now()}`,
      name: f.get('name') as string,
      role: f.get('role') as string,
      department: f.get('department') as string,
      salary: Number(f.get('salary')),
      status: f.get('status') as any,
      admissionDate: f.get('date') as string
    };

    try {
      await FirestoreService.save('employees', newEmployee.id, newEmployee);
      await AuditService.log({
        userId: currentUser?.id || 'sys',
        userName: currentUser?.name || 'Sistema',
        action: editingEmployee ? 'UPDATE_EMPLOYEE' : 'HIRE_EMPLOYEE',
        module: 'HR',
        details: `${editingEmployee ? 'Atualização' : 'Contratação'} registrada: ${newEmployee.name} (${newEmployee.role})`,
        criticality: 'INFO'
      });
      await loadData();
      setIsModalOpen(false);
      setEditingEmployee(null);
      toast.success(editingEmployee ? 'Dados atualizados.' : 'Colaborador registrado na folha.');
    } catch (e) {
      toast.error('Erro ao salvar colaborador.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteEmployee = async () => {
    if (!employeeToDelete) return;
    try {
      await FirestoreService.delete('employees', employeeToDelete.id);
      await AuditService.log({
        userId: currentUser?.id || 'sys',
        userName: currentUser?.name || 'Sistema',
        action: 'DELETE_EMPLOYEE',
        module: 'HR',
        details: `Colaborador removido: ${employeeToDelete.name}`,
        criticality: 'CRITICAL'
      });
      if (selectedEmployeeId === employeeToDelete.id) setSelectedEmployeeId(null);
      toast.success('Colaborador removido da base.');
      loadData();
    } catch (e) {
      toast.error('Erro ao remover colaborador.');
    } finally {
      setIsDeleteDialogOpen(false);
      setEmployeeToDelete(null);
    }
  };

  const handleClockIn = async () => {
    if (!selectedEmployeeId) return toast.error('Selecione um colaborador.');
    try {
      await HRService.clockIn(selectedEmployeeId);
      toast.success('Ponto registrado com sucesso.');
      loadData();
    } catch (e) {
      toast.error('Erro ao registrar ponto.');
    }
  };

  const handleRequestAbsence = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedEmployeeId) return;
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    try {
        await HRService.requestAbsence({
            employeeId: selectedEmployeeId,
            type: f.get('type') as any,
            startDate: f.get('startDate') as string,
            endDate: f.get('endDate') as string,
            reason: f.get('reason') as string
        });
        toast.success('Solicitação de ausência enviada.');
        setIsAbsenceModalOpen(false);
        loadData();
    } catch (e) {
        toast.error('Erro ao solicitar ausência.');
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleSubmitReview = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedEmployeeId) return;
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);

    const review: PerformanceReview = {
        id: `REV-${Date.now()}`,
        cycleId: '2024-Q1', // Mock cycle
        employeeId: selectedEmployeeId,
        evaluatorId: currentUser?.id || 'sys',
        selfRating: 0,
        managerRating: Number(f.get('rating')),
        feedback: f.get('feedback') as string,
        status: 'FINALIZED',
        completedAt: new Date().toISOString()
    };

    try {
        await HRService.submitPerformanceReview(review);
        toast.success('Avaliação de desempenho registrada.');
        setIsReviewModalOpen(false);
        loadData();
    } catch(e) {
        toast.error('Erro ao salvar avaliação.');
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleUploadDoc = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedEmployeeId) return;
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    const doc: HRDocument = {
        id: `DOC-${Date.now()}`,
        employeeId: selectedEmployeeId,
        title: f.get('title') as string,
        type: f.get('type') as any,
        url: '#', // Em produção, upload real
        uploadDate: new Date().toISOString(),
        status: 'VALIDADO'
    };

    try {
        await FirestoreService.save('hr_docs', doc.id, doc);
        toast.success('Documento arquivado no GED Pessoal.');
        setIsDocModalOpen(false);
        loadData();
    } catch (e) {
        toast.error('Erro ao salvar documento.');
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleCostCalculation = async () => {
    if (!selectedEmployee || !projects.length) return;
    try {
      const targetProject = projects[0];
      const hours = Math.floor(Math.random() * 100); 
      
      const allocation = await HRService.calculateProjectCost(
        selectedEmployee, 
        targetProject, 
        hours, 
        new Date().toISOString().slice(0, 7)
      );
      
      toast.success(`Custo calculado: R$ ${allocation.totalCost.toLocaleString()} para ${targetProject.name}`);
    } catch (e) {
      toast.error('Erro no algoritmo de custeio.');
    }
  };

  if (isLoading) return <div className="flex justify-center p-20"><Loader2 className="animate-spin text-pink-500" /></div>;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-700 pb-20">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black tracking-tighter dark:text-white">Capital Humano</h2>
          <p className="text-pink-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Gestão de Talentos & Performance</p>
        </div>
        <div className="flex gap-4">
           {selectedEmployee && (
             <div className="flex items-center gap-2 px-4 py-2 bg-pink-50 rounded-xl border border-pink-100 animate-in fade-in slide-in-from-right-5">
                <UserCircle size={18} className="text-pink-600"/>
                <span className="text-xs font-bold text-pink-700">{selectedEmployee.name}</span>
                <button onClick={() => setSelectedEmployeeId(null)} className="ml-2 text-pink-400 hover:text-pink-600"><XCircle size={14}/></button>
             </div>
           )}
           <Button onClick={() => { setEditingEmployee(null); setIsModalOpen(true); }} className="px-8 bg-pink-500 hover:bg-pink-600 shadow-pink-500/20 rounded-2xl h-12 font-black uppercase"><Plus size={18} /> Admissão</Button>
        </div>
      </div>

      <nav className="flex p-1 glass rounded-[40px] w-fit overflow-x-auto no-scrollbar shadow-xl border-white/20">
        {[
          { id: 'STAFF', label: 'Quadro (Core)', icon: <Users size={18}/> },
          { id: 'TIME', label: 'Jornada & Ponto', icon: <Clock size={18}/> },
          { id: 'TALENT', label: 'Performance', icon: <Award size={18}/> },
          { id: 'DOCS', label: 'GED Pessoal', icon: <FileText size={18}/> },
          { id: 'COSTS', label: 'Custo Real', icon: <Calculator size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-pink-600 text-white shadow-xl shadow-pink-500/20' : 'text-slate-500 hover:text-pink-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      {/* --- TAB: QUADRO (CORE) --- */}
      {activeTab === 'STAFF' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-black dark:text-white">Colaboradores Ativos</h3>
            {staff.map(s => (
              <div 
                key={s.id} 
                className={`p-6 rounded-[32px] glass flex items-center justify-between group hover:border-pink-500 transition-all border cursor-pointer ${selectedEmployeeId === s.id ? 'border-pink-500 ring-2 ring-pink-500/20' : 'border-slate-100 dark:border-slate-800'}`}
                onClick={() => setSelectedEmployeeId(s.id)}
              >
                <div className="flex items-center gap-6">
                  <div className="w-14 h-14 bg-pink-100 text-pink-600 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner uppercase">{s.name.charAt(0)}</div>
                  <div>
                    <h4 className="text-lg font-black dark:text-white">{s.name}</h4>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{s.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                    <Badge color={s.status === 'ATIVO' ? 'emerald' : 'amber'}>{s.status}</Badge>
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={(e) => { e.stopPropagation(); setEditingEmployee(s); setIsModalOpen(true); }} className="p-2 bg-white dark:bg-slate-800 rounded-xl hover:text-pink-600 shadow-sm border border-slate-100"><Edit2 size={16}/></button>
                        <button onClick={(e) => { e.stopPropagation(); setEmployeeToDelete(s); setIsDeleteDialogOpen(true); }} className="p-2 bg-white dark:bg-slate-800 rounded-xl hover:text-rose-500 shadow-sm border border-slate-100"><Trash2 size={16}/></button>
                    </div>
                </div>
              </div>
            ))}
          </div>
          <div className="glass p-8 rounded-[40px] border-l-4 border-pink-500 h-fit">
             <h4 className="text-lg font-black mb-4">Estatísticas do Quadro</h4>
             <div className="grid grid-cols-2 gap-6">
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase">Headcount</p>
                   <p className="text-4xl font-black text-slate-800 dark:text-white">{staff.length}</p>
                </div>
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase">Folha Mensal</p>
                   <p className="text-4xl font-black text-pink-600">R$ {staff.reduce((acc, s) => acc + s.salary, 0).toLocaleString()}</p>
                </div>
             </div>
          </div>
        </div>
      )}

      {/* --- TAB: PONTO & JORNADA --- */}
      {activeTab === 'TIME' && (
        <div className="space-y-8">
           {!selectedEmployeeId ? (
             <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-[40px]">
                <p className="text-slate-400 font-bold uppercase text-xs">Selecione um colaborador no Quadro para gerenciar o ponto.</p>
             </div>
           ) : (
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card title="Registro de Ponto Eletrônico" className="glass border-pink-500/20">
                   <div className="text-center py-8">
                      <div className="text-6xl font-black text-slate-800 dark:text-white mb-2">
                         {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-8">{new Date().toLocaleDateString()}</p>
                      <Button onClick={handleClockIn} className="w-full h-16 bg-pink-600 hover:bg-pink-700 text-lg font-black uppercase rounded-2xl shadow-xl shadow-pink-500/30">Registrar Ponto</Button>
                   </div>
                   <div className="mt-6 border-t border-slate-100 pt-4">
                      <h4 className="text-xs font-black uppercase text-slate-400 mb-3">Histórico Recente</h4>
                      {timeRecords.filter(t => t.employeeId === selectedEmployeeId).slice(0, 3).map(t => (
                          <div key={t.id} className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                              <span className="text-xs font-bold text-slate-600">{new Date(t.date).toLocaleDateString()}</span>
                              <div className="flex gap-2">
                                  {t.entries.map((e, i) => <Badge key={i} color="slate">{new Date(e).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</Badge>)}
                              </div>
                          </div>
                      ))}
                   </div>
                </Card>
                <div className="space-y-6">
                   <Card title="Gestão de Ausências" className="glass">
                      <div className="flex justify-between items-center mb-6">
                          <p className="text-xs text-slate-500">Solicitações de férias e atestados.</p>
                          <Button onClick={() => setIsAbsenceModalOpen(true)} className="bg-pink-600 h-8 text-[10px] font-black uppercase">Nova Solicitação</Button>
                      </div>
                      <div className="space-y-3">
                          {absences.filter(a => a.employeeId === selectedEmployeeId).map(abs => (
                              <div key={abs.id} className="p-4 bg-white/50 rounded-2xl border border-slate-100 flex justify-between items-center">
                                  <div>
                                      <p className="text-xs font-black uppercase text-pink-600">{abs.type}</p>
                                      <p className="text-[10px] font-bold text-slate-400">{new Date(abs.startDate).toLocaleDateString()} até {new Date(abs.endDate).toLocaleDateString()}</p>
                                  </div>
                                  <Badge color={abs.status === 'APPROVED' ? 'emerald' : 'amber'}>{abs.status}</Badge>
                              </div>
                          ))}
                          {absences.filter(a => a.employeeId === selectedEmployeeId).length === 0 && <p className="text-center text-xs text-slate-300 font-bold uppercase py-4">Nenhuma ausência registrada.</p>}
                      </div>
                   </Card>
                </div>
             </div>
           )}
        </div>
      )}

      {/* --- TAB: TALENTOS (PERFORMANCE) --- */}
      {activeTab === 'TALENT' && (
          <div className="space-y-8">
              {!selectedEmployeeId ? (
                  <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-[40px]">
                      <p className="text-slate-400 font-bold uppercase text-xs">Selecione um colaborador para ver o histórico de performance.</p>
                  </div>
              ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <Card title="Avaliações de Desempenho" className="glass border-pink-500/20">
                          <div className="flex justify-end mb-4">
                              <Button onClick={() => setIsReviewModalOpen(true)} className="bg-pink-600 gap-2 font-black uppercase text-xs"><Star size={14}/> Nova Avaliação</Button>
                          </div>
                          <div className="space-y-4">
                              {reviews.filter(r => r.employeeId === selectedEmployeeId).map(rev => (
                                  <div key={rev.id} className="p-6 rounded-3xl bg-white/50 border border-slate-100 flex flex-col gap-3">
                                      <div className="flex justify-between items-start">
                                          <Badge color="pink">{rev.cycleId}</Badge>
                                          <div className="flex gap-1">
                                              {[...Array(5)].map((_, i) => (
                                                  <Star key={i} size={14} className={i < rev.managerRating ? "text-amber-400 fill-amber-400" : "text-slate-200"} />
                                              ))}
                                          </div>
                                      </div>
                                      <p className="text-sm font-medium text-slate-600 italic">"{rev.feedback}"</p>
                                      <p className="text-[9px] text-slate-400 font-bold uppercase text-right">Avaliador: {rev.evaluatorId === 'sys' ? 'Sistema' : 'Gestor'}</p>
                                  </div>
                              ))}
                              {reviews.filter(r => r.employeeId === selectedEmployeeId).length === 0 && (
                                  <p className="text-center text-xs text-slate-400 py-10 uppercase font-bold">Nenhuma avaliação encontrada.</p>
                              )}
                          </div>
                      </Card>
                      <Card title="Plano de Desenvolvimento Individual (PDI)" className="glass">
                          <div className="p-6 text-center text-slate-400 text-xs font-bold uppercase border-2 border-dashed border-slate-200 rounded-3xl">
                              Módulo de PDI em desenvolvimento.
                          </div>
                      </Card>
                  </div>
              )}
          </div>
      )}

      {/* --- TAB: DOCS (GED) --- */}
      {activeTab === 'DOCS' && (
          <div className="space-y-8">
              {!selectedEmployeeId ? (
                  <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-[40px]">
                      <p className="text-slate-400 font-bold uppercase text-xs">Selecione um colaborador para acessar o dossiê digital.</p>
                  </div>
              ) : (
                  <div className="space-y-6">
                      <div className="flex justify-between items-center">
                          <h3 className="text-2xl font-black dark:text-white">Dossiê Digital (GED Pessoal)</h3>
                          <Button onClick={() => setIsDocModalOpen(true)} className="bg-indigo-600 gap-2"><UploadCloud size={18}/> Novo Documento</Button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          {documents.filter(d => d.employeeId === selectedEmployeeId).map(doc => (
                              <div key={doc.id} className="p-6 rounded-3xl glass border border-slate-100 hover:border-indigo-500 transition-all group cursor-pointer">
                                  <div className="flex justify-between items-start mb-4">
                                      <div className="p-3 bg-indigo-50 rounded-2xl text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                          <FileText size={24}/>
                                      </div>
                                      <Badge color="emerald">{doc.status}</Badge>
                                  </div>
                                  <h4 className="font-black text-sm dark:text-white truncate">{doc.title}</h4>
                                  <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">{doc.type}</p>
                                  <p className="text-[9px] text-slate-300 font-bold uppercase mt-4">Enviado em {new Date(doc.uploadDate).toLocaleDateString()}</p>
                              </div>
                          ))}
                          {documents.filter(d => d.employeeId === selectedEmployeeId).length === 0 && (
                              <div className="col-span-3 py-20 text-center glass rounded-[40px]">
                                  <Paperclip size={48} className="mx-auto text-slate-200 mb-4"/>
                                  <p className="text-slate-400 font-bold uppercase">Pasta vazia.</p>
                              </div>
                          )}
                      </div>
                  </div>
              )}
          </div>
      )}

      {/* --- TAB: CUSTO REAL --- */}
      {activeTab === 'COSTS' && (
         <div className="space-y-8">
            <div className="p-6 bg-indigo-50 dark:bg-indigo-900/10 rounded-[32px] border border-indigo-100 flex gap-4 items-center">
               <Calculator className="text-indigo-600" size={32} />
               <div className="flex-1">
                  <h4 className="font-black text-indigo-800 dark:text-indigo-300 text-sm uppercase tracking-widest">Algoritmo de Rateio Financeiro</h4>
                  <p className="text-xs text-indigo-700/70 dark:text-indigo-400 mt-1">
                     O sistema calcula o custo hora real (Salário + 60% Encargos / 220h) e cruza com a alocação em projetos.
                  </p>
               </div>
               <Button onClick={handleCostCalculation} disabled={!selectedEmployeeId} className="bg-indigo-600 font-black uppercase text-[10px]">Executar Rateio</Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <Card title="Simulação de Custo Hora" className="glass">
                  {selectedEmployee ? (
                     <div className="space-y-6 mt-4">
                        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                           <span className="text-xs font-bold text-slate-500">Salário Base</span>
                           <span className="font-black">R$ {selectedEmployee.salary.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                           <span className="text-xs font-bold text-slate-500">Encargos (+60%)</span>
                           <span className="font-black text-rose-500">+ R$ {(selectedEmployee.salary * 0.6).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center pt-2">
                           <span className="text-sm font-black text-indigo-600 uppercase tracking-widest">Custo Hora Efetivo</span>
                           <span className="text-2xl font-black text-indigo-600">R$ {((selectedEmployee.salary * 1.6) / 220).toFixed(2)}</span>
                        </div>
                     </div>
                  ) : (
                     <p className="text-center py-10 text-slate-400 text-xs font-bold uppercase">Selecione um colaborador.</p>
                  )}
               </Card>
            </div>
         </div>
      )}

      {/* --- MODAIS --- */}

      {/* Modal Admissão / Edição */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={editingEmployee ? "Editar Cadastro" : "Admissão de Colaborador"}>
        <form onSubmit={handleSaveEmployee} className="space-y-6">
          <Input label="Nome Completo" name="name" defaultValue={editingEmployee?.name} required />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Cargo / Função" name="role" defaultValue={editingEmployee?.role} required />
            <Input label="Departamento" name="department" defaultValue={editingEmployee?.department} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Salário Base (R$)" name="salary" type="number" defaultValue={editingEmployee?.salary} required />
            <Input label="Data Admissão" name="date" type="date" defaultValue={editingEmployee?.admissionDate} required />
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Status</label>
             <select name="status" defaultValue={editingEmployee?.status || 'ATIVO'} className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                <option value="ATIVO">Ativo</option>
                <option value="FÉRIAS">Férias</option>
                <option value="AFASTADO">Afastado</option>
             </select>
          </div>
          <div className="flex justify-end gap-4 pt-4">
             <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
             <Button type="submit" loading={isSubmitting} className="bg-pink-600 hover:bg-pink-700">{editingEmployee ? 'Salvar Alterações' : 'Registrar Contrato'}</Button>
          </div>
        </form>
      </Modal>

      {/* Modal Ausência */}
      <Modal isOpen={isAbsenceModalOpen} onClose={() => setIsAbsenceModalOpen(false)} title="Solicitação de Ausência">
          <form onSubmit={handleRequestAbsence} className="space-y-6">
              <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Tipo</label>
                  <select name="type" className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                      <option value="FERIAS">Férias</option>
                      <option value="ATESTADO">Atestado Médico</option>
                      <option value="FOLGA_BANCO">Folga (Banco de Horas)</option>
                  </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <Input label="Início" name="startDate" type="date" required />
                  <Input label="Fim" name="endDate" type="date" required />
              </div>
              <Input label="Motivo / Observação" name="reason" required />
              <Button type="submit" loading={isSubmitting} className="w-full bg-pink-600">Enviar Solicitação</Button>
          </form>
      </Modal>

      {/* Modal Review */}
      <Modal isOpen={isReviewModalOpen} onClose={() => setIsReviewModalOpen(false)} title="Nova Avaliação de Performance">
          <form onSubmit={handleSubmitReview} className="space-y-6">
              <div className="p-6 bg-slate-50 rounded-3xl text-center">
                  <p className="text-xs font-bold text-slate-500 uppercase mb-4">Nota Geral (1-5)</p>
                  <div className="flex justify-center gap-4">
                      {[1, 2, 3, 4, 5].map(n => (
                          <label key={n} className="cursor-pointer">
                              <input type="radio" name="rating" value={n} className="peer sr-only" required />
                              <div className="w-10 h-10 rounded-full bg-white border-2 border-slate-200 peer-checked:bg-amber-400 peer-checked:border-amber-400 flex items-center justify-center font-black peer-checked:text-white transition-all hover:scale-110">
                                  {n}
                              </div>
                          </label>
                      ))}
                  </div>
              </div>
              <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Feedback Qualitativo</label>
                  <textarea name="feedback" required className="w-full p-4 rounded-2xl glass border-none h-32 text-sm font-medium shadow-inner" placeholder="Pontos fortes e áreas de desenvolvimento..."></textarea>
              </div>
              <Button type="submit" loading={isSubmitting} className="w-full bg-pink-600">Registrar Avaliação</Button>
          </form>
      </Modal>

      {/* Modal Documento */}
      <Modal isOpen={isDocModalOpen} onClose={() => setIsDocModalOpen(false)} title="Arquivar Documento (GED)">
          <form onSubmit={handleUploadDoc} className="space-y-6">
              <Input label="Título do Documento" name="title" required />
              <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase">Tipo Documental</label>
                  <select name="type" className="w-full p-4 rounded-2xl glass border-none font-bold text-sm">
                      <option value="CONTRATO">Contrato de Trabalho</option>
                      <option value="IDENTIDADE">Documento de Identidade</option>
                      <option value="CERTIFICADO">Certificado / Diploma</option>
                      <option value="COMPROVANTE_RESIDENCIA">Comprovante de Residência</option>
                  </select>
              </div>
              <div className="p-10 border-2 border-dashed border-slate-200 rounded-3xl text-center cursor-pointer hover:bg-slate-50 transition-all">
                  <Paperclip size={32} className="mx-auto text-slate-300 mb-2"/>
                  <p className="text-xs font-bold text-slate-400 uppercase">Arraste o arquivo ou clique</p>
              </div>
              <Button type="submit" loading={isSubmitting} className="w-full bg-indigo-600">Upload Seguro</Button>
          </form>
      </Modal>

      <ConfirmDialog 
        isOpen={isDeleteDialogOpen} 
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleDeleteEmployee}
        title="Confirmar Desligamento"
        message={`Tem certeza que deseja remover ${employeeToDelete?.name} da folha? Esta ação é irreversível e removerá o acesso do usuário.`}
      />

    </div>
  );
};

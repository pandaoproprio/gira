
import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Badge, Input } from '../components/UI';
import { 
  ShieldCheck, 
  Database, 
  Terminal, 
  Lock, 
  Globe, 
  Bell,
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  Loader2
} from 'lucide-react';
import { mockDB } from '../services/mockDB';
import { FirestoreService } from '../services/FirestoreService';
import { PERMISSIONS } from '../constants';
import { AuditLog } from '../types';
import { DataBackup } from '../components/DataBackup';

export const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'general' | 'roles' | 'security' | 'audit'>('general');
  
  // State para Auditoria
  const [allLogs, setAllLogs] = useState<AuditLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Atualizar logs ao entrar na aba (AGORA DO FIRESTORE)
  useEffect(() => {
    if (activeTab === 'audit') {
      const fetchLogs = async () => {
        setIsLoadingLogs(true);
        try {
          // Busca real do Firestore
          const logs = await FirestoreService.getAll<AuditLog>('auditLogs');
          setAllLogs(logs.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
        } catch (error) {
          console.error("Erro ao buscar logs", error);
        } finally {
          setIsLoadingLogs(false);
        }
      };
      fetchLogs();
    }
  }, [activeTab]);

  // Lógica de Filtragem Multi-Campo
  const filteredLogs = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    if (!term) return allLogs;
    
    return allLogs.filter(log => 
      log.action.toLowerCase().includes(term) ||
      log.module.toLowerCase().includes(term) ||
      log.details.toLowerCase().includes(term) ||
      log.ip.toLowerCase().includes(term)
    );
  }, [allLogs, searchTerm]);

  // Lógica de Paginação
  const totalPages = Math.max(1, Math.ceil(filteredLogs.length / itemsPerPage));
  const currentLogsSlice = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredLogs.slice(start, start + itemsPerPage);
  }, [filteredLogs, currentPage]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset para a primeira página ao buscar
  };

  return (
    <div className="space-y-6">
      <div className="animate-in fade-in slide-in-from-left-4 duration-500">
        <h2 className="text-4xl font-black text-slate-800 dark:text-white tracking-tighter">Configurações <span className="gradient-text">Estruturais</span></h2>
        <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Parâmetros globais e auditoria do nodo</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <aside className="space-y-2">
          {[
            { id: 'general', label: 'Geral', icon: <Globe size={18} /> },
            { id: 'roles', label: 'Matriz de Perfis', icon: <ShieldCheck size={18} /> },
            { id: 'security', label: 'Segurança & Backup', icon: <Lock size={18} /> },
            { id: 'audit', label: 'Logs de Auditoria', icon: <Terminal size={18} /> },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl transition-all duration-300 font-black text-xs uppercase tracking-widest ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800 hover:text-indigo-600'}`}
            >
              {item.icon} {item.label}
            </button>
          ))}
        </aside>

        <div className="md:col-span-3">
          {activeTab === 'audit' && (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
              <Card 
                title="Registros de Atividade" 
                subtitle="Trilha de Auditoria Transversal (Cloud Sync)"
                action={<Button variant="outline" className="h-10 text-[10px] px-4"><Download size={14} className="mr-2" /> Exportar CSV</Button>}
              >
                {/* Filtro de Busca */}
                <div className="mb-8 relative group">
                  <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                  <input
                    type="text"
                    placeholder="Filtrar por ação, módulo, detalhes ou IP..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="w-full pl-14 pr-6 py-4 rounded-3xl glass bg-slate-100/50 dark:bg-slate-800/50 border-none focus:ring-4 focus:ring-indigo-500/10 dark:text-white font-bold text-sm transition-all shadow-inner"
                  />
                </div>

                <div className="space-y-4">
                  {isLoadingLogs ? (
                    <div className="py-20 flex justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>
                  ) : currentLogsSlice.length === 0 ? (
                    <div className="py-24 text-center glass rounded-[40px]">
                       <Terminal size={48} className="mx-auto text-slate-200 mb-6" />
                       <p className="text-slate-400 font-bold uppercase tracking-widest">Nenhum evento localizado no radar.</p>
                    </div>
                  ) : (
                    currentLogsSlice.map(log => (
                      <div key={log.id} className="p-6 rounded-[28px] border border-slate-50 dark:border-slate-800/50 glass hover:border-indigo-500/30 transition-all group flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex gap-5 items-start">
                          <div className={`w-10 h-10 rounded-xl glass flex items-center justify-center shrink-0 shadow-lg ${log.criticality === 'CRITICAL' ? 'text-rose-500' : 'text-indigo-500'}`}>
                            <Terminal size={18} />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                                <p className="text-sm font-black text-slate-800 dark:text-white">{log.action}</p>
                                <Badge color={log.criticality === 'CRITICAL' ? 'rose' : log.criticality === 'WARN' ? 'amber' : 'slate'}>{log.criticality}</Badge>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium leading-relaxed">{log.details}</p>
                            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-3">
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-1"><Clock size={12}/> {new Date(log.timestamp).toLocaleString('pt-BR')}</span>
                              <span className="text-[10px] text-indigo-500 font-black uppercase tracking-widest">{log.userName}</span>
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest flex items-center gap-1"><Globe size={12}/> {log.ip}</span>
                            </div>
                          </div>
                        </div>
                        <Badge color="indigo">{log.module}</Badge>
                      </div>
                    ))
                  )}
                </div>

                {/* Controles de Paginação */}
                {totalPages > 1 && (
                  <div className="flex flex-col sm:flex-row items-center justify-between mt-10 pt-8 border-t border-slate-100 dark:border-slate-800 gap-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">
                      Exibindo Página {currentPage} de {totalPages} • Total {filteredLogs.length} Entradas
                    </p>
                    <div className="flex gap-3">
                      <Button 
                        variant="outline" 
                        className="h-12 w-12 rounded-2xl p-0" 
                        disabled={currentPage === 1} 
                        onClick={() => setCurrentPage(p => p - 1)}
                      >
                        <ChevronLeft size={18} />
                      </Button>
                      <div className="flex gap-2">
                         {[...Array(totalPages)].map((_, i) => {
                            const pageNum = i + 1;
                            if (pageNum === 1 || pageNum === totalPages || (pageNum >= currentPage - 1 && pageNum <= currentPage + 1)) {
                               return (
                                 <button
                                   key={pageNum}
                                   onClick={() => setCurrentPage(pageNum)}
                                   className={`w-12 h-12 rounded-2xl text-[10px] font-black transition-all ${currentPage === pageNum ? 'bg-indigo-600 text-white shadow-lg' : 'glass text-slate-400 hover:text-indigo-600'}`}
                                 >
                                   {pageNum}
                                 </button>
                               );
                            }
                            if (pageNum === currentPage - 2 || pageNum === currentPage + 2) {
                               return <span key={pageNum} className="flex items-end px-1 text-slate-300">...</span>;
                            }
                            return null;
                         })}
                      </div>
                      <Button 
                        variant="outline" 
                        className="h-12 w-12 rounded-2xl p-0" 
                        disabled={currentPage === totalPages} 
                        onClick={() => setCurrentPage(p => p + 1)}
                      >
                        <ChevronRight size={18} />
                      </Button>
                    </div>
                  </div>
                )}
              </Card>
            </div>
          )}

          {activeTab === 'roles' && (
             <Card title="Matriz de Permissões RBAC" subtitle="Visualização por Perfil Institucional">
                <div className="overflow-x-auto mt-6">
                   <table className="w-full text-sm">
                      <thead>
                         <tr>
                            <th className="text-left py-4 px-6 bg-slate-50 dark:bg-slate-900/50 font-black text-slate-400 uppercase text-[10px] tracking-widest rounded-tl-2xl">Permissão / Módulo</th>
                            <th className="py-4 px-6 bg-indigo-50 dark:bg-indigo-900/20 font-black text-indigo-600 text-center text-[10px] tracking-widest">SuperAdmin</th>
                            <th className="py-4 px-6 bg-slate-50 dark:bg-slate-900/50 font-black text-slate-400 text-center text-[10px] tracking-widest">Direção</th>
                            <th className="py-4 px-6 bg-slate-50 dark:bg-slate-900/50 font-black text-slate-400 text-center text-[10px] tracking-widest rounded-tr-2xl">Analista</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                         {PERMISSIONS.slice(0, 12).map(perm => (
                           <tr key={perm.code} className="hover:bg-slate-500/[0.02] transition-colors">
                              <td className="py-5 px-6">
                                 <p className="font-black text-slate-800 dark:text-white leading-none">{perm.label}</p>
                                 <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-2">{perm.module}</p>
                              </td>
                              <td className="py-5 px-6 text-center"><div className="w-2.5 h-2.5 rounded-full bg-indigo-500 mx-auto shadow-lg shadow-indigo-500/40"></div></td>
                              <td className="py-5 px-6 text-center"><div className="w-2.5 h-2.5 rounded-full bg-indigo-300 mx-auto opacity-50"></div></td>
                              <td className="py-5 px-6 text-center"><div className="w-2.5 h-2.5 border-2 border-slate-200 dark:border-slate-700 rounded-full mx-auto"></div></td>
                           </tr>
                         ))}
                      </tbody>
                   </table>
                </div>
             </Card>
          )}

          {activeTab === 'security' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
               <DataBackup />
               
               <Card title="Criptografia & API" subtitle="Chaves e Acesso Externo">
                  <p className="text-sm text-slate-500 dark:text-slate-400 mb-8 font-medium">Gerencie chaves de criptografia RSA e credenciais de integração com parceiros governamentais.</p>
                  <Button variant="outline" className="w-full h-16 rounded-2xl gap-3 text-sm font-black uppercase tracking-widest border-indigo-500/20 text-indigo-600"><Globe size={20} /> Configurar Integrações</Button>
               </Card>
            </div>
          )}

          {activeTab === 'general' && (
             <Card title="Parâmetros Gerais" subtitle="Personalização da Interface Operacional">
                <div className="space-y-6 mt-4">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-6 rounded-3xl border border-slate-100 dark:border-slate-800 glass flex justify-between items-center group hover:border-indigo-500/30 transition-all">
                         <div>
                            <p className="font-black text-slate-800 dark:text-white uppercase tracking-widest text-xs">Modo Escuro Automático</p>
                            <p className="text-[10px] text-slate-500 font-bold mt-1 uppercase tracking-widest">Baseado no ciclo circadiano</p>
                         </div>
                         <div className="w-12 h-6 bg-indigo-600 rounded-full relative cursor-pointer shadow-lg shadow-indigo-500/20">
                            <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-all"></div>
                         </div>
                      </div>
                      <div className="p-6 rounded-3xl border border-slate-100 dark:border-slate-800 glass flex justify-between items-center group hover:border-indigo-500/30 transition-all">
                         <div>
                            <p className="font-black text-slate-800 dark:text-white uppercase tracking-widest text-xs">Notificações Críticas</p>
                            <p className="text-[10px] text-slate-500 font-bold mt-1 uppercase tracking-widest">Alertas de estoque e budget</p>
                         </div>
                         <div className="w-12 h-6 bg-slate-200 dark:bg-slate-700 rounded-full relative cursor-pointer">
                            <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-all"></div>
                         </div>
                      </div>
                   </div>
                   <div className="pt-8 border-t border-slate-50 dark:border-slate-800 flex justify-end">
                      <Button variant="outline" className="gap-3 h-14 rounded-2xl text-[10px] font-black uppercase tracking-widest"><Bell size={18} /> Testar Notificações PUSH</Button>
                   </div>
                </div>
             </Card>
          )}
        </div>
      </div>
    </div>
  );
};


import React, { useState, useMemo } from 'react';
import { Card, Button, Badge, Modal, Input, useToast } from '../components/UI';
import { 
  FileText, Download, Sparkles, Plus, Search, 
  ChevronRight, Calendar, User, TrendingUp, BarChart3, 
  Loader2, Printer, Trash2, PieChart
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Cell, Legend
} from 'recharts';
import { mockDB } from '../services/mockDB';
import { InstitutionalReport } from '../types';
import { useAuth } from '../context/AuthContext';
import { GoogleGenAI } from "@google/genai";
import { pdfService } from '../services/pdfService';

export const Reports: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  const [reports, setReports] = useState<InstitutionalReport[]>(mockDB.getInstitutionalReports());
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAiGenerating, setIsAiGenerating] = useState(false);

  // Form State
  const [newReport, setNewReport] = useState<Partial<InstitutionalReport>>({
    title: 'Relatório Narrativo - Mutirão de Amor',
    period: '',
    type: 'MENSAL',
    summary: '',
    indicators: {
      directImpact: 0,
      indirectImpact: 0,
      foodDistributedKg: 0,
      basketsDistributed: 0
    }
  });

  const filteredReports = useMemo(() => {
    return reports.filter(r => 
      r.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      r.period.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [reports, searchTerm]);

  // Chart Data: Impact Growth
  const chartData = useMemo(() => {
    return reports.slice().reverse().map(r => ({
      name: r.period.split(' / ')[0],
      alimentos: r.indicators.foodDistributedKg,
      familias: r.indicators.directImpact
    }));
  }, [reports]);

  const handleAiSynthesize = async () => {
    if (!newReport.period) return toast.error('Selecione o período primeiro.');
    setIsAiGenerating(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Como um analista de impacto social do CEAP, escreva um resumo executivo de 4 a 5 linhas para o relatório do período ${newReport.period}. 
      Dados quantitativos para o texto: ${newReport.indicators?.directImpact} famílias atendidas, ${newReport.indicators?.foodDistributedKg}kg de alimentos e ${newReport.indicators?.basketsDistributed} cestas. 
      Foco em transparência e impacto social positivo.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setNewReport(prev => ({ ...prev, summary: response.text || '' }));
      toast.success('Síntese gerada com sucesso pela Cognição ATIS.');
    } catch (e) {
      toast.error('Erro na matriz neural. Tente escrever manualmente.');
    } finally {
      setIsAiGenerating(false);
    }
  };

  const handleSaveReport = () => {
    if (!newReport.period || !newReport.summary) return toast.error('Preencha todos os campos vitais.');
    
    const reportToSave: InstitutionalReport = {
      id: `rep-${Date.now()}`,
      title: newReport.title!,
      period: newReport.period!,
      type: newReport.type!,
      generatedBy: currentUser?.name || 'Sistema',
      summary: newReport.summary!,
      indicators: newReport.indicators as any,
      status: 'FINAL',
      createdAt: new Date().toISOString()
    };

    mockDB.saveInstitutionalReport(reportToSave);
    setReports(mockDB.getInstitutionalReports());
    setIsModalOpen(false);
    toast.success('Relatório protocolado e arquivado.');
  };

  const handleDownloadPdf = (report: InstitutionalReport) => {
    pdfService.generateInstitutionalReportPdf(report);
    toast.success('Arquivo PDF pronto para compartilhamento.');
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black text-sky-600 tracking-tighter">Relatórios</h2>
          <p className="text-slate-400 font-medium text-sm mt-1">Sistematização de resultados e impacto social institucional.</p>
        </div>
        <Button onClick={() => setIsModalOpen(true)} className="bg-sky-600 hover:bg-sky-700 h-14 px-8 rounded-2xl gap-2 font-black uppercase text-sm shadow-lg shadow-sky-500/20">
          <Plus size={20} /> Novo Relatório
        </Button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Gráfico de Impacto */}
        <Card className="lg:col-span-2 glass" title="Crescimento de Impacto" subtitle="Distribuição de Alimentos vs Famílias Atendidas">
          <div className="h-[300px] mt-6">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{fontSize: 11, fontWeight: 700, fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                <YAxis tick={{fontSize: 11, fontWeight: 700, fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                <Legend />
                <Bar dataKey="alimentos" name="Alimentos (kg)" fill="#0284c7" radius={[6, 6, 0, 0]} />
                <Bar dataKey="familias" name="Famílias" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Card de Resumo Rápido */}
        <Card className="glass" title="Radar Institucional">
           <div className="space-y-6 mt-4">
              <div className="p-5 rounded-2xl bg-sky-50 dark:bg-sky-900/10 border border-sky-100 flex items-center justify-between">
                 <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase">Média de Alimentos</p>
                    <p className="text-2xl font-black text-sky-600">1.750 kg</p>
                 </div>
                 <TrendingUp className="text-sky-500" />
              </div>
              <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 flex items-center justify-between">
                 <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase">Atenção às Famílias</p>
                    <p className="text-2xl font-black text-emerald-600">90 / mês</p>
                 </div>
                 <Badge color="emerald">+12%</Badge>
              </div>
           </div>
        </Card>
      </div>

      <div className="relative group">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-sky-500 transition-colors" size={20} />
        <input 
          type="text" 
          placeholder="Filtrar por período ou título..." 
          className="w-full pl-16 pr-6 py-5 rounded-2xl border-none bg-white dark:bg-slate-800 focus:ring-4 focus:ring-sky-500/10 transition-all font-bold text-sm shadow-sm"
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredReports.map(report => (
          <Card key={report.id} glass={false} className="bg-white border-slate-100 rounded-3xl p-0 hover:shadow-xl transition-all overflow-hidden border">
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
                      <FileText size={20} />
                   </div>
                   <div>
                      <h4 className="font-black text-slate-800 leading-none">{report.period}</h4>
                      <p className="text-[10px] font-bold text-slate-400 uppercase mt-1">Ref: {report.title}</p>
                   </div>
                </div>
                {/* Changed color from 'sky' to 'indigo' to fix TypeScript error */}
                <Badge color="indigo">{report.type}</Badge>
              </div>

              <p className="text-sm text-slate-500 font-medium line-clamp-3 leading-relaxed mb-8">
                {report.summary}
              </p>

              <div className="grid grid-cols-2 gap-4">
                 <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="text-[9px] font-black text-slate-400 uppercase">Impacto Direto</p>
                    <p className="text-base font-black text-slate-800">{report.indicators.directImpact} famílias</p>
                 </div>
                 <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="text-[9px] font-black text-slate-400 uppercase">Logística de Alimentos</p>
                    <p className="text-base font-black text-slate-800">{report.indicators.foodDistributedKg.toLocaleString()} kg</p>
                 </div>
              </div>
            </div>

            <div className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <div className="flex items-center gap-2 text-slate-400">
                  <User size={14} />
                  <span className="text-[10px] font-black uppercase">{report.generatedBy}</span>
               </div>
               <div className="flex gap-2">
                  <button onClick={() => handleDownloadPdf(report)} className="p-2.5 bg-white text-sky-600 hover:bg-sky-600 hover:text-white rounded-xl transition-all shadow-sm border border-slate-200">
                    <Printer size={16} />
                  </button>
                  <button className="p-2.5 bg-white text-slate-400 hover:bg-rose-500 hover:text-white rounded-xl transition-all shadow-sm border border-slate-200">
                    <Trash2 size={16} />
                  </button>
               </div>
            </div>
          </Card>
        ))}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Protocolo de Relatório Narrativo" size="xl">
         <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <Input 
                label="Período de Referência" 
                placeholder="Ex: Fevereiro / 2024" 
                value={newReport.period} 
                onChange={e => setNewReport({...newReport, period: e.target.value})} 
               />
               <Input 
                label="Título do Documento" 
                placeholder="Relatório Narrativo Mensal" 
                value={newReport.title}
                onChange={e => setNewReport({...newReport, title: e.target.value})} 
               />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               <Input label="Impacto Direto" type="number" value={newReport.indicators?.directImpact} onChange={e => setNewReport({...newReport, indicators: {...newReport.indicators!, directImpact: Number(e.target.value)}})} />
               <Input label="Impacto Indireto" type="number" value={newReport.indicators?.indirectImpact} onChange={e => setNewReport({...newReport, indicators: {...newReport.indicators!, indirectImpact: Number(e.target.value)}})} />
               <Input label="Alimentos (kg)" type="number" value={newReport.indicators?.foodDistributedKg} onChange={e => setNewReport({...newReport, indicators: {...newReport.indicators!, foodDistributedKg: Number(e.target.value)}})} />
               <Input label="Cestas" type="number" value={newReport.indicators?.basketsDistributed} onChange={e => setNewReport({...newReport, indicators: {...newReport.indicators!, basketsDistributed: Number(e.target.value)}})} />
            </div>

            <div className="space-y-2">
               <div className="flex justify-between items-center px-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Resumo Narrativo de Impacto</label>
                  <button 
                    onClick={handleAiSynthesize}
                    disabled={isAiGenerating}
                    className="flex items-center gap-1.5 text-[10px] font-black text-sky-600 uppercase hover:text-sky-700 transition-colors disabled:opacity-50"
                  >
                    {isAiGenerating ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                    Sintetizar com IA
                  </button>
               </div>
               <textarea 
                className="w-full p-6 rounded-2xl border-2 border-slate-100 bg-slate-50 focus:border-sky-500 focus:bg-white focus:outline-none text-sm font-medium h-40 transition-all shadow-inner"
                placeholder="Descreva as principais conquistas e desafios do período..."
                value={newReport.summary}
                onChange={e => setNewReport({...newReport, summary: e.target.value})}
               ></textarea>
            </div>

            <div className="flex justify-end gap-4 pt-6">
               <Button variant="outline" onClick={() => setIsModalOpen(false)} className="px-10 h-14">Cancelar</Button>
               <Button onClick={handleSaveReport} className="bg-sky-600 h-14 px-12 rounded-2xl shadow-xl shadow-sky-500/20 font-black uppercase text-sm">Protocolar Resultados</Button>
            </div>
         </div>
      </Modal>
    </div>
  );
};

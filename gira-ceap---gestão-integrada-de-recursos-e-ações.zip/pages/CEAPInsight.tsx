
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Card, Button, Badge, useToast } from '../components/UI';
import { 
  BrainCircuit, Sparkles, Activity, TrendingUp, BarChart3, 
  ShieldCheck, FileText, Share2, Zap, AlertCircle, Bot, Globe, Download, Volume2, Loader2,
  Leaf, Users, Scale
} from 'lucide-react';
import { 
  ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip
} from 'recharts';
import { GoogleGenAI, Modality } from "@google/genai";
import { FirestoreService } from '../services/FirestoreService';
import { Beneficiary, Donation, Attendance, Project } from '../types';

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const CEAPInsight: React.FC = () => {
  const toast = useToast();
  const [activeTab, setActiveTab] = useState<'ESG_DASH' | 'SOCIAL' | 'ENVIRONMENTAL' | 'GOVERNANCE'>('ESG_DASH');
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const audioContextRef = useRef<AudioContext | null>(null);

  const [stats, setStats] = useState({
    beneficiaries: [] as Beneficiary[],
    donations: [] as Donation[],
    attendances: [] as Attendance[],
    projects: [] as Project[]
  });

  useEffect(() => {
    const loadRealData = async () => {
      try {
        const [bens, dons, atts, projs] = await Promise.all([
          FirestoreService.getAll<Beneficiary>('beneficiaries'),
          FirestoreService.getAll<Donation>('donations'),
          FirestoreService.getAll<Attendance>('attendances'),
          FirestoreService.getAll<Project>('projects')
        ]);
        setStats({ beneficiaries: bens, donations: dons, attendances: atts, projects: projs });
      } catch (e) {
        console.error("Erro ao carregar dados ESG", e);
      } finally {
        setIsLoadingData(false);
      }
    };
    loadRealData();
  }, []);

  const impactStats = useMemo(() => [
    { category: 'Social (Pessoas)', value: stats.beneficiaries.length, unit: 'Vidas', trend: 15, icon: <Users size={18}/>, color: 'text-rose-500', bg: 'bg-rose-100' },
    { category: 'Governança (Fundos)', value: stats.donations.reduce((acc, d) => acc + d.value, 0), unit: 'R$', trend: 8, icon: <Scale size={18}/>, color: 'text-indigo-500', bg: 'bg-indigo-100' },
    { category: 'Ambiental (Projetos)', value: stats.projects.length, unit: 'Ações', trend: 5, icon: <Leaf size={18}/>, color: 'text-emerald-500', bg: 'bg-emerald-100' },
    { category: 'Engajamento', value: stats.attendances.length, unit: 'Interações', trend: 22, icon: <Activity size={18}/>, color: 'text-amber-500', bg: 'bg-amber-100' }
  ], [stats]);

  const handleGenerateAiReport = async () => {
    setIsGenerating(true);
    setAiAnalysis(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Gere um Relatório de Impacto ESG para o GIRA CEAP baseado nestes dados:
      - Social: ${stats.beneficiaries.length} beneficiários e ${stats.attendances.length} atendimentos à comunidade negra.
      - Governança: R$ ${stats.donations.reduce((acc, d) => acc + d.value, 0).toLocaleString()} geridos com transparência.
      - Ações: ${stats.projects.length} projetos de economia criativa ativos.
      Destaque como esses números fortalecem o ecossistema da comunidade negra e a sustentabilidade das ações.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      setAiAnalysis(response.text || 'Análise indisponível.');
      toast.success('Relatório ESG gerado com inteligência artificial.');
    } catch (e) {
      toast.error('Erro ao conectar com API Gemini.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSpeakReport = async () => {
    if (!aiAnalysis || isSpeaking) return;
    setIsSpeaking(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: aiAnalysis }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } }
        }
      });
      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const ctx = audioContextRef.current;
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => setIsSpeaking(false);
        source.start();
      } else {
        setIsSpeaking(false);
      }
    } catch (error) {
      setIsSpeaking(false);
    }
  };

  if (isLoadingData) return <div className="h-[60vh] flex flex-col items-center justify-center"><Loader2 className="w-12 h-12 text-emerald-600 animate-spin opacity-20" /><p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-4">Calculando Métricas ESG...</p></div>;

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-emerald-600 text-white text-[10px] font-black rounded-full uppercase tracking-widest shadow-lg shadow-emerald-500/20">Sustentabilidade</span>
            <Leaf size={18} className="text-emerald-500 animate-pulse" />
          </div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Painel <span className="text-emerald-500">ESG</span></h2>
          <p className="text-emerald-500 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Ambiental • Social • Governança</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="rounded-2xl gap-2 border-emerald-500/30 text-emerald-600 hover:bg-emerald-50"><Share2 size={18}/> Publicar Relatório</Button>
          <Button onClick={handleGenerateAiReport} loading={isGenerating} className="rounded-2xl gap-2 bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/40 font-black uppercase"><Sparkles size={18}/> Análise Gemini AI</Button>
        </div>
      </header>

      <nav className="flex p-1 glass rounded-[40px] w-fit overflow-x-auto no-scrollbar shadow-xl border-white/20">
        {[
          { id: 'ESG_DASH', label: 'Visão Geral', icon: <BarChart3 size={18}/> },
          { id: 'SOCIAL', label: 'Social (S)', icon: <Users size={18}/> },
          { id: 'ENVIRONMENTAL', label: 'Ambiental (E)', icon: <Leaf size={18}/> },
          { id: 'GOVERNANCE', label: 'Governança (G)', icon: <Scale size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-xs font-black transition-all shrink-0 ${activeTab === tab.id ? 'bg-emerald-600 text-white shadow-xl shadow-emerald-500/20' : 'text-slate-500 hover:text-emerald-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <div className="animate-in slide-in-from-bottom-5 duration-700">
        {activeTab === 'ESG_DASH' && (
          <div className="space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {impactStats.map((stat, i) => (
                <Card key={i} className="glass hover:scale-105 transition-all hover:border-emerald-500/30">
                  <div className="flex justify-between items-start mb-6">
                    <div className={`p-3 ${stat.bg} rounded-2xl ${stat.color}`}>{stat.icon}</div>
                    <Badge color="emerald">+{stat.trend}%</Badge>
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.category}</p>
                  <h3 className="text-4xl font-black dark:text-white mt-1">{stat.value.toLocaleString()} <span className="text-sm font-bold opacity-40">{stat.unit}</span></h3>
                </Card>
              ))}
            </div>

            <Card className="glass h-[400px] border-emerald-500/10" title="Índice de Impacto na Comunidade" subtitle="Evolução Mensal">
               <ResponsiveContainer width="100%" height="90%">
                  <AreaChart data={[{name: 'Jan', val: 40}, {name: 'Fev', val: 55}, {name: 'Mar', val: 65}, {name: 'Abr', val: 90}]}>
                     <defs>
                        <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                           <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/><stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                     </defs>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                     <XAxis dataKey="name" />
                     <YAxis />
                     <Tooltip />
                     <Area type="monotone" dataKey="val" stroke="#10b981" fillOpacity={1} fill="url(#colorVal)" />
                  </AreaChart>
               </ResponsiveContainer>
            </Card>
          </div>
        )}

        {activeTab === 'ESG_DASH' && aiAnalysis && (
          <div className="p-10 rounded-[48px] glass bg-emerald-600 text-white animate-in zoom-in-95 duration-1000 shadow-2xl shadow-emerald-500/30">
             <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-4">
                   <div className="w-16 h-16 bg-white/20 rounded-3xl flex items-center justify-center"><Bot size={32}/></div>
                   <h3 className="text-3xl font-black">Relatório de Sustentabilidade</h3>
                </div>
                <div className="flex gap-2">
                   <Button variant="ghost" onClick={handleSpeakReport} className="text-white hover:bg-white/10">
                      <Volume2 size={24} className={isSpeaking ? 'animate-pulse' : ''} />
                   </Button>
                   <Button variant="ghost" className="text-white hover:bg-white/10"><Download size={24}/></Button>
                </div>
             </div>
             <p className="text-lg leading-relaxed font-medium whitespace-pre-wrap opacity-90">{aiAnalysis}</p>
             <div className="mt-12 pt-8 border-t border-white/10 flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                <span>Gerado por Gemini 3.0 Flash</span>
                <Badge color="emerald">Impacto Verificado</Badge>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};


import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Modal, Badge, useToast, useTheme, FileUpload } from '../components/UI';
import { 
  Plus, Search, Boxes, ShoppingCart, Truck, 
  TrendingUp, History, FileCheck, PackageMinus, 
  ChevronRight, Camera, AlertCircle, PieChart as PieIcon,
  Layers, Edit2, Trash2, Tag, FileText, Users, Mail, Phone, Filter,
  Building2, UserPlus, ShieldCheck, Globe, Info, User, Clock, Hash,
  MapPin, ListTodo, PlusCircle, Loader2, ArrowRightLeft, BarChart3, Download,
  Calculator, ClipboardList, Handshake
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area, Legend
} from 'recharts';
// Removed mockDB import
import { FirestoreService } from '../services/FirestoreService';
import { AuditService } from '../services/AuditService';
import { 
  Material, Movement, PurchaseOrder, Project, Category, Client, TechnicalSpec 
} from '../types';
import { useAuth } from '../context/AuthContext';
import { CotacoesTab, PedidosTab, RequisicoesTab, ClientsTab, RelatoriosSuprimentos, MovimentacaoEstoque, PlanejamentoMRP, GestaoInventario, ContratosTab } from '../components/SuppliesExtensions';

export const Supplies: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'DASH'|'MM01'|'MIGO'|'MRP'|'INVENTORY'|'REQUISITIONS'|'QUOTES'|'ORDERS'|'CONTRACTS'|'CLIENTS'|'REPORTS'>('DASH');
  const [materials, setMaterials] = useState<Material[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');

  const [isMM01Open, setIsMM01Open] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Material | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const refreshData = async () => {
    setIsLoading(true);
    try {
      // Fetching from Firestore instead of mockDB
      const [m, c, po] = await Promise.all([
        FirestoreService.getAll<Material>('materials'),
        FirestoreService.getAll<Category>('categories'),
        FirestoreService.getAll<PurchaseOrder>('purchase_orders')
      ]);
      setMaterials(m);
      setCategories(c);
      setPurchaseOrders(po);
    } catch (e) {
      toast.error("Erro ao sincronizar estoque.");
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const kpis = useMemo(() => {
    const totalValue = materials.reduce((acc, m) => acc + (m.quantity * m.unitValue), 0);
    const lowStock = materials.filter(m => m.quantity <= m.minQuantity).length;
    const openOrders = purchaseOrders.filter(po => po.status === 'ORDERED').length;
    const itemsCount = materials.length;
    return { totalValue, lowStock, openOrders, itemsCount };
  }, [materials, purchaseOrders]);

  const handleSaveMaterial = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const f = new FormData(e.currentTarget);
    
    // Ensure ID stability
    const materialId = selectedItem?.id || `MAT-${Date.now()}`;

    const newMaterial: Material = {
      id: materialId,
      sku: f.get('sku') as string,
      name: f.get('name') as string,
      category: f.get('category') as string,
      type: 'CONSUMO',
      abcClass: (f.get('abcClass') as any) || 'C',
      xyzClass: f.get('xyzClass') as any || 'Z',
      status: 'ATIVO',
      quantity: Number(f.get('quantity')),
      unitValue: Number(f.get('unitValue')),
      totalValue: Number(f.get('quantity')) * Number(f.get('unitValue')),
      minQuantity: Number(f.get('minQuantity')),
      location: f.get('location') as string,
      uomBase: f.get('uom') as string,
      createdAt: selectedItem?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      // Preserve existing batches if not edited here (batches managed in MIGO)
      batches: selectedItem?.batches || []
    };

    try {
        await FirestoreService.save('materials', materialId, newMaterial);
        
        // Log de Auditoria via Service
        await AuditService.log({
          userId: currentUser?.id || 'sys',
          userName: currentUser?.name || 'Sistema',
          action: selectedItem ? 'UPDATE_MATERIAL' : 'CREATE_MATERIAL',
          module: 'SUPPLIES',
          details: `Material ${newMaterial.sku} - ${newMaterial.name} ${selectedItem ? 'atualizado' : 'criado'}.`,
          criticality: 'INFO'
        });

        await refreshData();
        setIsMM01Open(false);
        toast.success('Mestre de materiais atualizado na nuvem.');
    } catch (e) {
        toast.error('Erro ao salvar material.');
    } finally {
        setIsSaving(false);
    }
  };

  if (isLoading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <Loader2 className="w-12 h-12 text-orange-500 animate-spin opacity-20" />
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Auditando Almoxarifado...</p>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">
            Cadeia de <span className="text-orange-500">Suprimentos</span>
          </h2>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.4em] mt-2">Logística Institucional Enterprise</p>
        </div>
        <div className="flex gap-4">
           <Button onClick={() => { setSelectedItem(null); setIsMM01Open(true); }} className="bg-orange-500 hover:bg-orange-600 gap-2 h-14 rounded-2xl px-8 font-black uppercase text-xs shadow-lg shadow-orange-500/20"><Plus size={18}/> Cadastro MM01</Button>
        </div>
      </header>

      <nav className="flex p-1.5 glass rounded-[40px] w-full overflow-x-auto no-scrollbar shadow-2xl border-white/10 bg-white/20 dark:bg-black/20">
        {[
          { id: 'DASH', label: 'Cockpit', icon: <PieIcon size={18}/> },
          { id: 'MM01', label: 'Catálogo', icon: <Boxes size={18}/> },
          { id: 'MRP', label: 'MRP', icon: <Calculator size={18}/> },
          { id: 'MIGO', label: 'Movimentos', icon: <ArrowRightLeft size={18}/> },
          { id: 'INVENTORY', label: 'Inventário', icon: <ClipboardList size={18}/> },
          { id: 'REQUISITIONS', label: 'Requisições', icon: <ListTodo size={18}/> },
          { id: 'QUOTES', label: 'Cotações', icon: <FileText size={18}/> },
          { id: 'ORDERS', label: 'Pedidos', icon: <ShoppingCart size={18}/> },
          { id: 'CONTRACTS', label: 'Contratos', icon: <Handshake size={18}/> },
          { id: 'CLIENTS', label: 'Parceiros', icon: <Users size={18}/> },
          { id: 'REPORTS', label: 'Relatórios', icon: <BarChart3 size={18}/> }
        ].map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex items-center gap-3 px-6 py-4 rounded-[32px] text-[10px] uppercase font-black transition-all duration-500 shrink-0 ${activeTab === tab.id ? 'bg-orange-500 text-white shadow-xl shadow-orange-500/20' : 'text-slate-500 dark:text-slate-400 hover:text-orange-500'}`}>
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      <main>
        {activeTab === 'DASH' && (
           <div className="space-y-8 animate-in slide-in-from-bottom-5">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 <Card className="glass border-l-4 border-l-orange-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Valor em Estoque</p>
                    <h3 className="text-3xl font-black text-slate-800 dark:text-white mt-1">R$ {kpis.totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-rose-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Risco Ruptura (SKUs)</p>
                    <h3 className="text-3xl font-black text-rose-500 mt-1">{kpis.lowStock} <span className="text-xs text-slate-400 font-bold">Itens</span></h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-indigo-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pedidos Abertos</p>
                    <h3 className="text-3xl font-black text-indigo-500 mt-1">{kpis.openOrders} <span className="text-xs text-slate-400 font-bold">POs</span></h3>
                 </Card>
                 <Card className="glass border-l-4 border-l-emerald-500">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Catálogo Ativo</p>
                    <h3 className="text-3xl font-black text-emerald-500 mt-1">{kpis.itemsCount} <span className="text-xs text-slate-400 font-bold">SKUs</span></h3>
                 </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                 <Card className="lg:col-span-2 glass" title="Curva de Consumo" subtitle="Movimentação Financeira (Saídas)">
                    <div className="h-[300px] mt-6">
                       <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={[
                             {name: 'Jan', val: 4500}, {name: 'Fev', val: 3200}, {name: 'Mar', val: 6800}, 
                             {name: 'Abr', val: 5100}, {name: 'Mai', val: 4900}, {name: 'Jun', val: 7200}
                          ]}>
                             <defs>
                                <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                                   <stop offset="5%" stopColor="#f97316" stopOpacity={0.3}/>
                                   <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                                </linearGradient>
                             </defs>
                             <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                             <XAxis dataKey="name" tick={{fontSize: 10}} axisLine={false} tickLine={false} />
                             <YAxis tickFormatter={(v) => `R$${v/1000}k`} tick={{fontSize: 10}} axisLine={false} tickLine={false} />
                             <Tooltip />
                             <Area type="monotone" dataKey="val" stroke="#f97316" strokeWidth={3} fill="url(#colorVal)" />
                          </AreaChart>
                       </ResponsiveContainer>
                    </div>
                 </Card>
                 <Card className="glass" title="Classificação ABC">
                    <div className="space-y-4 mt-6">
                       <div className="flex justify-between items-center p-3 bg-emerald-50 dark:bg-emerald-900/10 rounded-xl">
                          <span className="text-xs font-black uppercase text-emerald-600">Classe A (Críticos)</span>
                          <span className="font-bold text-slate-700 dark:text-white">{materials.filter(m => m.abcClass === 'A').length} SKUs</span>
                       </div>
                       <div className="flex justify-between items-center p-3 bg-indigo-50 dark:bg-indigo-900/10 rounded-xl">
                          <span className="text-xs font-black uppercase text-indigo-600">Classe B (Intermediários)</span>
                          <span className="font-bold text-slate-700 dark:text-white">{materials.filter(m => m.abcClass === 'B').length} SKUs</span>
                       </div>
                       <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                          <span className="text-xs font-black uppercase text-slate-500">Classe C (Baixo Giro)</span>
                          <span className="font-bold text-slate-700 dark:text-white">{materials.filter(m => m.abcClass === 'C').length} SKUs</span>
                       </div>
                    </div>
                 </Card>
              </div>
           </div>
        )}

        {activeTab === 'MM01' && (
          <div className="space-y-8 animate-in slide-in-from-right-5">
            <div className="relative w-full max-w-lg">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
               <input className="w-full pl-12 pr-4 py-3 rounded-2xl glass border-none text-sm font-bold shadow-inner" placeholder="Buscar Material por SKU ou Nome..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {materials.filter(m => m.name.toLowerCase().includes(search.toLowerCase()) || m.sku.toLowerCase().includes(search.toLowerCase())).map(m => (
                <Card key={m.id} className="group hover:border-orange-500 transition-all cursor-pointer flex flex-col justify-between" onClick={() => { setSelectedItem(m); setIsMM01Open(true); }}>
                  <div>
                     <div className="flex justify-between mb-4">
                       <Badge color="slate">{m.sku}</Badge>
                       <Badge color={m.quantity <= m.minQuantity ? 'rose' : 'emerald'}>{m.quantity} {m.uomBase || 'UN'}</Badge>
                     </div>
                     <h4 className="font-black text-sm dark:text-white leading-tight mb-2 line-clamp-2">{m.name}</h4>
                     <p className="text-[10px] text-slate-400 uppercase font-bold">{m.category} • {m.location}</p>
                  </div>
                  <div className="pt-4 mt-4 border-t border-slate-50 dark:border-slate-800 flex justify-between items-center">
                     <div className="flex gap-2">
                        <span className="text-[10px] font-black bg-orange-100 dark:bg-orange-900/20 text-orange-600 px-2 py-1 rounded-lg">ABC: {m.abcClass}</span>
                        <span className="text-[10px] font-black bg-indigo-100 dark:bg-indigo-900/20 text-indigo-600 px-2 py-1 rounded-lg">XYZ: {m.xyzClass}</span>
                     </div>
                     <span className="text-xs font-black dark:text-white">R$ {m.unitValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
        
        {activeTab === 'MIGO' && <MovimentacaoEstoque materials={materials} onUpdate={refreshData} />}
        {activeTab === 'MRP' && <PlanejamentoMRP />}
        {activeTab === 'INVENTORY' && <GestaoInventario />}
        {activeTab === 'REQUISITIONS' && <RequisicoesTab />}
        {activeTab === 'QUOTES' && <CotacoesTab />}
        {activeTab === 'ORDERS' && <PedidosTab onUpdate={refreshData} />}
        {activeTab === 'CONTRACTS' && <ContratosTab />}
        {activeTab === 'CLIENTS' && <ClientsTab />}
        {activeTab === 'REPORTS' && <RelatoriosSuprimentos />}
      </main>

      <Modal isOpen={isMM01Open} onClose={() => setIsMM01Open(false)} title={selectedItem ? `Editar Material: ${selectedItem.sku}` : "Cadastro de Material (MM01)"} size="lg">
         <form onSubmit={handleSaveMaterial} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
               <Input label="SKU (Código)" name="sku" required defaultValue={selectedItem?.sku} placeholder="EX: MAT-001" />
               <Input label="Unidade de Medida (UOM)" name="uom" required defaultValue={selectedItem?.uomBase || 'UN'} placeholder="UN, KG, CX" />
            </div>
            <Input label="Denominação Completa" name="name" required defaultValue={selectedItem?.name} />
            
            <div className="grid grid-cols-3 gap-6">
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Categoria</label>
                  <select name="category" defaultValue={selectedItem?.category} className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                     {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                     <option>Outros</option>
                  </select>
               </div>
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Curva ABC</label>
                  <select name="abcClass" defaultValue={selectedItem?.abcClass || 'C'} className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                     <option value="A">Classe A (Crítico/Alto Valor)</option>
                     <option value="B">Classe B (Intermediário)</option>
                     <option value="C">Classe C (Baixo Valor/Giro)</option>
                  </select>
               </div>
               <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Curva XYZ</label>
                  <select name="xyzClass" defaultValue={selectedItem?.xyzClass || 'Z'} className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                     <option value="X">Classe X (Consumo Estável)</option>
                     <option value="Y">Classe Y (Consumo Variável)</option>
                     <option value="Z">Classe Z (Consumo Esporádico)</option>
                  </select>
               </div>
            </div>

            <div className="grid grid-cols-3 gap-6">
               <Input label="Estoque Atual" name="quantity" type="number" required defaultValue={selectedItem?.quantity || 0} />
               <Input label="Estoque Mínimo" name="minQuantity" type="number" required defaultValue={selectedItem?.minQuantity || 5} />
               <Input label="Valor Unitário (R$)" name="unitValue" type="number" step="0.01" required defaultValue={selectedItem?.unitValue || 0} />
            </div>

            <Input label="Localização Padrão no Almoxarifado" name="location" defaultValue={selectedItem?.location} placeholder="Ex: Corredor B, Prateleira 4" />

            <div className="flex justify-end gap-4 pt-4 border-t border-slate-100 dark:border-slate-800">
               <Button type="button" variant="outline" onClick={() => setIsMM01Open(false)}>Cancelar</Button>
               <Button type="submit" loading={isSaving} className="bg-orange-500 shadow-xl shadow-orange-500/20 px-8">Salvar Dados Mestres</Button>
            </div>
         </form>
      </Modal>
    </div>
  );
};

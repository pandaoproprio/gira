import React, { useState, useMemo, useEffect } from 'react';
import { Card, Button, Input, Badge, Modal, useToast, ConfirmDialog } from '../components/UI';
import { 
  Box, MapPin, Plus, Search, 
  Trash2, History, TrendingDown,
  Tag, Calendar, AlertTriangle, Table as TableIcon, LayoutGrid,
  TrendingUp, Info, ChevronRight, Clock, Activity, Loader2,
  Wrench, Shield, QrCode, FileText, BarChart, Printer
} from 'lucide-react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, AreaChart, Area
} from 'recharts';
import { Asset, MaintenanceOrder, AssetInsurance, AccountingEntry } from '../types';
import { AssetService } from '../services/AssetService';
import { AssetLifecycleService } from '../services/AssetLifecycleService';
import { FirestoreService } from '../services/FirestoreService';
import { AuditService } from '../services/AuditService';
import { useAuth } from '../context/AuthContext';

export const Patrimony: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  const [assets, setAssets] = useState<Asset[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [activeView, setActiveView] = useState<'GRID' | 'ANALYTICS'>('GRID');
  const [focusedAssetId, setFocusedAssetId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // States para Baixa
  const [isDisposeDialogOpen, setIsDisposeDialogOpen] = useState(false);
  const [assetToDispose, setAssetToDispose] = useState<Asset | null>(null);

  // States para Lifecycle Tabs (Modal)
  const [modalTab, setModalTab] = useState<'DETAILS' | 'MAINTENANCE' | 'FINANCE' | 'QR'>('DETAILS');
  const [assetMaintenance, setAssetMaintenance] = useState<MaintenanceOrder[]>([]);
  const [assetInsurances, setAssetInsurances] = useState<AssetInsurance[]>([]);
  const [isDepreciationRunning, setIsDepreciationRunning] = useState(false);

  const loadAssets = async () => {
    setIsLoading(true);
    try {
      const data = await FirestoreService.getAll<Asset>('assets');
      setAssets(data);
    } catch (e) {
      toast.error('Erro ao sincronizar patrimônio.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAssets();
  }, []);

  const loadLifecycleData = async (assetId: string) => {
    try {
      // Simulação de queries (Em produção usaria 'where' clause)
      const orders = await FirestoreService.getAll<MaintenanceOrder>('maintenance_orders');
      setAssetMaintenance(orders.filter(o => o.assetId === assetId));
      
      const insurances = await FirestoreService.getAll<AssetInsurance>('asset_insurances');
      setAssetInsurances(insurances.filter(i => i.assetId === assetId));
    } catch (e) {
      console.error(e);
    }
  };

  const handleOpenModal = (asset: Asset | null) => {
    setSelectedAsset(asset);
    setModalTab('DETAILS');
    if (asset) loadLifecycleData(asset.id);
    setIsFormOpen(true);
  };

  const filteredAssets = useMemo(() => {
    return assets.filter(a => 
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      a.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.location.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [assets, searchTerm]);

  // Garante que o item focado existe na lista filtrada ou pega o primeiro
  const focusedAsset = useMemo(() => {
    if (focusedAssetId) {
      const found = assets.find(a => a.id === focusedAssetId);
      if (found) return found;
    }
    return filteredAssets.length > 0 ? filteredAssets[0] : null;
  }, [assets, focusedAssetId, filteredAssets]);

  const curveData = useMemo(() => {
    if (!focusedAsset) return [];
    return AssetService.getDepreciationCurve(focusedAsset);
  }, [focusedAsset]);

  const handleSaveAsset = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    const f = new FormData(e.currentTarget);
    
    const assetData: Asset = {
      id: selectedAsset?.id || `AST-${Date.now()}`,
      name: f.get('name') as string,
      code: f.get('code') as string,
      category: f.get('category') as string,
      value: Number(f.get('value')),
      acquisitionDate: f.get('acquisitionDate') as string,
      lifespan: Number(f.get('lifespan')),
      location: f.get('location') as string,
      status: (f.get('status') as any) || 'Operacional',
      description: f.get('description') as string
    };

    try {
        await FirestoreService.save('assets', assetData.id, assetData);
        await AuditService.log({
          userId: currentUser?.id || 'sys',
          userName: currentUser?.name || 'Sistema',
          action: selectedAsset ? 'UPDATE_ASSET' : 'CREATE_ASSET',
          module: 'PATRIMONY',
          details: `${selectedAsset ? 'Atualizado' : 'Tombado'} ativo: ${assetData.name} (${assetData.code})`,
          criticality: 'INFO'
        });

        await loadAssets();
        setIsFormOpen(false);
        setSelectedAsset(null);
        toast.success(selectedAsset ? 'Ativo atualizado no mestre.' : 'Ativo tombado com sucesso.');
    } catch (e) {
        toast.error('Erro ao salvar ativo.');
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleCreateMaintenance = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedAsset) return;
    const f = new FormData(e.currentTarget);
    
    try {
      await AssetLifecycleService.createWorkOrder(
        selectedAsset,
        f.get('description') as string,
        f.get('type') as any,
        f.get('scheduledDate') as string,
        currentUser?.name || 'Sistema'
      );
      toast.success('Ordem de Serviço (O.S.) aberta.');
      loadLifecycleData(selectedAsset.id);
    } catch (e) {
      toast.error('Erro ao criar O.S.');
    }
  };

  const handleRunDepreciation = async () => {
    setIsDepreciationRunning(true);
    try {
      const count = await AssetLifecycleService.runDepreciationJob(assets);
      toast.success(`Fechamento contábil concluído. ${count} lançamentos gerados.`);
    } catch (e) {
      toast.error('Erro no processamento contábil.');
    } finally {
      setIsDepreciationRunning(false);
    }
  };

  const confirmDispose = (asset: Asset) => {
    setAssetToDispose(asset);
    setIsDisposeDialogOpen(true);
  };

  const handleDispose = async () => {
    if (!assetToDispose) return;
    
    const updated = { ...assetToDispose, status: 'Baixado' as const };
    try {
        await FirestoreService.save('assets', updated.id, updated);
        await AuditService.log({
          userId: currentUser?.id || 'sys',
          userName: currentUser?.name || 'Sistema',
          action: 'DISPOSE_ASSET',
          module: 'PATRIMONY',
          details: `Baixa patrimonial executada: ${assetToDispose.name} (${assetToDispose.code})`,
          criticality: 'WARN'
        });
        
        await loadAssets();
        toast.info('Baixa patrimonial executada. Valor residual zerado.');
        setIsDisposeDialogOpen(false);
        setAssetToDispose(null);
    } catch (e) {
        toast.error('Erro ao baixar ativo.');
    }
  };

  const totalPatrimonyValue = useMemo(() => {
    return assets.reduce((acc, a) => acc + AssetService.calculateCurrentValue(a), 0);
  }, [assets]);

  return (
    <div className="space-y-10 animate-in fade-in duration-700 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-5xl font-black text-[#F59E0B] tracking-tighter">Patrimônio</h2>
          <p className="text-slate-400 font-medium text-sm mt-1">Gestão de Ativos, Manutenção e Contabilidade.</p>
        </div>
        <div className="flex items-center gap-6">
           <div className="bg-white dark:bg-slate-800 px-6 py-3 rounded-2xl border border-slate-100 dark:border-slate-700 shadow-sm text-right">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Valor Residual Total</p>
              <p className="text-xl font-black text-[#F59E0B]">R$ {totalPatrimonyValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
           </div>
           <Button onClick={handleRunDepreciation} loading={isDepreciationRunning} variant="outline" className="h-14 border-amber-500/20 text-amber-600 gap-2 font-black uppercase text-xs">
             <BarChart size={18} /> Fechamento Depreciação
           </Button>
           <Button onClick={() => handleOpenModal(null)} className="h-14 px-10 rounded-2xl bg-[#F59E0B] hover:bg-[#D97706] shadow-lg shadow-amber-500/20 gap-2 font-black uppercase text-sm">
             <Plus size={20} /> Tombar Novo Ativo
           </Button>
        </div>
      </header>

      <div className="flex justify-between items-center gap-4">
        <nav className="flex p-1 glass rounded-2xl w-fit bg-white/20">
          <button 
            onClick={() => setActiveView('GRID')} 
            className={`flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-black transition-all ${activeView === 'GRID' ? 'bg-[#F59E0B] text-white shadow-lg' : 'text-slate-500 hover:text-amber-600'}`}
          >
            <LayoutGrid size={16}/> Mosaico
          </button>
          <button 
            onClick={() => setActiveView('ANALYTICS')} 
            className={`flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-black transition-all ${activeView === 'ANALYTICS' ? 'bg-[#F59E0B] text-white shadow-lg' : 'text-slate-500 hover:text-amber-600'}`}
          >
            <TableIcon size={16}/> Análise de Depreciação
          </button>
        </nav>

        <div className="relative group flex-1 max-w-md">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-amber-500 transition-colors" size={18} />
          <input 
            type="text" 
            placeholder="Buscar por nome, código ou local..." 
            className="w-full pl-14 pr-6 py-3.5 rounded-2xl border-none bg-white dark:bg-slate-800 focus:ring-4 focus:ring-amber-500/10 transition-all font-bold text-sm dark:text-white shadow-sm"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="py-20 text-center">
           <Loader2 className="w-12 h-12 text-[#F59E0B] animate-spin mx-auto opacity-20"/>
           <p className="mt-4 text-xs font-black uppercase text-slate-400 tracking-[0.3em]">Auditando Ativos...</p>
        </div>
      ) : activeView === 'GRID' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-8">
          {filteredAssets.map(asset => {
            const currentValue = AssetService.calculateCurrentValue(asset);
            const health = AssetService.getAssetHealth(asset);
            
            return (
              <Card key={asset.id} glass={false} className="group hover:shadow-xl transition-all relative flex flex-col h-full bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700 rounded-[16px] p-0 shadow-sm">
                <div className="p-6 flex-1">
                  <div className="flex justify-between items-start mb-6">
                    <div className="w-12 h-12 bg-slate-50 dark:bg-slate-900 rounded-full flex items-center justify-center text-slate-400 shrink-0 border border-slate-100 dark:border-slate-700">
                      <Box size={24}/>
                    </div>
                    <Badge color={asset.status === 'Operacional' ? 'emerald' : asset.status === 'Manutenção' ? 'amber' : 'rose'}>
                      {asset.status.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="text-base font-black text-slate-800 dark:text-white leading-snug break-words" title={asset.name}>
                      {asset.name}
                    </h4>
                    <p className="text-[11px] font-bold text-[#F59E0B] uppercase tracking-widest mt-1 flex items-center gap-1">
                      <Tag size={10}/> {asset.code}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Aquisição</p>
                      <p className="text-xs font-black text-slate-700 dark:text-slate-300">R$ {asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Residual</p>
                      <p className="text-xs font-black text-[#F59E0B]">R$ {currentValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-slate-500 overflow-hidden">
                      <MapPin size={14} className="shrink-0 text-[#F59E0B]" />
                      <span className="text-[10px] font-bold uppercase truncate" title={asset.location}>{asset.location}</span>
                    </div>
                    <Badge color={health.color as any}>{health.label.toUpperCase()}</Badge>
                  </div>
                </div>

                <div className="px-6 py-4 bg-slate-50/50 dark:bg-slate-900/30 border-t border-slate-100 dark:border-slate-700 flex justify-between items-center rounded-b-[16px]">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Calendar size={12} />
                    <span className="text-[10px] font-black uppercase">{new Date(asset.acquisitionDate).toLocaleDateString('pt-BR')}</span>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => handleOpenModal(asset)} className="p-2 bg-white dark:bg-slate-800 hover:bg-amber-500 hover:text-white text-slate-400 rounded-xl transition-all shadow-sm border border-slate-100 dark:border-slate-700" title="Gestão do Ativo">
                      <History size={14}/>
                    </button>
                    {asset.status !== 'Baixado' && (
                      <button onClick={() => confirmDispose(asset)} className="p-2 bg-white dark:bg-slate-800 text-slate-400 hover:bg-rose-500 hover:text-white rounded-xl transition-all shadow-sm border border-slate-100 dark:border-slate-700" title="Executar Baixa">
                        <TrendingDown size={14}/>
                      </button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
          {filteredAssets.length === 0 && (
            <div className="col-span-full py-20 text-center">
              <Box size={48} className="mx-auto text-slate-200 mb-4"/>
              <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Nenhum ativo encontrado.</p>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-10 animate-in slide-in-from-bottom-5 duration-700">
           {/* Gráfico de Evolução */}
           <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <Card className="xl:col-span-2 glass" title="Evolução do Valor Residual" subtitle={`Ativo Selecionado: ${focusedAsset?.name || 'Nenhum'}`}>
                 <div className="h-[350px] mt-6">
                    <ResponsiveContainer width="100%" height="100%">
                       <AreaChart data={curveData}>
                          <defs>
                             <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#F59E0B" stopOpacity={0}/>
                             </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                          <XAxis dataKey="ano" tick={{fontSize: 11, fontWeight: 700, fill: '#94a3b8'}} axisLine={false} tickLine={false} />
                          <YAxis tick={{fontSize: 11, fontWeight: 700, fill: '#94a3b8'}} axisLine={false} tickLine={false} tickFormatter={(v) => `R$${(v/1000).toFixed(0)}k`} />
                          <Tooltip 
                            contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                            formatter={(v: number) => [`R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 'Valor Residual']}
                          />
                          <Area type="monotone" dataKey="valor" stroke="#F59E0B" strokeWidth={3} fillOpacity={1} fill="url(#colorVal)" />
                       </AreaChart>
                    </ResponsiveContainer>
                 </div>
              </Card>

              <div className="space-y-6">
                <Card className="glass" title="Métricas do Ativo">
                  {focusedAsset ? (
                    <div className="space-y-6 mt-4">
                       {(() => {
                         const details = AssetService.calculateDepreciationDetails(focusedAsset);
                         return (
                           <>
                             <div className="flex justify-between items-center p-4 rounded-2xl bg-amber-50 dark:bg-amber-900/10 border border-amber-100">
                                <div>
                                   <p className="text-[10px] font-black text-slate-400 uppercase">Taxa de Depreciação</p>
                                   <p className="text-2xl font-black text-amber-600">{details.annualRate}% <span className="text-xs opacity-50">/ano</span></p>
                                </div>
                                <TrendingDown className="text-amber-500" />
                             </div>
                             <div className="flex justify-between items-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100">
                                <div>
                                   <p className="text-[10px] font-black text-slate-400 uppercase">Vida Útil Restante</p>
                                   <p className="text-2xl font-black text-slate-800 dark:text-white">{details.remainingLife} <span className="text-xs opacity-50">anos</span></p>
                                </div>
                                <Clock size={24} className="text-slate-400" />
                             </div>
                             <div className="p-4 rounded-2xl border border-dashed border-slate-200">
                                <p className="text-[9px] font-black text-slate-400 uppercase mb-2">Depreciação Anual em Reais</p>
                                <p className="text-sm font-bold text-slate-600 dark:text-slate-300">R$ {details.annualDepreciationValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                             </div>
                           </>
                         );
                       })()}
                    </div>
                  ) : (
                    <div className="py-10 text-center opacity-30 uppercase font-black text-[10px] tracking-widest">Selecione um ativo na tabela</div>
                  )}
                </Card>
              </div>
           </div>

           {/* Tabela de Depreciação */}
           <Card className="p-0 glass border-none overflow-hidden" title="Quadro Demonstrativo de Depreciação (Linear)">
              <div className="overflow-x-auto">
                 <table className="w-full text-left">
                    <thead>
                       <tr className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest border-b border-slate-100 dark:border-slate-800 bg-white/20 dark:bg-black/20">
                          <th className="py-6 px-8">Item / Código</th>
                          <th className="py-6 px-8 text-right">Valor Original</th>
                          <th className="py-6 px-8 text-center">Taxa Anual</th>
                          <th className="py-6 px-8 text-center">Vida Restante</th>
                          <th className="py-6 px-8 text-right">Valor Residual</th>
                          <th className="py-6 px-8 text-right w-20"></th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                       {filteredAssets.map(asset => {
                          const details = AssetService.calculateDepreciationDetails(asset);
                          const isFocused = focusedAsset?.id === asset.id;
                          
                          return (
                             <tr 
                              key={asset.id} 
                              className={`hover:bg-amber-500/[0.03] transition-all cursor-pointer group ${isFocused ? 'bg-amber-500/[0.05]' : ''}`}
                              onClick={() => setFocusedAssetId(asset.id)}
                             >
                                <td className="py-6 px-8">
                                   <div className="flex items-center gap-4">
                                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${isFocused ? 'bg-amber-500 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                                         <Box size={20}/>
                                      </div>
                                      <div>
                                         <p className="font-black text-slate-800 dark:text-white leading-tight text-sm">{asset.name}</p>
                                         <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">{asset.code}</p>
                                      </div>
                                   </div>
                                </td>
                                <td className="py-6 px-8 text-right font-bold text-slate-600 dark:text-slate-400">
                                   R$ {details.originalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </td>
                                <td className="py-6 px-8 text-center">
                                   <Badge color="amber">{details.annualRate}%</Badge>
                                </td>
                                <td className="py-6 px-8 text-center">
                                   <div className="flex flex-col items-center">
                                      <span className="text-sm font-black text-slate-700 dark:text-slate-300">{details.remainingLife}</span>
                                      <span className="text-[9px] text-slate-400 uppercase font-bold tracking-tighter">ANOS</span>
                                   </div>
                                </td>
                                <td className="py-6 px-8 text-right font-black text-amber-600">
                                   R$ {details.residualValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                </td>
                                <td className="py-6 px-8 text-right">
                                   <div className={`transition-all ${isFocused ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-2'}`}>
                                      <ChevronRight size={18} className="text-amber-500" />
                                   </div>
                                </td>
                             </tr>
                          );
                       })}
                    </tbody>
                 </table>
              </div>
           </Card>
        </div>
      )}

      {/* MODAL GESTÃO AVANÇADA DO ATIVO */}
      <Modal isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} title={selectedAsset ? "Gestão de Ciclo de Vida" : "Protocolo de Tombamento"} size="xl">
         {selectedAsset ? (
           <div className="space-y-6">
             {/* Navegação Interna Modal */}
             <div className="flex gap-2 p-1 bg-slate-50 dark:bg-slate-900 rounded-xl">
               {[
                 { id: 'DETAILS', label: 'Cadastro', icon: <Box size={14}/> },
                 { id: 'MAINTENANCE', label: 'Manutenção (O.S.)', icon: <Wrench size={14}/> },
                 { id: 'FINANCE', label: 'Financeiro & Seguros', icon: <Shield size={14}/> },
                 { id: 'QR', label: 'Etiqueta Digital', icon: <QrCode size={14}/> },
               ].map(tab => (
                 <button
                   key={tab.id}
                   onClick={() => setModalTab(tab.id as any)}
                   className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${modalTab === tab.id ? 'bg-white shadow text-amber-600' : 'text-slate-400 hover:text-slate-600'}`}
                 >
                   {tab.icon} {tab.label}
                 </button>
               ))}
             </div>

             {/* Tab Content: DETAILS */}
             {modalTab === 'DETAILS' && (
               <form onSubmit={handleSaveAsset} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <Input label="Denominação do Ativo" name="name" defaultValue={selectedAsset?.name} required placeholder="Ex: Mac Studio M2" />
                     <Input label="Etiqueta de Tombamento" name="code" defaultValue={selectedAsset?.code} required placeholder="Ex: CEAP-TI-104" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <div className="space-y-1">
                        <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Categoria</label>
                        <select name="category" defaultValue={selectedAsset?.category} className="w-full p-4 rounded-2xl border-2 border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                           <option>Hardware</option>
                           <option>Mobiliário</option>
                           <option>Veículos</option>
                           <option>Imóveis</option>
                           <option>Outros</option>
                        </select>
                     </div>
                     <Input label="V. Aquisição (R$)" name="value" type="number" step="0.01" defaultValue={selectedAsset?.value} required />
                     <Input label="Vida Útil (Anos)" name="lifespan" type="number" defaultValue={selectedAsset?.lifespan || 5} required />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <Input label="Data de Aquisição" name="acquisitionDate" type="date" defaultValue={selectedAsset?.acquisitionDate} required />
                     <Input label="Localização / Setor" name="location" defaultValue={selectedAsset?.location} required placeholder="Ex: CPD Central" />
                  </div>

                  <div className="space-y-1">
                     <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Status Operacional</label>
                     <select name="status" defaultValue={selectedAsset?.status} className="w-full p-4 rounded-2xl border-2 border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                        <option value="Operacional">Operacional (Em uso)</option>
                        <option value="Manutenção">Em Manutenção</option>
                        <option value="Baixado">Baixado / Descartado</option>
                     </select>
                  </div>

                  <div className="flex justify-end gap-4 pt-6">
                     <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="px-10 h-14 rounded-2xl border-slate-200 text-slate-600">Cancelar</Button>
                     <Button type="submit" loading={isSubmitting} className="px-12 h-14 rounded-2xl bg-[#F59E0B] hover:bg-[#D97706] shadow-xl shadow-amber-500/20 font-black uppercase text-sm">Atualizar Dados</Button>
                  </div>
               </form>
             )}

             {/* Tab Content: MAINTENANCE */}
             {modalTab === 'MAINTENANCE' && (
               <div className="space-y-6">
                 <div className="p-6 bg-slate-50 dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800">
                   <h4 className="text-sm font-black text-slate-700 dark:text-white mb-4 uppercase tracking-widest">Histórico de O.S.</h4>
                   <div className="space-y-3 max-h-[200px] overflow-y-auto pr-2">
                     {assetMaintenance.map(os => (
                       <div key={os.id} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 flex justify-between items-center">
                         <div>
                           <p className="text-xs font-bold text-slate-800 dark:text-white">{os.description}</p>
                           <p className="text-[9px] text-slate-400 font-bold uppercase">{new Date(os.createdAt).toLocaleDateString()} • {os.type}</p>
                         </div>
                         <Badge color={os.status === 'CONCLUIDA' ? 'emerald' : 'amber'}>{os.status}</Badge>
                       </div>
                     ))}
                     {assetMaintenance.length === 0 && <p className="text-center text-xs text-slate-400 py-4">Nenhuma ordem de serviço registrada.</p>}
                   </div>
                 </div>

                 <form onSubmit={handleCreateMaintenance} className="space-y-4">
                   <h4 className="text-sm font-black text-amber-600 uppercase tracking-widest">Abrir Nova O.S.</h4>
                   <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-1">
                       <label className="text-[10px] font-black uppercase text-slate-400">Tipo</label>
                       <select name="type" className="w-full p-3 rounded-xl border-2 border-slate-100 text-xs font-bold">
                         <option value="CORRETIVA">Corretiva (Reparo)</option>
                         <option value="PREVENTIVA">Preventiva (Agendada)</option>
                       </select>
                     </div>
                     <Input label="Data Prevista" name="scheduledDate" type="date" required />
                   </div>
                   <Input label="Descrição do Serviço" name="description" required placeholder="Ex: Troca de cooler e limpeza" />
                   <Button type="submit" className="w-full bg-slate-800 text-white h-12 uppercase font-black text-xs">Registrar Solicitação</Button>
                 </form>
               </div>
             )}

             {/* Tab Content: FINANCE */}
             {modalTab === 'FINANCE' && (
               <div className="space-y-6">
                 <div className="grid grid-cols-2 gap-4">
                   <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100">
                     <p className="text-[10px] font-black text-slate-400 uppercase">Valor de Mercado</p>
                     <p className="text-xl font-black text-emerald-600">R$ {AssetService.calculateCurrentValue(selectedAsset).toLocaleString()}</p>
                   </div>
                   <div className="p-4 rounded-2xl bg-amber-50 border border-amber-100">
                     <p className="text-[10px] font-black text-slate-400 uppercase">Custo Histórico</p>
                     <p className="text-xl font-black text-amber-600">R$ {selectedAsset.value.toLocaleString()}</p>
                   </div>
                 </div>

                 <div className="border-t border-slate-100 pt-6">
                   <h4 className="text-sm font-black text-slate-700 mb-4 uppercase tracking-widest flex items-center gap-2"><Shield size={14}/> Apólices de Seguro</h4>
                   {assetInsurances.length > 0 ? (
                     assetInsurances.map(ins => (
                       <div key={ins.id} className="p-4 border rounded-2xl mb-2 flex justify-between items-center">
                         <div>
                           <p className="font-bold text-xs">{ins.insurerName}</p>
                           <p className="text-[10px] text-slate-400">Apólice: {ins.policyNumber}</p>
                         </div>
                         <Badge color="emerald">Vigente</Badge>
                       </div>
                     ))
                   ) : (
                     <p className="text-xs text-slate-400 italic">Nenhum seguro vinculado.</p>
                   )}
                   <Button variant="outline" className="w-full mt-4 text-xs font-bold border-dashed border-slate-300 text-slate-500">
                     + Vincular Apólice (Módulo Financeiro)
                   </Button>
                 </div>
               </div>
             )}

             {/* Tab Content: QR CODE */}
             {modalTab === 'QR' && (
               <div className="flex flex-col items-center justify-center py-10 space-y-6">
                 <div className="p-4 bg-white rounded-2xl shadow-xl border border-slate-100">
                   <img src={AssetLifecycleService.generateQRCodeUrl(selectedAsset)} alt="QR Code" className="w-48 h-48" />
                 </div>
                 <div className="text-center">
                   <p className="text-lg font-black text-slate-800">{selectedAsset.code}</p>
                   <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">{selectedAsset.name}</p>
                 </div>
                 <Button className="bg-amber-500 hover:bg-amber-600 gap-2 px-8"><Printer size={18}/> Imprimir Etiqueta</Button>
               </div>
             )}

           </div>
         ) : (
           <form onSubmit={handleSaveAsset} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <Input label="Denominação do Ativo" name="name" required placeholder="Ex: Mac Studio M2" />
                 <Input label="Etiqueta de Tombamento" name="code" required placeholder="Ex: CEAP-TI-104" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Categoria</label>
                    <select name="category" className="w-full p-4 rounded-2xl border-2 border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                       <option>Hardware</option>
                       <option>Mobiliário</option>
                       <option>Veículos</option>
                       <option>Imóveis</option>
                       <option>Outros</option>
                    </select>
                 </div>
                 <Input label="V. Aquisição (R$)" name="value" type="number" step="0.01" required />
                 <Input label="Vida Útil (Anos)" name="lifespan" type="number" defaultValue={5} required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <Input label="Data de Aquisição" name="acquisitionDate" type="date" required />
                 <Input label="Localização / Setor" name="location" required placeholder="Ex: CPD Central" />
              </div>

              <div className="space-y-1">
                 <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Status Operacional</label>
                 <select name="status" className="w-full p-4 rounded-2xl border-2 border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                    <option value="Operacional">Operacional (Em uso)</option>
                    <option value="Manutenção">Em Manutenção</option>
                    <option value="Baixado">Baixado / Descartado</option>
                 </select>
              </div>

              <div className="p-8 rounded-[24px] bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-500/20 flex items-center gap-6">
                 <AlertTriangle size={32} className="text-[#F59E0B] shrink-0" />
                 <p className="text-xs font-bold text-slate-500 dark:text-amber-300/70 leading-relaxed uppercase">
                   O tombamento gera uma entrada contábil no balanço institucional. Verifique se os dados de custo e vida útil seguem a norma CPC 27 para depreciação linear.
                 </p>
              </div>

              <div className="flex justify-end gap-4 pt-6">
                 <Button type="button" variant="outline" onClick={() => setIsFormOpen(false)} className="px-10 h-14 rounded-2xl border-slate-200 text-slate-600">Cancelar</Button>
                 <Button type="submit" loading={isSubmitting} className="px-12 h-14 rounded-2xl bg-[#F59E0B] hover:bg-[#D97706] shadow-xl shadow-amber-500/20 font-black uppercase text-sm">Protocolar Ativo</Button>
              </div>
           </form>
         )}
      </Modal>

      <ConfirmDialog 
        isOpen={isDisposeDialogOpen}
        onClose={() => setIsDisposeDialogOpen(false)}
        onConfirm={handleDispose}
        title="Confirmar Baixa Patrimonial"
        message={`Tem certeza que deseja baixar o ativo "${assetToDispose?.name}"? Esta ação zera o valor residual e remove o item do inventário ativo.`}
      />
    </div>
  );
};
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

interface ErrorBoundaryProps {
  children?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

// --- RESILIÊNCIA: Error Boundary para capturar falhas de renderização ---
class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = {
    hasError: false, 
    error: null
  };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("GIRA CEAP Critical Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{padding: '40px', fontFamily: 'sans-serif', color: '#333'}}>
          <h1 style={{color: '#e11d48'}}>Sistema GIRA CEAP - Interrompido</h1>
          <p>Ocorreu uma falha crítica na inicialização do módulo de gestão.</p>
          <div style={{background: '#f1f5f9', padding: '20px', borderRadius: '8px', overflow: 'auto'}}>
            <strong>Log de Erro:</strong>
            <pre style={{marginTop: '10px', color: '#dc2626'}}>{this.state.error?.toString()}</pre>
          </div>
          <p style={{marginTop: '20px'}}>Verifique o console do desenvolvedor para stack trace completo.</p>
          <button onClick={() => window.location.reload()} style={{padding: '10px 20px', background: '#4f46e5', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', marginTop: '10px'}}>
            Tentar Recuperação Automática
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  console.error("FALHA DE INICIALIZAÇÃO: Elemento 'root' não encontrado no DOM.");
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);

try {
  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );
  console.log("GIRA CEAP: Sistema iniciado com sucesso. Módulos: Economia Criativa, ESG, Recursos.");
} catch (e) {
  console.error("GIRA CEAP: Falha no Build/Render:", e);
}
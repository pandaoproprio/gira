
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role, PermissionCode, UserStatus } from '../types';
import { INITIAL_ROLES } from '../constants';
import { AuditService } from '../services/AuditService';
import { FirestoreService } from '../services/FirestoreService';
import { auth } from '../services/firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';

interface AuthContextType {
  currentUser: User | null;
  currentRole: Role | null;
  firebaseUser: FirebaseUser | null;
  allPermissions: PermissionCode[];
  hasPermission: (code: PermissionCode) => boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, userData: Partial<User>) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  isLoading: boolean;
  authError: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentRole, setCurrentRole] = useState<Role | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  // Validação de Domínio Corporativo & SuperAdmin
  const isDomainAllowed = (email: string) => {
    if (email === 'juanpablorj@gmail.com') return true;
    return email.endsWith('@ceapoficial.org.br');
  };

  // Helper: Cria usuário de fallback garantido
  const createFallbackUser = (fbUser: FirebaseUser): User => {
    const isAdmin = fbUser.email === 'juanpablorj@gmail.com';
    return {
        id: fbUser.uid,
        name: fbUser.displayName || fbUser.email?.split('@')[0] || 'Usuário',
        email: fbUser.email || '',
        roleId: isAdmin ? 'superadmin' : 'tecnico',
        status: UserStatus.ACTIVE,
        mfaEnabled: false,
        extraPermissions: [],
        photoURL: fbUser.photoURL || `https://ui-avatars.com/api/?name=${fbUser.email}&background=random`,
        admissionDate: new Date().toISOString(),
        department: 'Geral',
        position: isAdmin ? 'Diretor Geral' : 'Colaborador'
    };
  };

  useEffect(() => {
    // Verificação defensiva: Se 'auth' não foi inicializado corretamente (erro de rede/config),
    // aborta para não quebrar a UI inteira.
    if (!auth) {
        console.error("Firebase Auth service not initialized correctly.");
        setAuthError("Erro crítico de inicialização do serviço de autenticação.");
        setIsLoading(false);
        return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        let userProfile: User | null = null;
        
        try {
          // Tenta buscar perfil oficial no Firestore
          userProfile = await FirestoreService.getById<User>('users', fbUser.uid);
        } catch (e) {
          console.warn("Banco de dados indisponível ou perfil inexistente. Ativando modo fallback.", e);
        }

        // Lógica Super Admin: Se for o email mestre, garante role 'superadmin'
        if (fbUser.email === 'juanpablorj@gmail.com') {
            if (!userProfile) {
                // Se não existir perfil no banco para o Super Admin, cria agora
                userProfile = createFallbackUser(fbUser);
                await FirestoreService.save('users', fbUser.uid, userProfile);
            } else if (userProfile.roleId !== 'superadmin') {
                // Se existir mas estiver errado, corrige
                userProfile.roleId = 'superadmin';
                await FirestoreService.save('users', fbUser.uid, { roleId: 'superadmin' });
            }
        }

        if (userProfile) {
          setCurrentUser(userProfile);
          const role = INITIAL_ROLES.find(r => r.id === userProfile?.roleId) || INITIAL_ROLES[0];
          setCurrentRole(role);
        } else {
          // CRÍTICO: Se falhar o banco, usa o fallback para não travar o login
          const fallbackUser = createFallbackUser(fbUser);
          setCurrentUser(fallbackUser);
          const role = INITIAL_ROLES.find(r => r.id === fallbackUser.roleId) || INITIAL_ROLES[2];
          setCurrentRole(role);
        }
      } else {
        setCurrentUser(null);
        setCurrentRole(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      setAuthError(null);

      if (!isDomainAllowed(email)) {
        const msg = "Acesso restrito. Utilize seu e-mail corporativo (@ceapoficial.org.br).";
        setAuthError(msg);
        return { success: false, error: msg };
      }

      await signInWithEmailAndPassword(auth, email, password);
      
      AuditService.log({
        userId: email, 
        userName: email,
        action: 'USER_LOGIN',
        module: 'AUTH',
        details: `Acesso realizado via Firebase`,
        criticality: 'INFO'
      }).catch(console.error);

      return { success: true };
    } catch (error: any) {
      console.error(error);
      let msg = "Erro ao fazer login.";
      if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
        msg = "E-mail ou senha incorretos.";
      } else if (error.code === 'auth/too-many-requests') {
        msg = "Muitas tentativas. Tente novamente mais tarde.";
      }
      
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  const signup = async (email: string, password: string, userData: Partial<User>): Promise<{ success: boolean; error?: string }> => {
    try {
      setAuthError(null);

      if (!isDomainAllowed(email)) {
        const msg = "Cadastro restrito ao domínio @ceapoficial.org.br";
        setAuthError(msg);
        return { success: false, error: msg };
      }
      
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const uid = userCredential.user.uid;

      let initialRole = userData.roleId || 'tecnico';
      if (email === 'juanpablorj@gmail.com') {
        initialRole = 'superadmin';
      }

      const newUserPayload: User = {
        id: uid, 
        name: userData.name || 'Novo Usuário',
        email,
        roleId: initialRole,
        status: UserStatus.ACTIVE,
        mfaEnabled: false,
        extraPermissions: [],
        photoURL: userData.photoURL || `https://ui-avatars.com/api/?name=${userData.name || 'User'}&background=4f46e5&color=fff`,
        admissionDate: new Date().toISOString(),
        department: userData.department || 'Geral',
        position: userData.position || 'Colaborador'
      };

      await FirestoreService.save('users', uid, newUserPayload);

      return { success: true };

    } catch (error: any) {
      // TRATAMENTO DE USUÁRIO JÁ EXISTENTE
      if (error.code === 'auth/email-already-in-use') {
        try {
          // Tenta realizar o login com as credenciais fornecidas
          await signInWithEmailAndPassword(auth, email, password);
          return { success: true };
        } catch (loginError: any) {
          // Se falhar o login (senha incorreta), retorna erro
          setAuthError("Este e-mail já existe, mas a senha informada está incorreta.");
          return { success: false, error: "Conta existente. Senha incorreta." };
        }
      }

      let msg = error.message;
      if (error.code === 'auth/weak-password') msg = "A senha deve ter pelo menos 6 caracteres.";
      
      setAuthError(msg);
      return { success: false, error: msg };
    }
  };

  const logout = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setCurrentRole(null);
    setFirebaseUser(null);
  };

  const resetPassword = async (email: string) => {
    alert('Funcionalidade de reset de senha via e-mail será ativada em breve via Firebase.');
  };

  const allPermissions = [
    ...(currentRole?.permissions || []),
    ...(currentUser?.extraPermissions || [])
  ];

  const hasPermission = (code: PermissionCode) => {
    if (currentRole?.id === 'superadmin' || (currentRole?.permissions && currentRole.permissions.includes('*'))) return true;
    return allPermissions.includes(code);
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      currentRole,
      firebaseUser,
      allPermissions,
      hasPermission,
      login,
      signup,
      logout,
      resetPassword,
      isLoading,
      authError
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

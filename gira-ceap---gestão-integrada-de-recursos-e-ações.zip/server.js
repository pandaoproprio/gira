// ESTE ARQUIVO NÃO É MAIS NECESSÁRIO.
// O sistema foi migrado para arquitetura Serverless com Firebase.
// Você pode deletar este arquivo.

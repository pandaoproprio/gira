
import React, { useState, useEffect, useMemo } from 'react';
import { Card, Button, Input, Badge, Modal, useToast } from '../components/UI';
import { 
  UserCircle, Users, TrendingUp, DollarSign, Plus, Search, 
  Trash2, Edit2, Loader2, AlertTriangle, Clock, Calendar, 
  FileText, Briefcase, Award, GraduationCap, Calculator,
  UploadCloud, CheckCircle2, XCircle
} from 'lucide-react';
import { FirestoreService } from '../services/FirestoreService';
import { HRService } from '../services/HRService';
import { AuditService } from '../services/AuditService';
import { useAuth } from '../context/AuthContext';
import { Project, TimeRecord, AbsenceRequest } from '../types';

interface Employee {
  id: string;
  name: string;
  role: string;
  department: string;
  status: 'ATIVO' | 'FÉRIAS' | 'AFASTADO';
  salary: number;
  admissionDate: string;
}

export const HR: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  
  // Navigation
  const [activeTab, setActiveTab] = useState<'STAFF' | 'TIME' | 'TALENT' | 'DOCS' | 'COSTS'>('STAFF');
  
  // Core Data (Read-Only)
  const [staff, setStaff] = useState<Employee[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  
  // Extension Data
  const [timeRecords, setTimeRecords] = useState<TimeRecord[]>([]);
  const [absences, setAbsences] = useState<AbsenceRequest[]>([]);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Selected Context
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [empData, projData, timeData, absData] = await Promise.all([
        FirestoreService.getAll<Employee>('employees'),
        FirestoreService.getAll<Project>('projects'),
        FirestoreService.getAll<TimeRecord>('hr_time_records'),
        FirestoreService.getAll<AbsenceRequest>('hr_absences')
      ]);
      setStaff(empData);
      setProjects(projData);
      setTimeRecords(timeData);
      setAbsences(absData);
    } catch (e) {
      toast.error('Erro ao sincronizar ecossistema de RH.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const selectedEmployee = useMemo(() => staff.find(e => e.id === selectedEmployeeId), [staff, selectedEmployeeId]);

  // Handlers
  const handleClockIn = async () => {
    if (!selectedEmployeeId) return toast.error('Selecione um colaborador.');
    try {
      await HRService.clockIn(selectedEmployeeId);
      toast.success('Ponto registrado com sucesso.');
      loadData();
    } catch (e) {
      toast.error('Erro ao registrar ponto.');
    }
  };

  const handleCostCalculation = async () => {
    if (!selectedEmployee || !projects.length) return;
    try {
      // Simulação: Pega o primeiro projeto para exemplo
      const targetProject = projects[0];
      const hours = Math.floor(Math.random() * 100); // Mock hours
      
      const allocation = await HRService.calculateProjectCost(
        selectedEmployee, 
        targetProject, 
        hours, 
        new Date().toISOString().slice(0, 7)
      );
      
      toast.success(`Custo calculado: R$ ${allocation.totalCost.toLocaleString()} para ${targetProject.name}`);
    } catch (e) {
      toast.error('Erro no algoritmo de custeio.');
    }
  };

  if (isLoading) return <div className="flex justify-center p-20"><Loader2 className="animate-spin text-pink-500" /></div>;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-700">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black tracking-tighter dark:text-white">Capital Humano</h2>
          <p className="text-pink-500 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Gestão de Talentos & Performance</p>
        </div>
        <div className="flex gap-4">
           {selectedEmployee && (
             <div className="flex items-center gap-2 px-4 py-2 bg-pink-50 rounded-xl border border-pink-100">
                <UserCircle size={18} className="text-pink-600"/>
                <span className="text-xs font-bold text-pink-700">{selectedEmployee.name}</span>
                <button onClick={() => setSelectedEmployeeId(null)} className="ml-2 text-pink-400 hover:text-pink-600"><XCircle size={14}/></button>
             </div>
           )}
           <Button onClick={() => setIsModalOpen(true)} className="px-8 bg-pink-500 hover:bg-pink-600 shadow-pink-500/20 rounded-2xl h-12 font-black uppercase"><Plus size={18} /> Admissão</Button>
        </div>
      </div>

      <nav className="flex p-1 glass rounded-[40px] w-fit overflow-x-auto no-scrollbar shadow-xl border-white/20">
        {[
          { id: 'STAFF', label: 'Quadro (Core)', icon: <Users size={18}/> },
          { id: 'TIME', label: 'Jornada & Ponto', icon: <Clock size={18}/> },
          { id: 'TALENT', label: 'Performance', icon: <Award size={18}/> },
          { id: 'DOCS', label: 'GED Pessoal', icon: <FileText size={18}/> },
          { id: 'COSTS', label: 'Custo Real', icon: <Calculator size={18}/> }
        ].map(tab => (
          <button 
            key={tab.id} 
            onClick={() => setActiveTab(tab.id as any)} 
            className={`flex items-center gap-3 px-8 py-5 rounded-[32px] text-[10px] font-black uppercase transition-all shrink-0 ${activeTab === tab.id ? 'bg-pink-600 text-white shadow-xl shadow-pink-500/20' : 'text-slate-500 hover:text-pink-600'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </nav>

      {/* --- TAB: QUADRO (CORE) --- */}
      {activeTab === 'STAFF' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-black dark:text-white">Colaboradores Ativos</h3>
            {staff.map(s => (
              <div 
                key={s.id} 
                onClick={() => setSelectedEmployeeId(s.id)}
                className={`p-6 rounded-[32px] glass flex items-center justify-between group hover:border-pink-500 transition-all border cursor-pointer ${selectedEmployeeId === s.id ? 'border-pink-500 ring-2 ring-pink-500/20' : 'border-slate-100 dark:border-slate-800'}`}
              >
                <div className="flex items-center gap-6">
                  <div className="w-14 h-14 bg-pink-100 text-pink-600 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner uppercase">{s.name.charAt(0)}</div>
                  <div>
                    <h4 className="text-lg font-black dark:text-white">{s.name}</h4>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{s.role}</p>
                  </div>
                </div>
                <Badge color={s.status === 'ATIVO' ? 'emerald' : 'amber'}>{s.status}</Badge>
              </div>
            ))}
          </div>
          <div className="glass p-8 rounded-[40px] border-l-4 border-pink-500">
             <h4 className="text-lg font-black mb-4">Estatísticas do Quadro</h4>
             <div className="grid grid-cols-2 gap-6">
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase">Headcount</p>
                   <p className="text-4xl font-black text-slate-800 dark:text-white">{staff.length}</p>
                </div>
                <div>
                   <p className="text-[10px] font-black text-slate-400 uppercase">Folha Mensal</p>
                   <p className="text-4xl font-black text-pink-600">R$ {staff.reduce((acc, s) => acc + s.salary, 0).toLocaleString()}</p>
                </div>
             </div>
          </div>
        </div>
      )}

      {/* --- TAB: PONTO & JORNADA --- */}
      {activeTab === 'TIME' && (
        <div className="space-y-8">
           {!selectedEmployeeId ? (
             <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-[40px]">
                <p className="text-slate-400 font-bold uppercase text-xs">Selecione um colaborador no Quadro para gerenciar o ponto.</p>
             </div>
           ) : (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <Card title="Registro de Ponto Eletrônico" className="glass border-pink-500/20">
                   <div className="text-center py-8">
                      <div className="text-6xl font-black text-slate-800 dark:text-white mb-2">
                         {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-8">{new Date().toLocaleDateString()}</p>
                      <Button onClick={handleClockIn} className="w-full h-16 bg-pink-600 hover:bg-pink-700 text-lg font-black uppercase rounded-2xl shadow-xl shadow-pink-500/30">Registrar Ponto</Button>
                   </div>
                </Card>
                <div className="space-y-4">
                   <h3 className="text-lg font-black dark:text-white">Espelho de Ponto (Recente)</h3>
                   {timeRecords.filter(t => t.employeeId === selectedEmployeeId).slice(0, 5).map(t => (
                      <div key={t.id} className="p-4 rounded-2xl bg-white/50 dark:bg-slate-800/50 border border-slate-100 flex justify-between items-center">
                         <div>
                            <p className="text-xs font-black dark:text-white">{new Date(t.date).toLocaleDateString()}</p>
                            <div className="flex gap-2 mt-1">
                               {t.entries.map((e, i) => (
                                 <span key={i} className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-bold text-slate-500">{new Date(e).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                               ))}
                            </div>
                         </div>
                         <Badge color={t.entries.length % 2 === 0 ? 'emerald' : 'amber'}>{t.entries.length % 2 === 0 ? 'FECHADO' : 'ABERTO'}</Badge>
                      </div>
                   ))}
                </div>
             </div>
           )}
        </div>
      )}

      {/* --- TAB: CUSTO REAL --- */}
      {activeTab === 'COSTS' && (
         <div className="space-y-8">
            <div className="p-6 bg-indigo-50 dark:bg-indigo-900/10 rounded-[32px] border border-indigo-100 flex gap-4 items-center">
               <Calculator className="text-indigo-600" size={32} />
               <div className="flex-1">
                  <h4 className="font-black text-indigo-800 dark:text-indigo-300 text-sm uppercase tracking-widest">Algoritmo de Rateio Financeiro</h4>
                  <p className="text-xs text-indigo-700/70 dark:text-indigo-400 mt-1">
                     O sistema calcula o custo hora real (Salário + 60% Encargos / 220h) e cruza com a alocação em projetos.
                  </p>
               </div>
               <Button onClick={handleCostCalculation} disabled={!selectedEmployeeId} className="bg-indigo-600 font-black uppercase text-[10px]">Executar Rateio</Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <Card title="Simulação de Custo Hora" className="glass">
                  {selectedEmployee ? (
                     <div className="space-y-6 mt-4">
                        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                           <span className="text-xs font-bold text-slate-500">Salário Base</span>
                           <span className="font-black">R$ {selectedEmployee.salary.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center pb-4 border-b border-slate-100">
                           <span className="text-xs font-bold text-slate-500">Encargos (+60%)</span>
                           <span className="font-black text-rose-500">+ R$ {(selectedEmployee.salary * 0.6).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between items-center pt-2">
                           <span className="text-sm font-black text-indigo-600 uppercase tracking-widest">Custo Hora Efetivo</span>
                           <span className="text-2xl font-black text-indigo-600">R$ {((selectedEmployee.salary * 1.6) / 220).toFixed(2)}</span>
                        </div>
                     </div>
                  ) : (
                     <p className="text-center py-10 text-slate-400 text-xs font-bold uppercase">Selecione um colaborador.</p>
                  )}
               </Card>
            </div>
         </div>
      )}

      {/* Only keeping Modal for completeness of the example, simplified */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Admissão de Colaborador">
        <div className="p-6 text-center">
           <p className="text-slate-500">Formulário de admissão (mantido do original)...</p>
           <Button onClick={() => setIsModalOpen(false)} className="mt-4">Fechar</Button>
        </div>
      </Modal>
    </div>
  );
};


export type PermissionCode = string;

export enum UserStatus {
  ACTIVE = 'ACTIVE',
  BLOCKED = 'BLOCKED',
  VACATION = 'VACATION',
  PENDING = 'PENDING'
}

export enum RoleType {
  INTERNAL = 'INTERNAL',
  EXTERNAL = 'EXTERNAL'
}

export interface Permission {
  code: PermissionCode;
  label: string;
  module: string;
}

export interface Role {
  id: string;
  name: string;
  description: string;
  level: number;
  financialLimit: number;
  type: RoleType;
  permissions: PermissionCode[];
  icon: string;
  color: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  roleId: string;
  status: UserStatus;
  mfaEnabled: boolean;
  extraPermissions: PermissionCode[];
  photoURL: string;
  admissionDate: string;
  department?: string;
  position?: string;
  lastAccess?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  module: string;
  details: string;
  criticality: 'INFO' | 'WARN' | 'CRITICAL';
  timestamp: string;
  ip: string;
  device?: string;
  oldValue?: string;
  newValue?: string;
}

// Supply Chain
export interface Material {
  id: string;
  sku: string;
  name: string;
  category: string;
  type: string;
  abcClass: 'A' | 'B' | 'C';
  xyzClass: 'X' | 'Y' | 'Z';
  status: 'ATIVO' | 'INATIVO';
  quantity: number;
  unitValue: number;
  totalValue: number;
  minQuantity: number;
  location: string;
  uomBase: string;
  createdAt: string;
  updatedAt: string;
  batches?: Batch[];
  averageCost?: number;
}

export interface Batch {
  id: string;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  location: string;
  materialId: string;
}

export interface Supplier {
  id: string;
  companyName: string;
  tradeName: string;
  cnpj: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  status: 'ATIVO' | 'BLOQUEADO';
  contacts: any[];
  documents: any[];
  score: { quality: number; delivery: number; price: number; service: number; total: number };
  badge: string;
  compliance?: { riskLevel: string; dpaSigned: boolean };
}

export interface Client {
  id: string;
  name: string;
  email: string;
}

export interface PurchaseRequest {
  id: string;
  items: { materialId: string; materialName: string; quantity: number; unitValue: number; total: number }[];
  projectId: string;
  projectName?: string;
  costCenter: string;
  status: 'PENDING_ANALYSIS' | 'PENDING_DIRECTION' | 'APPROVED' | 'REJECTED';
  urgency: 'NORMAL' | 'URGENTE' | 'EMERGENCIAL';
  justification: string;
  requesterId: string;
  requesterName: string;
  totalValue: number;
  createdAt: string;
  history?: any[];
}

export interface PurchaseOrder {
  id: string;
  supplierName: string;
  totalValue: number;
  deliveryDate: string;
  createdAt: string;
  items: any[];
  status: 'ORDERED' | 'DELIVERED' | 'CANCELLED';
}

export interface Quote {
  id: string;
  status: string;
}

export interface Category {
  id: string;
  name: string;
}

export interface Movement {
  id: string;
  // properties...
}

export interface TechnicalSpec {
  // properties...
}

export interface InventoryCount {
  id: string;
  date: string;
  status: 'OPEN' | 'CLOSED';
  responsible: string;
  createdAt: string;
  items: { materialId: string; materialName: string; systemQty: number; countedQty: number; divergence: number }[];
}

export interface SupplyContract {
  id: string;
  supplierId: string;
  supplierName: string;
  materialId: string;
  materialName: string;
  fixedPrice: number;
  validityStart: string;
  validityEnd: string;
  slaDays: number;
  active: boolean;
}

// Projects
export enum ProjectPhase {
  IDEATION = 'IDEATION',
  PLANNING = 'PLANNING',
  EXECUTION = 'EXECUTION',
  CLOSING = 'CLOSING'
}

export interface ProjectScoring {
  strategicAlignment: number;
  roi: number;
  urgency: number;
  totalScore: number;
}

export interface ProjectTask {
  id: string;
  wbsCode: string;
  name: string;
  type: string;
  startDate: string;
  endDate: string;
  durationPlanned: number;
  progress: number;
  costEstimate: number;
  actualCost: number;
  dependencies: any[]; // string[] or object[]
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED';
  isCritical: boolean;
  assignedHours: number;
  responsibleName?: string;
  responsibleId?: string;
}

export interface ProjectRisk {
  id: string;
  title: string;
  description: string;
  category: string;
  probability: number;
  impact: { schedule: number; cost: number; scope: number; quality: number };
  overallImpact: number;
  score: number;
  strategy: string;
  responsePlan: string;
  contingencyPlan: string;
  ownerId: string;
  ownerName: string;
  status: string;
  contingencyBudget: number;
}

export interface ChangeRequest {
  id: string;
  seq: number;
  title: string;
  description: string;
  requesterId: string;
  requesterName: string;
  date: string;
  justification: string;
  type: string[];
  impact: { scope: string; scheduleDays: number; cost: number; risks: string };
  status: 'SUBMITTED' | 'APPROVED' | 'REJECTED';
  approvals: any[];
}

export interface QualityItem {
  id: string;
  deliverable: string;
  criteria: string;
  status: 'PENDING' | 'PASSED' | 'FAILED';
  inspectorId?: string;
}

export interface Stakeholder {
  id: string;
  name: string;
  organization: string;
  role: string;
  interest: 'HIGH' | 'MEDIUM' | 'LOW';
  influence: 'HIGH' | 'MEDIUM' | 'LOW';
  engagementLevel: { current: string; desired: string };
  expectations: string;
  commRequirements: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  phase: ProjectPhase;
  status: string;
  justification: string;
  objectives_smart: string[];
  scope_included: string[];
  scope_excluded: string[];
  assumptions: string[];
  constraints: string[];
  managerId: string;
  managerName: string;
  sponsorId: string;
  sponsorName: string;
  financerId: string;
  financerName: string;
  approvedValue: number;
  managementReserve: number;
  contingencyReserve: number;
  executedValue: number;
  startDate: string;
  endDate: string;
  baselineSet: boolean;
  tasks: ProjectTask[];
  risks: ProjectRisk[];
  changes: ChangeRequest[];
  stakeholders: Stakeholder[];
  theoryOfChange: any[];
  odsIndicators: any[];
  qualityPlan: QualityItem[];
  scoring?: ProjectScoring;
  createdAt: string;
  updatedAt: string;
  baselineDate?: string;
}

export interface TAP {
  id: string;
  projectId: string;
  sponsorName: string;
  businessCase: string;
  projectDescription: string;
  preliminaryScope: string;
  majorDeliverables: string[];
  keyConstraints: string[];
  assumptions: string[];
  budgetLimit: number;
  approvals: { role: string; name: string; signed: boolean }[];
  version: number;
  lastUpdate: string;
}

export interface ProjectBaseline {
  id: string;
  projectId: string;
  version: string;
  createdAt: string;
  createdBy: string;
  snapshot: any;
  varianceCost?: number;
  varianceSchedule?: number;
}

export interface LessonLearned {
  id: string;
  projectId: string;
  phase: ProjectPhase;
  category: 'TECNICO' | 'GERENCIAL' | 'EXTERNO' | 'PESSOAS';
  description: string;
  impact: 'POSITIVO' | 'NEGATIVO';
  recommendation: string;
  createdAt: string;
}

export interface ProjectCriteria {
  minAge?: number;
  maxAge?: number;
  gender?: string;
  location?: string[];
  requiredVulnerabilities?: string[];
}

export type TaskDependencyType = 'FS' | 'SS' | 'FF' | 'SF';

// Finance
export interface CostCenter {
  id: string;
  name: string;
  budget?: number;
}

export interface FinanceTransaction {
  id: string;
  description: string;
  amount: number;
  netAmount?: number;
  type: 'IN' | 'OUT';
  date: string;
  dueDate?: string;
  paymentDate?: string;
  status: 'SCHEDULED' | 'PAID' | 'PENDING_APPROVAL';
  category: string;
  chartOfAccountId?: string;
  bankAccountId?: string;
  costCenterId?: string;
  projectId?: string;
  splits?: TransactionSplit[];
  retentions?: { iss: number; inss: number; irrf: number; pisCofinsCsll: number };
  docNumber?: string;
  reconciled?: boolean;
}

export interface TransactionSplit {
  costCenterId: string;
  amount: number;
  percentage: number;
}

export interface BankAccount {
  id: string;
  name: string;
  bankCode: string;
  agency: string;
  accountNumber: string;
  initialBalance: number;
  currentBalance: number;
  currency: string;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface ChartOfAccount {
  id: string;
  code: string;
  name: string;
  type: 'REVENUE' | 'EXPENSE' | 'ASSET' | 'LIABILITY';
  category: 'OPERATIONAL' | 'FINANCIAL' | 'PERSONNEL' | 'TAX';
  level: number;
}

export interface Budget {
  id: string;
  year: number;
  costCenterId: string;
  totalAmount: number;
  monthlyDistribution: number[];
  revision: number;
  status: 'APPROVED' | 'DRAFT';
}

// CRM
export interface Beneficiary {
  id: string;
  name: string;
  cpf: string;
  birthDate: string;
  gender: string;
  race: string;
  phone: string;
  email: string;
  address: {
    cep: string;
    street: string;
    number: string;
    neighborhood: string;
    city: string;
    uf: string;
  };
  familyComposition: {
    peopleCount: number;
    monthlyIncome: number;
    dependents: any[];
  };
  vulnerabilities: string[];
  projectsLinked: string[];
  lgpdConsent: { accepted: boolean; timestamp: string; revokedAt?: string };
  status: 'ATIVO' | 'INATIVO';
  createdAt: string;
  lastInteraction?: string;
  isAnonymized?: boolean;
}

export interface Attendance {
  id: string;
  beneficiaryId: string;
  type: string;
  location: string;
  date: string;
}

export interface Funder {
  id: string;
  // props
}

export type DonorStatus = 'LEAD' | 'PROSPECT' | 'ACTIVE_ONE_OFF' | 'ACTIVE_RECURRING' | 'CHURNED';

export interface Donor {
  id: string;
  name: string;
  email: string;
  phone: string;
  identifier: string;
  type: 'PF' | 'PJ';
  status: DonorStatus;
  totalDonated: number;
  acquisitionChannel: string;
}

export interface Donation {
  id: string;
  value: number;
}

export interface CRMCommunication {
  id: string;
  timestamp: string;
  channel: 'WHATSAPP' | 'EMAIL' | 'REUNIÃO PRESENCIAL';
  subject: string;
  content: string;
  contactType: string;
  direction: 'INBOUND' | 'OUTBOUND';
}

// Contracts & Grants
export enum ContractStatus {
  VIGENTE = 'Vigente',
  EXPIRADO = 'Expirado',
  CANCELADO = 'Cancelado'
}

export interface Contract {
  id: string;
  title: string;
  supplierId: string;
  value: number;
  validity: string;
  status: ContractStatus;
  documents: any[];
}

export interface Grant {
  id: string;
  title: string;
  grantNumber: string;
  funderName: string;
  startDate: string;
  endDate: string;
  totalAmount: number;
  disbursementSchedule: any[];
  status: string;
  accountabilityDeadline: string;
}

// Documents
export interface Document {
  id: string;
  name: string;
  size: string;
  type: string;
  owner: string;
  tags: string[];
  isDrive: boolean;
  link?: string;
}

// Patrimony / Assets
export interface Asset {
  id: string;
  name: string;
  code: string;
  category: string;
  value: number;
  acquisitionDate: string;
  lifespan: number;
  location: string;
  status: 'Operacional' | 'Manutenção' | 'Baixado';
  description: string;
  lastInventoryDate?: string;
  lastInventoryBy?: string;
}

export type MaintenanceType = 'PREVENTIVA' | 'CORRETIVA' | 'PREDITIVA';
export type MaintenanceStatus = 'ABERTA' | 'EM_ANALISE' | 'EM_EXECUCAO' | 'CONCLUIDA' | 'CANCELADA';

export interface MaintenanceOrder {
  id: string;
  assetId: string;
  assetName: string;
  type: MaintenanceType;
  status: MaintenanceStatus;
  priority: 'BAIXA' | 'MEDIA' | 'ALTA' | 'CRITICA';
  description: string;
  technicianId?: string;
  technicianName?: string;
  scheduledDate: string;
  completedDate?: string;
  cost: number;
  notes?: string;
  createdAt: string;
}

export interface AssetQRCode {
  assetId: string;
  code: string;
  generatedAt: string;
}

export interface AssetInsurance {
  id: string;
  assetId: string;
  policyNumber: string;
  insurerName: string;
  premiumValue: number;
  coverageValue: number;
  startDate: string;
  endDate: string;
  status: 'VIGENTE' | 'VENCIDA' | 'CANCELADA';
}

export interface AssetRevaluation {
  id: string;
  assetId: string;
  oldValue: number;
  newValue: number;
  revaluationDate: string;
  reason: string;
  responsibleId: string;
}

export interface AccountingEntry {
  id: string;
  assetId: string;
  date: string;
  type: 'DEPRECIACAO' | 'BAIXA' | 'REAVALIACAO';
  debitAccount: string;
  creditAccount: string;
  amount: number;
  description: string;
  processedBy: string;
}

// Reports
export interface InstitutionalReport {
  id: string;
  title: string;
  period: string;
  type: string;
  generatedBy: string;
  summary: string;
  indicators: {
    directImpact: number;
    indirectImpact: number;
    foodDistributedKg: number;
    basketsDistributed: number;
  };
  status: string;
  createdAt: string;
}

// Conformia
export interface DataActivity {
  id: string;
  processName: string;
  moduleLink: string;
  legalBase: string;
  dataCategories: string[];
  status: 'MAPPED' | 'REVIEW';
}

export interface SubjectRequest {
  id: string;
  subjectName: string;
  subjectEmail: string;
  type: string;
  status: 'PENDING' | 'RESPONDED';
  createdAt: string;
}

export interface ConformiaIncident {
  id: string;
  description: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'OPEN' | 'RESOLVED';
  reportedAt: string;
}

export interface ConformiaPolicy {
  id: string;
  status: 'PUBLISHED' | 'DRAFT';
  title: string;
  category: string;
  version: string;
  nextReview: string;
}

export interface ConformiaTraining {
  id: string;
  title: string;
  theme: string;
  minScore: number;
}

export interface DPIA {
  id: string;
  version: string;
  status: string;
  steps: { identification: string };
  updatedAt: string;
}

export interface ThirdPartyAssessment {
  id: string;
  supplierId: string;
  supplierName: string;
  status: string;
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  questionnaire: {
    iso27001: boolean;
    hasDPO: boolean;
    hasEncryption: boolean;
    hasIncidentPlan: boolean;
    dataRetentionPolicy: boolean;
  };
  evidenceUrl?: string;
  assessedBy: string;
  assessedAt: string;
}

export interface DataSharingLog {
  id: string;
  timestamp: string;
  senderId: string;
  recipient: string;
  dataCategories: string[];
  purpose: string;
  legalBase: string;
  transferMechanism: string;
  encrypted: boolean;
}

export interface BCPPlan {
  id: string;
  title: string;
  scenarios: string[];
  activationTrigger: string;
  rto: string;
  rpo: string;
  communicationPlan: string;
  status: 'DRAFT' | 'ACTIVE' | 'ARCHIVED';
  lastTestDate?: string;
}

export interface IncidentSimulation {
  scenario: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  affectedSystems: string[];
  estimatedDataLoss: string;
  recommendedActions: string[];
}

export interface MaturityAssessment {
  id: string;
  date: string;
  score: number;
  breakdown: { governance: number; process: number; technology: number; people: number };
  answers: Record<string, boolean>;
}

// --- NOVAS ENTIDADES HR TECH (ADDITIVE ARCHITECTURE) ---

export interface TimeRecord {
  id: string;
  employeeId: string; // FK to Employee/User
  date: string; // ISO Date YYYY-MM-DD
  entries: string[]; // Timestamps ISO for Clock-in/Clock-out
  type: 'NORMAL' | 'EXTRA' | 'FOLGA';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  totalHours: number;
}

export interface AbsenceRequest {
  id: string;
  employeeId: string;
  type: 'FERIAS' | 'ATESTADO' | 'FOLGA_BANCO';
  startDate: string;
  endDate: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  attachmentUrl?: string;
}

export interface HRDocument {
  id: string;
  employeeId: string;
  title: string;
  type: 'CONTRATO' | 'IDENTIDADE' | 'COMPROVANTE_RESIDENCIA' | 'CERTIFICADO';
  url: string;
  uploadDate: string;
  status: 'VALIDADO' | 'PENDENTE';
  expiryDate?: string;
}

export interface PerformanceCycle {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  status: 'OPEN' | 'CLOSED';
}

export interface PerformanceReview {
  id: string;
  cycleId: string;
  employeeId: string;
  evaluatorId: string;
  selfRating: number;
  managerRating: number;
  feedback: string;
  status: 'DRAFT' | 'SUBMITTED' | 'FINALIZED';
  completedAt?: string;
}

export interface TrainingCourse {
  id: string;
  title: string;
  category: string;
  durationHours: number;
  description: string;
  url?: string;
}

export interface EmployeeTraining {
  id: string;
  employeeId: string;
  courseId: string;
  progress: number;
  status: 'IN_PROGRESS' | 'COMPLETED';
  certificateUrl?: string;
  completedAt?: string;
}

export interface ProjectCostAllocation {
  id: string;
  employeeId: string;
  projectId: string;
  month: string; // YYYY-MM
  hoursAllocated: number;
  hourlyRate: number; // Calculated based on salary + overhead
  totalCost: number;
  source: 'TIMESHEET' | 'ESTIMATED';
}


import { 
  User, Role, Material, Project, AuditLog, UserStatus, 
  FinanceTransaction, CostCenter, Category, TAP,
  Beneficiary, Attendance, Funder, Donor, Donation, CRMCommunication, ProjectPhase,
  Client, PurchaseOrder, RoleType, Document, Asset, InstitutionalReport,
  Contract, ContractStatus, Supplier, PurchaseRequest, Quote,
  // New HR Types
  TimeRecord, AbsenceRequest, PerformanceCycle, PerformanceReview, TrainingCourse, EmployeeTraining, HRDocument, ProjectCostAllocation
} from '../types';

const DB_KEYS = {
  USERS: 'gira_users_v2',
  ROLES: 'gira_roles_v2',
  MATERIALS: 'gira_materials_v2',
  SUPPLIERS: 'gira_suppliers_v2',
  CLIENTS: 'gira_clients_v2',
  PROJECTS: 'gira_projects_v2',
  LOGS: 'gira_audit_v2',
  MOVEMENTS: 'gira_movements_v2',
  PURCHASE_REQUESTS: 'gira_purchase_requests_v2',
  PURCHASE_ORDERS: 'gira_purchase_orders_v2',
  FINANCE: 'gira_finance_v2',
  COST_CENTERS: 'gira_cost_centers_v2',
  PATRIMONY: 'gira_patrimony_v2',
  HR: 'gira_hr_v2', // Core Funcionarios (Read-Only for new modules)
  CONTRACTS: 'gira_contracts_v2',
  DOCUMENTS: 'gira_documents_v2',
  CATEGORIES: 'gira_categories_v2',
  QUOTES: 'gira_quotes_v2',
  TAPS: 'gira_taps_v2',
  DIARY: 'gira_diary_v2',
  BENEFICIARIES: 'gira_crm_beneficiaries_v1',
  ATTENDANCES: 'gira_crm_attendances_v1',
  FUNDERS: 'gira_crm_funders_v1',
  DONORS: 'gira_crm_donors_v1',
  DONATIONS: 'gira_crm_donations_v1',
  COMMUNICATIONS: 'gira_crm_communications_v1',
  DATA_MAPPING: 'conformia_data_mapping_v1',
  SUBJECT_REQUESTS: 'conformia_subject_requests_v1',
  INCIDENTS: 'conformia_incidents_v1',
  POLICIES: 'conformia_policies_v1',
  TRAININGS: 'conformia_trainings_v1',
  DPIAS: 'conformia_dpias_v1',
  INSTITUTIONAL_REPORTS: 'gira_institutional_reports_v1',
  // New HR Collections
  HR_TIME_RECORDS: 'hr_time_records_v1',
  HR_ABSENCES: 'hr_absences_v1',
  HR_REVIEWS: 'hr_reviews_v1',
  HR_COURSES: 'hr_courses_v1',
  HR_DOCS: 'hr_docs_v1',
  HR_COSTS: 'hr_cost_allocations_v1'
};

const getFromStorage = <T,>(key: string, defaultValue: T): T => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : defaultValue;
};

const setToStorage = <T,>(key: string, value: T): void => {
  localStorage.setItem(key, JSON.stringify(value));
};

const delay = (ms: number = 400) => new Promise(res => setTimeout(res, ms));

export const mockDB = {
  // ... (Existing methods retained) ...
  getUsers: () => getFromStorage<User[]>(DB_KEYS.USERS, []),
  saveUser: async (u: User) => {
    await delay();
    const data = getFromStorage<User[]>(DB_KEYS.USERS, []);
    const idx = data.findIndex(i => i.id === u.id);
    if (idx > -1) data[idx] = u; else data.push(u);
    setToStorage(DB_KEYS.USERS, data);
  },

  getRoles: () => getFromStorage<Role[]>(DB_KEYS.ROLES, []),
  saveRole: async (r: Role) => {
    await delay();
    const data = getFromStorage<Role[]>(DB_KEYS.ROLES, []);
    const idx = data.findIndex(i => i.id === r.id);
    if (idx > -1) data[idx] = r; else data.push(r);
    setToStorage(DB_KEYS.ROLES, data);
  },

  getLogs: () => getFromStorage<AuditLog[]>(DB_KEYS.LOGS, []),
  audit: async (log: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const logs = getFromStorage<AuditLog[]>(DB_KEYS.LOGS, []);
    logs.unshift({ ...log, id: crypto.randomUUID(), timestamp: new Date().toISOString() });
    setToStorage(DB_KEYS.LOGS, logs.slice(0, 1000));
  },

  getCostCenters: () => getFromStorage<CostCenter[]>(DB_KEYS.COST_CENTERS, []),
  saveCostCenter: async (cc: CostCenter) => {
    await delay();
    const data = getFromStorage<CostCenter[]>(DB_KEYS.COST_CENTERS, []);
    const idx = data.findIndex(i => i.id === cc.id);
    if (idx > -1) data[idx] = cc; else data.push(cc);
    setToStorage(DB_KEYS.COST_CENTERS, data);
  },

  getFinanceTransactions: () => getFromStorage<FinanceTransaction[]>(DB_KEYS.FINANCE, []),
  saveFinanceTransaction: async (t: FinanceTransaction) => {
    await delay();
    const data = getFromStorage<FinanceTransaction[]>(DB_KEYS.FINANCE, []);
    const idx = data.findIndex(i => i.id === t.id);
    if (idx > -1) data[idx] = t; else data.unshift({ ...t, id: t.id || crypto.randomUUID() });
    setToStorage(DB_KEYS.FINANCE, data);
  },
  deleteFinanceTransaction: async (id: string) => {
    await delay();
    const data = getFromStorage<FinanceTransaction[]>(DB_KEYS.FINANCE, []);
    setToStorage(DB_KEYS.FINANCE, data.filter(i => i.id !== id));
  },

  getMaterials: () => getFromStorage<Material[]>(DB_KEYS.MATERIALS, []),
  saveMaterial: async (m: Material) => {
    await delay();
    const data = getFromStorage<Material[]>(DB_KEYS.MATERIALS, []);
    const idx = data.findIndex(i => i.id === m.id);
    if (idx > -1) data[idx] = m; else data.push(m);
    setToStorage(DB_KEYS.MATERIALS, data);
  },

  getSuppliers: () => getFromStorage<Supplier[]>(DB_KEYS.SUPPLIERS, []),
  saveSupplier: async (s: Supplier) => {
    await delay();
    const data = getFromStorage<Supplier[]>(DB_KEYS.SUPPLIERS, []);
    const idx = data.findIndex(i => i.id === s.id);
    if (idx > -1) data[idx] = s; else data.push(s);
    setToStorage(DB_KEYS.SUPPLIERS, data);
  },

  getClients: () => getFromStorage<Client[]>(DB_KEYS.CLIENTS, []),
  saveClient: async (c: Client) => {
    await delay();
    const data = getFromStorage<Client[]>(DB_KEYS.CLIENTS, []);
    const idx = data.findIndex(i => i.id === c.id);
    if (idx > -1) data[idx] = c; else data.push(c);
    setToStorage(DB_KEYS.CLIENTS, data);
  },
  deleteClient: async (id: string) => {
    await delay();
    const data = getFromStorage<Client[]>(DB_KEYS.CLIENTS, []);
    setToStorage(DB_KEYS.CLIENTS, data.filter(c => c.id !== id));
  },

  getProjects: () => getFromStorage<Project[]>(DB_KEYS.PROJECTS, []),
  saveProject: async (p: Project) => {
    await delay();
    const data = getFromStorage<Project[]>(DB_KEYS.PROJECTS, []);
    const idx = data.findIndex(i => i.id === p.id);
    if (idx > -1) data[idx] = p; else data.push(p);
    setToStorage(DB_KEYS.PROJECTS, data);
  },

  getPurchaseRequests: () => getFromStorage<PurchaseRequest[]>(DB_KEYS.PURCHASE_REQUESTS, []),
  savePurchaseRequest: async (pr: PurchaseRequest) => {
    await delay();
    const data = getFromStorage<PurchaseRequest[]>(DB_KEYS.PURCHASE_REQUESTS, []);
    const idx = data.findIndex(i => i.id === pr.id);
    if (idx > -1) data[idx] = pr; else data.push(pr);
    setToStorage(DB_KEYS.PURCHASE_REQUESTS, data);
  },

  getQuotes: () => getFromStorage<Quote[]>(DB_KEYS.QUOTES, []),
  saveQuote: async (q: Quote) => {
    await delay();
    const data = getFromStorage<Quote[]>(DB_KEYS.QUOTES, []);
    const idx = data.findIndex(i => i.id === q.id);
    if (idx > -1) data[idx] = q; else data.push(q);
    setToStorage(DB_KEYS.QUOTES, data);
  },

  getPurchaseOrders: () => getFromStorage<PurchaseOrder[]>(DB_KEYS.PURCHASE_ORDERS, []),
  savePurchaseOrder: async (po: PurchaseOrder) => {
    await delay();
    const data = getFromStorage<PurchaseOrder[]>(DB_KEYS.PURCHASE_ORDERS, []);
    const idx = data.findIndex(i => i.id === po.id);
    if (idx > -1) data[idx] = po; else data.push(po);
    setToStorage(DB_KEYS.PURCHASE_ORDERS, data);
  },

  getDocs: () => getFromStorage<Document[]>(DB_KEYS.DOCUMENTS, []),
  saveDoc: async (d: Document) => {
    await delay();
    const data = getFromStorage<Document[]>(DB_KEYS.DOCUMENTS, []);
    const idx = data.findIndex(i => i.id === d.id);
    if (idx > -1) data[idx] = d; else data.push(d);
    setToStorage(DB_KEYS.DOCUMENTS, data);
  },

  getCategories: () => getFromStorage<Category[]>(DB_KEYS.CATEGORIES, []),
  saveCategory: async (c: Category) => {
    await delay();
    const data = getFromStorage<Category[]>(DB_KEYS.CATEGORIES, []);
    const idx = data.findIndex(i => i.id === c.id);
    if (idx > -1) data[idx] = c; else data.push(c);
    setToStorage(DB_KEYS.CATEGORIES, data);
  },

  getTAPs: () => getFromStorage<TAP[]>(DB_KEYS.TAPS, []),
  saveTAP: async (t: TAP) => {
    await delay();
    const data = getFromStorage<TAP[]>(DB_KEYS.TAPS, []);
    const idx = data.findIndex(i => i.projectId === t.projectId);
    if (idx > -1) data[idx] = t; else data.push(t);
    setToStorage(DB_KEYS.TAPS, data);
  },

  getBeneficiaries: () => getFromStorage<Beneficiary[]>(DB_KEYS.BENEFICIARIES, []),
  saveBeneficiary: async (b: Beneficiary) => {
    await delay();
    const data = getFromStorage<Beneficiary[]>(DB_KEYS.BENEFICIARIES, []);
    const idx = data.findIndex(i => i.id === b.id);
    if (idx > -1) data[idx] = b; else data.push(b);
    setToStorage(DB_KEYS.BENEFICIARIES, data);
  },

  getAttendances: () => getFromStorage<Attendance[]>(DB_KEYS.ATTENDANCES, []),
  saveAttendance: async (a: Attendance) => {
    await delay();
    const data = getFromStorage<Attendance[]>(DB_KEYS.ATTENDANCES, []);
    const idx = data.findIndex(i => i.id === a.id);
    if (idx > -1) data[idx] = a; else data.push(a);
    setToStorage(DB_KEYS.ATTENDANCES, data);
  },

  getDonors: () => getFromStorage<Donor[]>(DB_KEYS.DONORS, []),
  getDonations: () => getFromStorage<Donation[]>(DB_KEYS.DONATIONS, []),
  saveDonation: async (d: Donation) => {
    await delay();
    const data = getFromStorage<Donation[]>(DB_KEYS.DONATIONS, []);
    data.unshift(d);
    setToStorage(DB_KEYS.DONATIONS, data);
  },

  getFunders: () => getFromStorage<Funder[]>(DB_KEYS.FUNDERS, []),
  getCommunications: () => getFromStorage<CRMCommunication[]>(DB_KEYS.COMMUNICATIONS, []),

  getInstitutionalReports: () => getFromStorage<InstitutionalReport[]>(DB_KEYS.INSTITUTIONAL_REPORTS, []),
  saveInstitutionalReport: async (r: InstitutionalReport) => {
    await delay();
    const data = getFromStorage<InstitutionalReport[]>(DB_KEYS.INSTITUTIONAL_REPORTS, []);
    const idx = data.findIndex(i => i.id === r.id);
    if (idx > -1) data[idx] = r; else data.unshift(r);
    setToStorage(DB_KEYS.INSTITUTIONAL_REPORTS, data);
  },

  getPatrimony: () => getFromStorage<Asset[]>(DB_KEYS.PATRIMONY, []),
  saveAsset: async (a: Asset) => {
    await delay();
    const data = getFromStorage<Asset[]>(DB_KEYS.PATRIMONY, []);
    const idx = data.findIndex(i => i.id === a.id);
    if (idx > -1) data[idx] = a; else data.push(a);
    setToStorage(DB_KEYS.PATRIMONY, data);
  },

  getContracts: () => getFromStorage<Contract[]>(DB_KEYS.CONTRACTS, []),
  saveContract: async (c: Contract) => {
    await delay();
    const data = getFromStorage<Contract[]>(DB_KEYS.CONTRACTS, []);
    const idx = data.findIndex(i => i.id === c.id);
    if (idx > -1) data[idx] = c; else data.push(c);
    setToStorage(DB_KEYS.CONTRACTS, data);
  },
  deleteContract: async (id: string) => {
    await delay();
    const data = getFromStorage<Contract[]>(DB_KEYS.CONTRACTS, []);
    setToStorage(DB_KEYS.CONTRACTS, data.filter(i => i.id !== id));
  },

  getHR: () => getFromStorage<any[]>(DB_KEYS.HR, []),
  getLGPDInventory: () => getFromStorage<any[]>(DB_KEYS.DATA_MAPPING, []),
  getSubjectRequests: () => getFromStorage<any[]>(DB_KEYS.SUBJECT_REQUESTS, []),
  getConformiaIncidents: () => getFromStorage<any[]>(DB_KEYS.INCIDENTS, []),
  getConformiaPolicies: () => getFromStorage<any[]>(DB_KEYS.POLICIES, []),
  getConformiaTrainings: () => getFromStorage<any[]>(DB_KEYS.TRAININGS, []),
  getDPIAs: () => getFromStorage<any[]>(DB_KEYS.DPIAS, []),
  
  // New HR Accessors
  getHRTimeRecords: () => getFromStorage<TimeRecord[]>(DB_KEYS.HR_TIME_RECORDS, []),
  getHRAbsences: () => getFromStorage<AbsenceRequest[]>(DB_KEYS.HR_ABSENCES, []),
  getHRReviews: () => getFromStorage<PerformanceReview[]>(DB_KEYS.HR_REVIEWS, []),
  getHRCourses: () => getFromStorage<TrainingCourse[]>(DB_KEYS.HR_COURSES, []),
  getHRDocs: () => getFromStorage<HRDocument[]>(DB_KEYS.HR_DOCS, []),
  
  // Added getChartData to satisfy Dashboard consumption
  getChartData: () => [
    { name: 'Jan', suprimentos: 4000, projetos: 2400 },
    { name: 'Fev', suprimentos: 3000, projetos: 1398 },
    { name: 'Mar', suprimentos: 2000, projetos: 9800 },
    { name: 'Abr', suprimentos: 2780, projetos: 3908 },
    { name: 'Mai', suprimentos: 1890, projetos: 4800 },
    { name: 'Jun', suprimentos: 2390, projetos: 3800 },
  ],
};

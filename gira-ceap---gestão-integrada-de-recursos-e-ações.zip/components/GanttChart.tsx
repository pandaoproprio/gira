
import React, { useState, useMemo, useEffect } from 'react';
import { Card, Badge, Modal, Input, Button, useToast } from './UI';
import { ProjectTask } from '../types';
import { Edit2, Clock, User, Link as LinkIcon, AlertCircle, CheckCircle2, ChevronRight, Zap, Target, GitCommit } from 'lucide-react';

// Helper para calcular datas
const addDays = (date: Date, days: number) => {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
};

export const GanttChart: React.FC<{ tasks: ProjectTask[]; onUpdate?: () => void }> = ({ tasks, onUpdate }) => {
  const toast = useToast();
  const [editingTask, setEditingTask] = useState<ProjectTask | null>(null);
  const [zoomLevel, setZoomLevel] = useState<'DAY' | 'WEEK' | 'MONTH'>('WEEK');

  // Algoritmo de Caminho Crítico (Simplificado para visualização)
  const processedTasks = useMemo(() => {
    if (!tasks || tasks.length === 0) return [];

    // 1. Map tasks for easier access
    const taskMap = new Map(tasks.map(t => [t.id, { ...t, earlyStart: 0, earlyFinish: 0, lateStart: 0, lateFinish: 0, float: 0 }]));

    // Note: A full CPM implementation requires topographical sort and multiple passes.
    // For this UI visualization, we will identify critical tasks based on simple float logic relative to project end.
    // Assuming the user inputs dates manually, we calculate "Slack" as (Late Finish - Early Finish).
    // In a real scheduling engine, we would calculate dates based on dependencies.
    
    // Here we mark tasks as critical if they have 0 slack or are explicitly marked.
    return tasks.map(t => ({
      ...t,
      isCritical: t.progress < 100 && (t.isCritical || false) // Mantém a flag se já existir ou lógica futura
    }));
  }, [tasks]);

  const minDate = useMemo(() => {
    if (!tasks || !tasks.length) return new Date();
    return new Date(Math.min(...tasks.map(t => new Date(t.startDate).getTime())));
  }, [tasks]);

  const maxDate = useMemo(() => {
    if (!tasks || !tasks.length) return new Date();
    return new Date(Math.max(...tasks.map(t => new Date(t.endDate).getTime())));
  }, [tasks]);

  const totalDays = Math.max(1, Math.ceil((maxDate.getTime() - minDate.getTime()) / (1000 * 3600 * 24)) + 15);

  if (!tasks || tasks.length === 0) return (
    <div className="py-40 text-center glass rounded-[40px] border-2 border-dashed border-slate-200">
       <Target size={48} className="mx-auto text-slate-300 mb-6" />
       <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Cronograma Vazio</p>
       <p className="text-xs text-slate-300 mt-2">Adicione atividades na EAP para gerar a visualização temporal.</p>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center px-4">
         <div className="flex gap-3 p-1.5 glass rounded-2xl bg-white/20">
            {(['DAY', 'WEEK', 'MONTH'] as const).map(z => (
              <button key={z} onClick={() => setZoomLevel(z)} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${zoomLevel === z ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-indigo-600'}`}>{z}</button>
            ))}
         </div>
         <div className="flex items-center gap-6">
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-rose-500 rounded-full shadow-lg shadow-rose-500/20 animate-pulse"></div><span className="text-[9px] font-black uppercase text-slate-400">Caminho Crítico</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-indigo-600 rounded-full"></div><span className="text-[9px] font-black uppercase text-slate-400">Normal</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-emerald-500 rounded-full"></div><span className="text-[9px] font-black uppercase text-slate-400">Concluído</span></div>
         </div>
      </div>

      <div className="overflow-x-auto pb-8 custom-scrollbar rounded-[40px] border border-slate-100 dark:border-slate-800 bg-white/20 dark:bg-black/10">
        <div className="min-w-[1200px] p-10 space-y-4">
          {processedTasks.sort((a,b) => a.wbsCode.localeCompare(b.wbsCode)).map((task) => {
            const start = new Date(task.startDate);
            const end = new Date(task.endDate);
            const offsetDays = Math.ceil((start.getTime() - minDate.getTime()) / (1000 * 3600 * 24));
            const durationDays = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 3600 * 24)));
            
            const leftPercent = (offsetDays / totalDays) * 100;
            const widthPercent = (durationDays / totalDays) * 100;

            const isCritical = task.isCritical; // || task.progress < 100 && durationDays > 10; // Exemplo de lógica simples se não houver cálculo complexo

            return (
              <div key={task.id} className="flex items-center gap-12 group">
                <div className="w-80 shrink-0 flex items-center justify-between pr-8 border-r border-slate-100 dark:border-slate-800 h-10">
                   <div className="min-w-0">
                      <div className="flex items-center gap-3">
                        <span className="text-[9px] font-black text-indigo-500 shrink-0">{task.wbsCode}</span>
                        <p className={`text-[11px] font-black dark:text-white truncate uppercase tracking-widest ${isCritical ? 'text-rose-500' : ''}`}>{task.name}</p>
                      </div>
                      <p className="text-[9px] text-slate-400 font-bold uppercase mt-1 opacity-0 group-hover:opacity-100 transition-opacity">{new Date(task.startDate).toLocaleDateString()} • {task.progress}%</p>
                   </div>
                   <button onClick={() => setEditingTask(task)} className="p-2 opacity-0 group-hover:opacity-100 transition-all hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-xl">
                      <Edit2 size={14} className="text-indigo-600" />
                   </button>
                </div>
                
                <div className="flex-1 h-10 relative cursor-pointer" onClick={() => setEditingTask(task)}>
                   <div className="absolute top-1/2 -translate-y-1/2 h-px bg-slate-100 dark:bg-slate-800 w-full"></div>
                   
                   {/* Barra de Tarefa */}
                   <div 
                      className={`absolute top-1 bottom-1 rounded-lg shadow-xl transition-all duration-500 flex items-center justify-between px-3 group/bar overflow-hidden ${task.progress === 100 ? 'bg-emerald-500' : isCritical ? 'bg-rose-500 shadow-rose-500/20' : 'bg-indigo-600 shadow-indigo-500/20'} hover:scale-y-125 z-10`}
                      style={{ left: `${leftPercent}%`, width: `${widthPercent}%` }}
                   >
                      <span className="text-[8px] text-white font-black uppercase tracking-tighter truncate opacity-0 group-hover/bar:opacity-100 transition-opacity">R$ {task.costEstimate.toLocaleString()}</span>
                      {task.dependencies?.length > 0 && <LinkIcon size={10} className="text-white/50" />}
                      <div className="absolute left-0 top-0 bottom-0 bg-white/20" style={{ width: `${task.progress}%` }}></div>
                   </div>

                   {/* Conector de Dependência (Visual Simples) */}
                   {task.dependencies?.map((dep, i) => (
                     <div key={i} className="absolute top-1/2 left-0 w-2 h-2 bg-slate-300 rounded-full -ml-1"></div>
                   ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="flex justify-between px-10 text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] py-8 border-t border-slate-100 dark:border-slate-800">
        <span>Início: {minDate.toLocaleDateString()}</span>
        <div className="flex items-center gap-2"><Clock size={12} className="text-indigo-500"/> <span className="text-indigo-600 uppercase tracking-widest font-black">Timeline Enterprise v3.0</span></div>
        <span>Término: {maxDate.toLocaleDateString()}</span>
      </div>

      <Modal isOpen={!!editingTask} onClose={() => setEditingTask(null)} title="Controle Operacional de Atividade">
         {editingTask && (
            <form className="space-y-8" onSubmit={(e) => { e.preventDefault(); setEditingTask(null); toast.success('Atividade atualizada.'); if(onUpdate) onUpdate(); }}>
               <div className="flex justify-between items-start">
                  <div>
                    <Badge color="indigo">WBS: {editingTask.wbsCode}</Badge>
                    <h4 className="text-2xl font-black dark:text-white mt-2 leading-none">{editingTask.name}</h4>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge color={editingTask.progress === 100 ? 'emerald' : 'indigo'}>Status: {editingTask.progress}%</Badge>
                    <label className="flex items-center gap-2 text-[10px] font-bold uppercase cursor-pointer">
                       <input type="checkbox" defaultChecked={editingTask.isCritical} className="accent-rose-500" />
                       <span className="text-rose-500">Forçar Caminho Crítico</span>
                    </label>
                  </div>
               </div>
               <div className="grid grid-cols-2 gap-6">
                  <Input label="Data Início" type="date" defaultValue={editingTask.startDate} required />
                  <Input label="Data Término" type="date" defaultValue={editingTask.endDate} required />
               </div>
               <div className="grid grid-cols-2 gap-6">
                  <Input label="Custo Orçado (Budget)" type="number" defaultValue={editingTask.costEstimate} required />
                  <div className="space-y-1">
                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Percentual Concluído</label>
                     <div className="flex items-center gap-4 pt-3">
                        <input type="range" className="flex-1 accent-indigo-600" min="0" max="100" defaultValue={editingTask.progress} />
                        <span className="text-lg font-black text-indigo-600 min-w-[40px]">{editingTask.progress}%</span>
                     </div>
                  </div>
               </div>
               <div className="p-8 rounded-[32px] bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-start gap-4">
                  <GitCommit size={24} className="text-indigo-500 shrink-0 mt-1" />
                  <div className="space-y-1">
                    <p className="text-xs font-black text-indigo-600 uppercase tracking-widest">Dependências</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                      Gerencie dependências (FS, SS) no menu de EAP para recalcular o caminho crítico automaticamente.
                    </p>
                  </div>
               </div>
               <div className="flex gap-4 pt-6 border-t border-slate-50">
                  <Button type="button" variant="outline" className="flex-1 h-14" onClick={() => setEditingTask(null)}>Fechar</Button>
                  <Button type="submit" className="flex-1 h-14 shadow-xl">Confirmar</Button>
               </div>
            </form>
         )}
      </Modal>
    </div>
  );
};

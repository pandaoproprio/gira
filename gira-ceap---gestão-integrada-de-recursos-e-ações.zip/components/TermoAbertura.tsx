
import React, { useState } from 'react';
import { Card, Button, Input, Modal, useToast } from './UI';
import { FileText, ShieldCheck, Printer, Save, Plus, Edit2 } from 'lucide-react';
import { TAP, Project } from '../types';
import { mockDB } from '../services/mockDB';

export const TermoAbertura: React.FC<{ project: Project; onUpdate: () => void }> = ({ project, onUpdate }) => {
  const toast = useToast();
  const [tap, setTap] = useState<TAP | null>(mockDB.getTAPs().find(t => t.projectId === project.id) || null);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const f = new FormData(e.target as HTMLFormElement);
    const newTap: TAP = {
      id: tap?.id || crypto.randomUUID(),
      projectId: project.id,
      sponsorName: f.get('sponsorName') as string,
      businessCase: f.get('businessCase') as string,
      projectDescription: f.get('projectDescription') as string,
      preliminaryScope: f.get('preliminaryScope') as string,
      majorDeliverables: (f.get('deliverables') as string).split('\n'),
      keyConstraints: (f.get('constraints') as string).split('\n'),
      assumptions: (f.get('assumptions') as string).split('\n'),
      budgetLimit: Number(f.get('budgetLimit')),
      approvals: [{ role: 'Sponsor', name: f.get('sponsorName') as string, signed: false }],
      version: (tap?.version || 0) + 1,
      lastUpdate: new Date().toISOString()
    };
    mockDB.saveTAP(newTap);
    setTap(newTap);
    setIsEditing(false);
    toast.success('Termo de Abertura salvo com sucesso.');
    onUpdate();
  };

  if (!tap && !isEditing) {
    return (
      <div className="py-20 text-center glass rounded-[40px]">
        <FileText size={48} className="mx-auto text-slate-200 mb-6" />
        <h4 className="text-xl font-black dark:text-white mb-2">TAP Não Emitido</h4>
        <p className="text-sm text-slate-400 mb-8 max-w-md mx-auto">O Termo de Abertura do Projeto ainda não foi formalizado para este nodo de impacto.</p>
        <Button onClick={() => setIsEditing(true)}><Plus size={18}/> Iniciar TAP</Button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Termo de Abertura (Charter)</h3>
        <div className="flex gap-4">
           {!isEditing && <Button variant="outline" onClick={() => setIsEditing(true)}><Edit2 size={16}/> Revisar</Button>}
           <Button variant="outline"><Printer size={16}/> Gerar PDF</Button>
        </div>
      </div>

      {isEditing ? (
        <form onSubmit={handleSave} className="space-y-6 glass p-10 rounded-[40px]">
          <div className="grid grid-cols-2 gap-6">
            <Input label="Sponsor / Patrocinador" name="sponsorName" defaultValue={tap?.sponsorName} required />
            <Input label="Limite Orçamentário (R$)" name="budgetLimit" type="number" defaultValue={tap?.budgetLimit} required />
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black uppercase text-slate-400">Business Case (Justificativa Estratégica)</label>
             <textarea name="businessCase" defaultValue={tap?.businessCase} required className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-32"></textarea>
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black uppercase text-slate-400">Descrição do Projeto</label>
             <textarea name="projectDescription" defaultValue={tap?.projectDescription} required className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-24"></textarea>
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black uppercase text-slate-400">Escopo Preliminar (O que está INCLUSO)</label>
             <textarea name="preliminaryScope" defaultValue={tap?.preliminaryScope} required className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-24"></textarea>
          </div>
          <div className="grid grid-cols-2 gap-6">
             <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400">Principais Entregas (Uma por linha)</label>
                <textarea name="deliverables" defaultValue={tap?.majorDeliverables?.join('\n')} required className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-32"></textarea>
             </div>
             <div className="space-y-1">
                <label className="text-[10px] font-black uppercase text-slate-400">Restrições e Premissas (Uma por linha)</label>
                <textarea name="constraints" defaultValue={tap?.keyConstraints?.join('\n')} className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-32"></textarea>
             </div>
          </div>
          <div className="space-y-1">
             <label className="text-[10px] font-black uppercase text-slate-400">Exclusões (O que NÃO será feito)</label>
             <textarea name="assumptions" defaultValue={tap?.assumptions?.join('\n')} className="w-full p-4 rounded-2xl glass bg-white dark:bg-slate-800 text-sm h-24" placeholder="Lista de exclusões de escopo..."></textarea>
          </div>
          <div className="flex justify-end gap-4">
            <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>Cancelar</Button>
            <Button type="submit"><Save size={18}/> Salvar e Publicar</Button>
          </div>
        </form>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <Card className="md:col-span-2 glass" title="Estrutura de Impacto">
              <div className="space-y-6">
                 <div>
                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Patrocinador</p>
                    <p className="text-lg font-black dark:text-white">{tap?.sponsorName}</p>
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Business Case</p>
                    <p className="text-sm dark:text-slate-300 italic">"{tap?.businessCase}"</p>
                 </div>
                 <div>
                    <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Escopo Preliminar</p>
                    <p className="text-sm dark:text-slate-300">{tap?.preliminaryScope}</p>
                 </div>
                 <div className="grid grid-cols-2 gap-4">
                    <div>
                        <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Principais Entregas</p>
                        <ul className="mt-2 space-y-2">
                           {tap?.majorDeliverables?.map((d, i) => (
                             <li key={i} className="flex items-center gap-3 text-sm font-bold dark:text-white">
                                <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div>
                                {d}
                             </li>
                           ))}
                        </ul>
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Restrições</p>
                        <ul className="mt-2 space-y-2">
                           {tap?.keyConstraints?.map((d, i) => (
                             <li key={i} className="flex items-center gap-3 text-sm font-bold dark:text-white">
                                <div className="w-1.5 h-1.5 bg-rose-500 rounded-full"></div>
                                {d}
                             </li>
                           ))}
                        </ul>
                    </div>
                 </div>
              </div>
           </Card>
           <div className="space-y-6">
              <Card className="glass" title="Financeiro TAP">
                 <p className="text-3xl font-black text-indigo-600">R$ {tap?.budgetLimit.toLocaleString()}</p>
                 <p className="text-[9px] font-black text-slate-400 uppercase mt-2">Cap Teto Autorizado</p>
              </Card>
              <Card className="glass" title="Aprovações">
                 {tap?.approvals?.map((app, i) => (
                   <div key={i} className="flex justify-between items-center">
                      <div>
                         <p className="text-xs font-black dark:text-white">{app.name}</p>
                         <p className="text-[9px] text-slate-400 font-bold uppercase">{app.role}</p>
                      </div>
                      <ShieldCheck size={20} className="text-emerald-500" />
                   </div>
                 ))}
              </Card>
           </div>
        </div>
      )}
    </div>
  );
};


import React, { useState, useEffect, createContext, useContext, useRef } from 'react';
import { AlertCircle, CheckCircle2, Info, XCircle, Loader2, X, Camera, UploadCloud } from 'lucide-react';

const ThemeContext = createContext<{ isDark: boolean; toggleTheme: () => void }>({ isDark: false, toggleTheme: () => {} });
export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDark, setIsDark] = useState(() => localStorage.getItem('gira_theme') === 'dark');
  
  useEffect(() => {
    if (isDark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('gira_theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme: () => setIsDark(!isDark) }}>
      {children}
    </ThemeContext.Provider>
  );
};

let toastFn: (msg: string, type: 'success' | 'error' | 'info') => void;
export const useToast = () => ({
  success: (m: string) => toastFn?.(m, 'success'),
  error: (m: string) => toastFn?.(m, 'error'),
  info: (m: string) => toastFn?.(m, 'info'),
});

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<{ id: string, msg: string, type: string }[]>([]);

  toastFn = (msg, type) => {
    const id = Math.random().toString(36);
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 5000);
  };

  return (
    <ThemeProvider>
      {children}
      {/* Moved Toasts to TOP RIGHT to avoid overlapping with Bot (bottom-right) or Sidebar (left) */}
      <div className="fixed top-6 right-6 z-[9999] flex flex-col gap-3 pointer-events-none">
        {toasts.map(t => (
          <div key={t.id} className={`pointer-events-auto flex items-center gap-4 px-6 py-4 rounded-2xl shadow-2xl animate-in slide-in-from-right-10 duration-200 glass border-l-4 ${t.type === 'success' ? 'border-l-emerald-500' : t.type === 'error' ? 'border-l-rose-500' : 'border-l-indigo-500'}`}>
            <div className={`p-2 rounded-xl ${t.type === 'success' ? 'bg-emerald-500/10 text-emerald-500' : t.type === 'error' ? 'bg-rose-500/10 text-rose-500' : 'bg-indigo-500/10 text-indigo-500'}`}>
                {t.type === 'success' ? <CheckCircle2 size={18} /> : t.type === 'error' ? <XCircle size={18} /> : <Info size={18} />}
            </div>
            <p className="text-sm font-bold tracking-tight">{t.msg}</p>
            <button onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))} className="ml-4 p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-premium"><X size={14} /></button>
          </div>
        ))}
      </div>
    </ThemeProvider>
  );
};

export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline', loading?: boolean }> = ({ children, className = '', variant = 'primary', loading, disabled, ...props }) => {
  const variants = {
    primary: 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg premium-shadow-indigo',
    secondary: 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700',
    danger: 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-500/20',
    ghost: 'bg-transparent hover:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400',
    outline: 'border-2 border-slate-200 dark:border-slate-700 bg-transparent hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400'
  };

  return (
    <button 
      disabled={loading || disabled}
      className={`px-6 py-3 rounded-2xl font-bold text-sm transition-premium active:scale-95 disabled:opacity-50 disabled:grayscale flex items-center justify-center gap-2 focus:ring-4 focus:ring-indigo-500/20 focus:outline-none ${variants[variant]} ${className}`} 
      {...props}
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : children}
    </button>
  );
};

export const Card: React.FC<{ children: React.ReactNode; className?: string; title?: string; subtitle?: string; action?: React.ReactNode; glass?: boolean; onClick?: () => void }> = ({ children, className = '', title, subtitle, action, glass = true, onClick }) => (
  <div 
    onClick={onClick}
    className={`rounded-[24px] overflow-hidden transition-premium group border ${glass ? 'glass' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'} ${onClick ? 'cursor-pointer' : ''} ${className}`}
  >
    {(title || action) && (
      <div className="px-8 py-5 border-b border-slate-200/40 dark:border-slate-700/30 flex items-center justify-between">
        <div className="min-w-0">
          {title && <h3 className="text-lg font-black text-slate-800 dark:text-white truncate tracking-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{title}</h3>}
          {subtitle && <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 mt-0.5 uppercase tracking-widest">{subtitle}</p>}
        </div>
        {action && <div className="shrink-0 ml-4">{action}</div>}
      </div>
    )}
    <div className="p-8">
      {children}
    </div>
  </div>
);

export const Input: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label?: string; error?: string; help?: string; icon?: React.ReactNode }> = ({ label, error, help, icon, className = '', ...props }) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.2em] ml-1">{label}</label>}
    <div className="relative group">
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-premium pointer-events-none">
            {icon}
          </div>
        )}
        <input 
            className={`w-full ${icon ? 'pl-11' : 'px-5'} py-3.5 rounded-2xl border-2 bg-slate-50 dark:bg-slate-800/50 text-sm font-medium focus:outline-none focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-premium placeholder:text-slate-300 dark:placeholder:text-slate-600 ${error ? 'border-rose-500' : 'border-transparent'} ${className}`} 
            {...props} 
        />
    </div>
    {error && <span className="text-[10px] text-rose-500 font-bold ml-1 flex items-center gap-1"><AlertCircle size={10} /> {error}</span>}
  </div>
);

export const Badge: React.FC<{ 
  children: React.ReactNode; 
  color?: 'indigo' | 'slate' | 'rose' | 'emerald' | 'amber' | 'violet' | 'pink' | 'teal' | 'blue' | 'sky' | 'cyan' | 'fuchsia'; 
  className?: string;
}> = ({ children, color = 'indigo', className = '' }) => {
  const colors: Record<string, string> = {
    indigo: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20',
    slate: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20',
    rose: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20',
    violet: 'bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20',
    pink: 'bg-pink-500/10 text-pink-600 dark:text-pink-400 border-pink-500/20',
    teal: 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/20',
    blue: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
    sky: 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/20',
    cyan: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 border-cyan-500/20',
    fuchsia: 'bg-fuchsia-500/10 text-fuchsia-600 dark:text-fuchsia-400 border-fuchsia-500/20',
  };
  return (
    <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest border backdrop-blur-md ${colors[color] || colors.indigo} ${className}`}>
      {children}
    </span>
  );
};

export const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' }> = ({ isOpen, onClose, title, children, size = 'md' }) => {
  if (!isOpen) return null;
  const sizes = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-xl', xl: 'max-w-4xl', '2xl': 'max-w-6xl' };
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200" onClick={onClose} />
      <div className={`relative bg-white/95 dark:bg-slate-900/95 w-full ${sizes[size]} rounded-[32px] shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden flex flex-col max-h-[90vh] border border-white/20 dark:border-slate-800`}>
        <div className="px-8 py-6 border-b border-slate-200/50 dark:border-slate-800 flex items-center justify-between shrink-0">
          <h3 className="text-xl font-black text-slate-800 dark:text-white tracking-tight">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-premium text-slate-400 hover:rotate-90">
            <X size={20} />
          </button>
        </div>
        <div className="p-8 overflow-y-auto">
          {children}
        </div>
      </div>
    </div>
  );
};

export const FileUpload: React.FC<{ label: string; value?: string; onChange: (base64: string) => void }> = ({ label, value, onChange }) => {
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => onChange(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div 
      className={`relative w-full aspect-video rounded-[24px] border-2 border-dashed transition-premium flex flex-col items-center justify-center p-6 cursor-pointer group overflow-hidden ${dragActive ? 'border-indigo-500 bg-indigo-500/5' : value ? 'border-indigo-200' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400'}`}
      onDragEnter={() => setDragActive(true)}
      onDragLeave={() => setDragActive(false)}
      onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
      onDrop={(e) => { e.preventDefault(); setDragActive(false); if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]); }}
      onClick={() => inputRef.current?.click()}
    >
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files && handleFile(e.target.files[0])} />
      {value ? (
        <div className="absolute inset-0">
          <img src={value} alt="Preview" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-premium flex items-center justify-center text-white font-bold text-xs uppercase tracking-widest"><UploadCloud className="mr-2" size={20}/> Trocar Imagem</div>
        </div>
      ) : (
        <>
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-4 transition-premium group-hover:scale-110 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/30 group-hover:text-indigo-600"><Camera size={24} /></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
        </>
      )}
    </div>
  );
};

export const ConfirmDialog: React.FC<{ isOpen: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string; type?: 'danger' | 'warning' }> = ({ isOpen, onClose, onConfirm, title, message, type = 'danger' }) => (
  <Modal isOpen={isOpen} onClose={onClose} title={title} size="sm">
    <div className="text-center">
       <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 ${type === 'danger' ? 'bg-rose-500/10 text-rose-500' : 'bg-amber-500/10 text-amber-500'}`}>
          <AlertCircle size={32} />
       </div>
       <p className="text-slate-600 dark:text-slate-400 text-sm font-bold mb-8">{message}</p>
       <div className="flex gap-3">
          <Button variant="outline" className="flex-1" onClick={onClose}>Cancelar</Button>
          <Button variant={type === 'danger' ? 'danger' : 'primary'} className="flex-1" onClick={() => { onConfirm(); onClose(); }}>Confirmar</Button>
       </div>
    </div>
  </Modal>
);

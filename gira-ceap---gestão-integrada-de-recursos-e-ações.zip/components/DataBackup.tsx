
import React, { useState, useRef } from 'react';
import { Card, Button, Modal, Input, Badge, useToast } from './UI';
import { Database, Download, UploadCloud, AlertTriangle, FileJson, CheckCircle2, RefreshCw, ShieldAlert, History } from 'lucide-react';
import { BackupService, BackupData } from '../services/BackupService';

export const DataBackup: React.FC = () => {
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [pendingBackup, setPendingBackup] = useState<BackupData | null>(null);
  const [isRestoreModalOpen, setIsRestoreModalOpen] = useState(false);
  const [confirmationText, setConfirmationText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDownload = () => {
    try {
      BackupService.exportAllData();
      toast.success('Snapshot institucional gerado com sucesso.');
    } catch (e) {
      toast.error('Erro na exportação neural.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const analyzed = BackupService.analyzeBackup(content);
      
      if (analyzed) {
        setPendingBackup(analyzed);
        setIsRestoreModalOpen(true);
      } else {
        toast.error('Arquivo incompatível ou corrompido. Use apenas backups oficiais GIRA.');
      }
    };
    reader.readAsText(file);
    // Limpa o input para permitir selecionar o mesmo arquivo novamente
    e.target.value = '';
  };

  const executeRestore = async () => {
    if (confirmationText !== 'CONFIRMAR') {
      toast.error('Assinatura de confirmação inválida.');
      return;
    }

    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 2000));

    if (pendingBackup) {
      BackupService.restoreData(pendingBackup);
      toast.success('Matriz de dados restaurada. Reiniciando núcleo...');
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    }
  };

  const getSummary = () => {
    if (!pendingBackup) return null;
    const c = pendingBackup.metadata.recordsCount;
    return (
      <div className="grid grid-cols-2 gap-4 mt-6">
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Identidade</p>
          <p className="text-sm font-black dark:text-white">{c.gira_users_v2 || 0} Usuários</p>
        </div>
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Cadeia Social</p>
          <p className="text-sm font-black dark:text-white">{c.gira_projects_v2 || 0} Projetos</p>
        </div>
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Vínculos CRM</p>
          <p className="text-sm font-black dark:text-white">{c.gira_crm_beneficiaries_v1 || 0} Beneficiários</p>
        </div>
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800">
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Logs</p>
          <p className="text-sm font-black dark:text-white">{c.gira_audit_v2 || 0} Eventos</p>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <div className="p-6 rounded-[32px] bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-500/20 flex gap-6 items-start">
         <ShieldAlert className="text-indigo-600 shrink-0 mt-1" size={24} />
         <div className="space-y-2">
            <h4 className="text-sm font-black text-indigo-800 dark:text-indigo-400 uppercase tracking-widest">Atenção: Protocolo de Segurança Local</h4>
            <p className="text-xs text-indigo-700 dark:text-indigo-300/70 leading-relaxed font-medium">
               Como o GIRA opera em modo <strong>Single Source (LocalStorage)</strong>, o backup é sua única garantia de imutabilidade. Salve o arquivo JSON em um local seguro após grandes alterações operacionais.
            </p>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card title="Extrair Snapshot" subtitle="Exportação Imutável de Dados">
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-10 font-medium">
            Gera um arquivo consolidado contendo toda a inteligência, materiais e cadastros do CEAP.
          </p>
          <Button onClick={handleDownload} className="w-full h-16 rounded-[24px] gap-3 text-sm font-black uppercase tracking-widest">
            <Download size={20} /> Baixar Snapshot .json
          </Button>
          <div className="mt-6 flex items-center justify-center gap-2 text-emerald-500">
            <CheckCircle2 size={12} />
            <p className="text-[9px] uppercase font-black tracking-[0.2em]">Criptografia Serial Ativa</p>
          </div>
        </Card>

        <Card title="Restauração Neural" subtitle="Recuperação de Nodo em Crise">
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-10 font-medium">
            Sobrescreve a base local com os dados de um arquivo de backup. <span className="text-rose-500 font-bold">Operação destrutiva e irreversível.</span>
          </p>
          
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json"
            className="hidden"
          />
          
          <Button 
            variant="outline" 
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-16 rounded-[24px] gap-3 text-sm font-black uppercase tracking-widest border-indigo-500/20 text-indigo-600"
          >
            <UploadCloud size={20} /> Carregar Matriz de Dados
          </Button>

          <div className="mt-6 flex items-center justify-center gap-2 text-slate-400">
            <History size={12} />
            <p className="text-[9px] uppercase font-black tracking-[0.2em]">Último Snapshot Aceito: v5.2</p>
          </div>
        </Card>
      </div>

      <Modal 
        isOpen={isRestoreModalOpen} 
        onClose={() => !isProcessing && setIsRestoreModalOpen(false)} 
        title="Validar Substituição de Base"
        size="lg"
      >
        <div className="space-y-8">
          <div className="p-8 bg-rose-50 dark:bg-rose-900/20 rounded-[40px] border border-rose-200 dark:border-rose-800 flex gap-6 items-center">
            <AlertTriangle className="text-rose-600 shrink-0" size={40} />
            <div className="space-y-1">
              <h4 className="text-lg font-black text-rose-800 dark:text-rose-400 uppercase tracking-tighter">Risco de Perda Total</h4>
              <p className="text-xs font-bold text-rose-700 dark:text-rose-400/70 leading-relaxed uppercase">
                Esta ação apagará instantaneamente o estado atual do GIRA no seu navegador e o substituirá pelo backup abaixo.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest ml-1 flex items-center gap-2"><Database size={12}/> Metadados do Snapshot Carregado</h4>
            <div className="p-8 glass rounded-[40px] border border-white/20">
               <div className="flex justify-between items-center pb-6 border-b border-slate-100 dark:border-slate-800">
                 <div>
                    <Badge color="indigo">GIRA CORE {pendingBackup?.metadata.version}</Badge>
                    <p className="text-[10px] font-black text-slate-400 mt-2 uppercase tracking-widest">Checksum ID: {pendingBackup?.metadata.checksum}</p>
                 </div>
                 <div className="text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Data de Geração</p>
                    <span className="text-sm font-black dark:text-white">{new Date(pendingBackup?.metadata.timestamp || '').toLocaleString('pt-BR')}</span>
                 </div>
               </div>
               {getSummary()}
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[11px] font-black text-slate-600 dark:text-slate-400 uppercase tracking-widest ml-1">Para confirmar a destruição dos dados atuais e restauração da matriz, digite <span className="text-indigo-600">CONFIRMAR</span>:</label>
            <Input 
              value={confirmationText}
              onChange={e => setConfirmationText(e.target.value.toUpperCase())}
              placeholder="Digite aqui..."
              className="py-5 px-8 rounded-3xl border-2 focus:border-indigo-600 shadow-inner"
              disabled={isProcessing}
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button 
              variant="outline" 
              className="flex-1 h-16 rounded-[28px]" 
              onClick={() => setIsRestoreModalOpen(false)}
              disabled={isProcessing}
            >
              Abortar Operação
            </Button>
            <Button 
              variant="danger" 
              className="flex-1 h-16 rounded-[28px] gap-3 font-black uppercase tracking-widest shadow-xl shadow-rose-500/20" 
              onClick={executeRestore}
              loading={isProcessing}
              disabled={confirmationText !== 'CONFIRMAR' || isProcessing}
            >
              {isProcessing ? 'Sincronizando Matriz...' : <><RefreshCw size={18}/> Executar Restauração</>}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};


import React, { useState, useEffect, useMemo } from 'react';
import { Card, Button, Badge, Modal, Input, useToast, ConfirmDialog } from './UI';
import { ShoppingCart, FileText, CheckCircle, Clock, Truck, Plus, ArrowRight, Printer, Mail, Trash2, PlusCircle, Gavel, ShieldAlert, PackageSearch, Info, UserCheck, AlertTriangle, ChevronRight, User, RefreshCcw, Building2, MapPin, Phone, Search, Users, ArrowRightLeft, Package, Star, BarChart3, Download, DollarSign, Trophy, Timer, Loader2, Calculator, ClipboardList, Handshake, Box } from 'lucide-react';
import { PurchaseRequest, Quote, PurchaseOrder, Supplier, Material, Project, CostCenter, Client, Movement, FinanceTransaction, Batch, InventoryCount, SupplyContract } from '../types';
import { useAuth } from '../context/AuthContext';
import { AuditService } from '../services/AuditService';
import { FirestoreService } from '../services/FirestoreService';
import { pdfService } from '../services/pdfService';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Legend, LineChart, Line
} from 'recharts';

// --- MOVIMENTAÇÃO DE ESTOQUE (MIGO) ---
export const MovimentacaoEstoque: React.FC<{ materials: Material[], onUpdate: () => void }> = ({ materials, onUpdate }) => {
  const toast = useToast();
  const { currentUser } = useAuth();
  const [movementType, setMovementType] = useState<'IN' | 'OUT'>('OUT');
  
  // Cart for MIGO
  const [cart, setCart] = useState<{ 
    materialId: string, 
    quantity: number,
    // Fields for IN
    batchNumber?: string,
    expiryDate?: string,
    location?: string,
    unitPrice?: number // For Average Cost calculation
  }[]>([]);
  
  const [obs, setObs] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [recentLogs, setRecentLogs] = useState<any[]>([]);

  useEffect(() => {
    const loadLogs = async () => {
      const logs = await FirestoreService.getAll<any>('auditLogs');
      const supplyLogs = logs
        .filter(l => l.module === 'SUPPLIES' && (l.action === 'STOCK_ENTRY' || l.action === 'STOCK_EXIT'))
        .sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);
      setRecentLogs(supplyLogs);
    };
    loadLogs();
  }, [isSubmitting]);

  const handleAddMovement = async () => {
    if (cart.length === 0) return toast.error('Adicione materiais à lista.');
    setIsSubmitting(true);

    try {
      for (const item of cart) {
        const mat = materials.find(m => m.id === item.materialId);
        if (!mat) continue;

        let newQty = mat.quantity;
        let newAvgCost = mat.averageCost || mat.unitValue;
        let updatedBatches = mat.batches || [];

        if (movementType === 'IN') {
            newQty += item.quantity;
            
            // Calc Average Cost (Moving Weighted Average)
            const inputPrice = item.unitPrice || mat.unitValue;
            if (inputPrice > 0) {
               const oldTotalVal = (mat.quantity * (mat.averageCost || mat.unitValue));
               const newTotalVal = oldTotalVal + (item.quantity * inputPrice);
               newAvgCost = newTotalVal / newQty;
            }

            // Add Batch
            if (item.batchNumber) {
                updatedBatches.push({
                    id: `bat-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
                    batchNumber: item.batchNumber,
                    expiryDate: item.expiryDate || '',
                    quantity: item.quantity,
                    location: item.location || 'Geral',
                    materialId: mat.id
                });
            }
        } else {
            newQty -= item.quantity;
            // Simple FIFO logic or manual batch selection could be added here.
            // For now, we reduce from quantity. In full system, we'd reduce from specific batch.
        }

        if (newQty < 0) {
          toast.error(`Estoque insuficiente para ${mat.name}. Disponível: ${mat.quantity}`);
          continue; 
        }

        await FirestoreService.save('materials', mat.id, { 
            quantity: newQty,
            averageCost: newAvgCost,
            batches: updatedBatches
        });

        await AuditService.log({
          userId: currentUser?.id || 'sys',
          userName: currentUser?.name || 'Sistema',
          action: movementType === 'IN' ? 'STOCK_ENTRY' : 'STOCK_EXIT',
          module: 'SUPPLIES',
          details: `${movementType === 'IN' ? 'Entrada' : 'Saída'} manual de ${item.quantity} ${mat.uomBase} - ${mat.name}. ${item.batchNumber ? `Lote: ${item.batchNumber}` : ''} Motivo: ${obs}`,
          criticality: movementType === 'OUT' ? 'WARN' : 'INFO'
        });
      }
      
      toast.success('Movimentação registrada com sucesso.');
      setCart([]);
      setObs('');
      onUpdate();
    } catch (e) {
      console.error(e);
      toast.error('Erro de conexão ao processar movimentos.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in">
       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card title="Lançamento de Movimento (MIGO)">
             <div className="flex gap-4 mb-6">
                <button onClick={() => setMovementType('OUT')} className={`flex-1 py-4 rounded-2xl font-black uppercase text-xs transition-all border-2 ${movementType === 'OUT' ? 'border-rose-500 bg-rose-500 text-white' : 'border-slate-200 text-slate-400'}`}>Saída / Consumo</button>
                <button onClick={() => setMovementType('IN')} className={`flex-1 py-4 rounded-2xl font-black uppercase text-xs transition-all border-2 ${movementType === 'IN' ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-200 text-slate-400'}`}>Entrada / Ajuste</button>
             </div>
             
             <div className="space-y-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-900/50 rounded-2xl border border-slate-100 dark:border-slate-800">
                   <div className="flex justify-between items-center mb-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase">Item de Movimento</label>
                      <button onClick={() => setCart([...cart, { materialId: materials[0]?.id, quantity: 1 }])} className="text-[10px] font-black text-indigo-600 uppercase hover:underline">+ Adicionar Item</button>
                   </div>
                   <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
                      {cart.map((item, idx) => (
                        <div key={idx} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 space-y-3">
                           <div className="flex gap-2">
                               <select className="flex-1 p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-xs font-bold border-none" value={item.materialId} onChange={e => {
                                 const n = [...cart]; n[idx].materialId = e.target.value; setCart(n);
                               }}>
                                  {materials.map(m => <option key={m.id} value={m.id}>{m.sku} - {m.name} (Saldo: {m.quantity})</option>)}
                               </select>
                               <input type="number" placeholder="Qtd" className="w-20 p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-xs font-bold border-none" value={item.quantity} onChange={e => {
                                 const n = [...cart]; n[idx].quantity = Number(e.target.value); setCart(n);
                               }} />
                               <button onClick={() => setCart(cart.filter((_, i) => i !== idx))} className="p-2 text-rose-500"><Trash2 size={14}/></button>
                           </div>
                           
                           {movementType === 'IN' && (
                               <div className="grid grid-cols-2 gap-2">
                                   <input type="text" placeholder="Lote (Opcional)" className="p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-[10px] font-bold border-none" value={item.batchNumber || ''} onChange={e => {
                                       const n = [...cart]; n[idx].batchNumber = e.target.value; setCart(n);
                                   }} />
                                   <input type="date" className="p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-[10px] font-bold border-none" value={item.expiryDate || ''} onChange={e => {
                                       const n = [...cart]; n[idx].expiryDate = e.target.value; setCart(n);
                                   }} />
                                   <input type="text" placeholder="Local (Ex: Almox. A)" className="p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-[10px] font-bold border-none" value={item.location || ''} onChange={e => {
                                       const n = [...cart]; n[idx].location = e.target.value; setCart(n);
                                   }} />
                                   <input type="number" placeholder="Custo Unit. (R$)" className="p-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-[10px] font-bold border-none" value={item.unitPrice || ''} onChange={e => {
                                       const n = [...cart]; n[idx].unitPrice = Number(e.target.value); setCart(n);
                                   }} />
                               </div>
                           )}
                        </div>
                      ))}
                      {cart.length === 0 && <p className="text-center text-xs text-slate-300 py-4">Nenhum item na lista de movimento.</p>}
                   </div>
                </div>
                <Input label="Histórico / Motivo" value={obs} onChange={e => setObs(e.target.value)} placeholder="Ex: Consumo para evento X ou Ajuste de inventário" />
                <Button onClick={handleAddMovement} loading={isSubmitting} className="w-full h-12 bg-slate-800 text-white font-black uppercase">Processar Movimento</Button>
             </div>
          </Card>

          <Card title="Últimas Movimentações (Audit Cloud)" className="glass h-[500px] overflow-hidden flex flex-col">
             <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3">
                {recentLogs.map(log => (
                  <div key={log.id} className="p-4 rounded-2xl bg-white/50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 flex items-start gap-4">
                     <div className={`p-2 rounded-xl ${log.action === 'STOCK_ENTRY' ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                        <Package size={16} />
                     </div>
                     <div>
                        <p className="text-xs font-black dark:text-white">{log.details}</p>
                        <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold">{new Date(log.timestamp).toLocaleString()} • {log.userName}</p>
                     </div>
                  </div>
                ))}
                {recentLogs.length === 0 && <p className="text-center text-xs text-slate-400 mt-10">Nenhum registro recente.</p>}
             </div>
          </Card>
       </div>
    </div>
  );
};

// --- MRP (PLANEJAMENTO DE MATERIAIS) ---
export const PlanejamentoMRP: React.FC = () => {
    const [materials, setMaterials] = useState<Material[]>([]);
    const [orders, setOrders] = useState<PurchaseOrder[]>([]);
    const [suggestions, setSuggestions] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const load = async () => {
            const [mats, ords] = await Promise.all([
                FirestoreService.getAll<Material>('materials'),
                FirestoreService.getAll<PurchaseOrder>('purchase_orders')
            ]);
            setMaterials(mats);
            setOrders(ords);
            setLoading(false);
        };
        load();
    }, []);

    useEffect(() => {
        if (loading) return;
        
        const openOrdersMap = new Map<string, number>();
        orders.filter(o => o.status === 'ORDERED').forEach(o => {
            o.items.forEach((item: any) => {
                const curr = openOrdersMap.get(item.materialId) || 0;
                openOrdersMap.set(item.materialId, curr + item.quantityRequested);
            });
        });

        const newSuggestions = materials.map(m => {
            const onOrder = openOrdersMap.get(m.id) || 0;
            const available = m.quantity + onOrder;
            const need = m.minQuantity - available;
            
            if (need > 0) {
                return {
                    material: m,
                    onOrder,
                    need,
                    cost: need * (m.averageCost || m.unitValue)
                };
            }
            return null;
        }).filter(Boolean);

        setSuggestions(newSuggestions);
    }, [materials, orders, loading]);

    if (loading) return <div className="p-20 flex justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>;

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Planejamento de Necessidades (MRP)</h3>
                <Badge color="indigo">{suggestions.length} Sugestões de Compra</Badge>
            </div>

            <Card className="p-0 glass border-none overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-50 dark:bg-slate-900/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
                        <tr>
                            <th className="p-6">Material</th>
                            <th className="p-6 text-center">Estoque Atual</th>
                            <th className="p-6 text-center">Em Pedido</th>
                            <th className="p-6 text-center">Ponto de Pedido</th>
                            <th className="p-6 text-right text-indigo-600">Sugestão de Compra</th>
                            <th className="p-6 text-right">Impacto Financeiro</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {suggestions.map((s: any) => (
                            <tr key={s.material.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                <td className="p-6">
                                    <p className="text-sm font-bold dark:text-white">{s.material.name}</p>
                                    <p className="text-[9px] text-slate-400 uppercase tracking-widest">{s.material.sku}</p>
                                </td>
                                <td className="p-6 text-center font-bold text-slate-600 dark:text-slate-400">{s.material.quantity}</td>
                                <td className="p-6 text-center font-bold text-indigo-500">{s.onOrder}</td>
                                <td className="p-6 text-center font-bold text-rose-500">{s.material.minQuantity}</td>
                                <td className="p-6 text-right">
                                    <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-lg text-xs font-black">{s.need} {s.material.uomBase}</span>
                                </td>
                                <td className="p-6 text-right font-black text-slate-700 dark:text-white">R$ {s.cost.toLocaleString()}</td>
                            </tr>
                        ))}
                        {suggestions.length === 0 && (
                            <tr><td colSpan={6} className="p-10 text-center text-xs text-slate-400 uppercase font-bold">Nenhuma necessidade de compra detectada no momento.</td></tr>
                        )}
                    </tbody>
                </table>
            </Card>
        </div>
    );
};

// --- GESTÃO DE INVENTÁRIO (CICLICO) ---
export const GestaoInventario: React.FC = () => {
    const toast = useToast();
    const { currentUser } = useAuth();
    const [counts, setCounts] = useState<InventoryCount[]>([]);
    const [materials, setMaterials] = useState<Material[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedCount, setSelectedCount] = useState<InventoryCount | null>(null);
    const [countData, setCountData] = useState<Record<string, number>>({});

    const refresh = async () => {
        const [cts, mats] = await Promise.all([
            FirestoreService.getAll<InventoryCount>('inventory_counts'),
            FirestoreService.getAll<Material>('materials')
        ]);
        setCounts(cts);
        setMaterials(mats);
    };

    useEffect(() => { refresh(); }, []);

    const handleCreateCount = async () => {
        // Simple Logic: Random 5 items for cyclic count
        const shuffled = materials.sort(() => 0.5 - Math.random()).slice(0, 5);
        const newCount: InventoryCount = {
            id: `INV-${Date.now()}`,
            date: new Date().toISOString(),
            status: 'OPEN',
            responsible: currentUser?.name || 'Sistema',
            createdAt: new Date().toISOString(),
            items: shuffled.map(m => ({
                materialId: m.id,
                materialName: m.name,
                systemQty: m.quantity,
                countedQty: 0,
                divergence: 0
            }))
        };
        await FirestoreService.save('inventory_counts', newCount.id, newCount);
        refresh();
        toast.success('Nova sessão de contagem cíclica criada.');
    };

    const handleFinalizeCount = async () => {
        if (!selectedCount) return;
        
        // 1. Update Inventory Count Document
        const updatedItems = selectedCount.items.map(item => ({
            ...item,
            countedQty: countData[item.materialId] || 0,
            divergence: (countData[item.materialId] || 0) - item.systemQty
        }));
        
        await FirestoreService.save('inventory_counts', selectedCount.id, {
            items: updatedItems,
            status: 'CLOSED'
        });

        // 2. Adjust Stock (MIGO)
        for (const item of updatedItems) {
            if (item.divergence !== 0) {
                const mat = materials.find(m => m.id === item.materialId);
                if (mat) {
                    await FirestoreService.save('materials', mat.id, { quantity: item.countedQty });
                    // Log adjustment
                    await AuditService.log({
                        userId: currentUser?.id || 'sys',
                        userName: currentUser?.name || 'Sistema',
                        action: item.divergence > 0 ? 'STOCK_ENTRY' : 'STOCK_EXIT',
                        module: 'INVENTORY',
                        details: `Ajuste de Inventário ${selectedCount.id}: ${item.divergence > 0 ? '+' : ''}${item.divergence} para ${mat.name}`,
                        criticality: 'WARN'
                    });
                }
            }
        }

        toast.success('Inventário finalizado e estoques ajustados.');
        setIsModalOpen(false);
        refresh();
    };

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Inventário Rotativo (Cíclico)</h3>
                <Button onClick={handleCreateCount} className="bg-orange-600 gap-2"><Calculator size={18}/> Gerar Sessão de Contagem</Button>
            </div>

            <div className="grid grid-cols-1 gap-4">
                {counts.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(count => (
                    <Card key={count.id} className="glass flex justify-between items-center p-6 group hover:border-orange-500 transition-all">
                        <div className="flex items-center gap-6">
                            <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 text-orange-600 rounded-2xl flex items-center justify-center font-black">
                                <ClipboardList size={24}/>
                            </div>
                            <div>
                                <h4 className="text-lg font-black dark:text-white">{count.id}</h4>
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{new Date(count.date).toLocaleDateString()} • {count.items.length} Itens • Resp: {count.responsible}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <Badge color={count.status === 'OPEN' ? 'amber' : 'emerald'}>{count.status === 'OPEN' ? 'EM CONTAGEM' : 'FINALIZADO'}</Badge>
                            {count.status === 'OPEN' && (
                                <Button onClick={() => { setSelectedCount(count); setIsModalOpen(true); setCountData({}); }} variant="outline" className="h-10 text-[10px] font-black uppercase">Realizar Contagem</Button>
                            )}
                        </div>
                    </Card>
                ))}
            </div>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Execução de Contagem Física" size="lg">
                <div className="space-y-6">
                    {selectedCount?.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800">
                            <div>
                                <p className="font-black text-sm dark:text-white">{item.materialName}</p>
                                <p className="text-[10px] text-slate-400 uppercase">Sistema: {item.systemQty}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-slate-500 uppercase">Contagem:</span>
                                <input 
                                    type="number" 
                                    className="w-24 p-2 rounded-lg text-right font-black border-2 border-indigo-100 focus:border-indigo-500 outline-none" 
                                    onChange={(e) => setCountData({...countData, [item.materialId]: Number(e.target.value)})}
                                />
                            </div>
                        </div>
                    ))}
                    <div className="flex justify-end gap-4 pt-4">
                        <Button variant="outline" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
                        <Button onClick={handleFinalizeCount} className="bg-emerald-600 hover:bg-emerald-700">Finalizar e Ajustar Estoque</Button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

// --- CONTRATOS DE FORNECIMENTO ---
export const ContratosTab: React.FC = () => {
    const toast = useToast();
    const [contracts, setContracts] = useState<SupplyContract[]>([]);
    const [suppliers, setSuppliers] = useState<Supplier[]>([]);
    const [materials, setMaterials] = useState<Material[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const refresh = async () => {
        const [cts, sups, mats] = await Promise.all([
            FirestoreService.getAll<SupplyContract>('supply_contracts'),
            FirestoreService.getAll<Supplier>('suppliers'),
            FirestoreService.getAll<Material>('materials')
        ]);
        setContracts(cts);
        setSuppliers(sups);
        setMaterials(mats);
    };

    useEffect(() => { refresh(); }, []);

    const handleSaveContract = async (e: React.FormEvent) => {
        e.preventDefault();
        const f = new FormData(e.target as HTMLFormElement);
        const supplierId = f.get('supplierId') as string;
        const materialId = f.get('materialId') as string;
        
        const newContract: SupplyContract = {
            id: `CTR-${Date.now()}`,
            supplierId,
            supplierName: suppliers.find(s => s.id === supplierId)?.tradeName || '',
            materialId,
            materialName: materials.find(m => m.id === materialId)?.name || '',
            fixedPrice: Number(f.get('price')),
            validityStart: f.get('start') as string,
            validityEnd: f.get('end') as string,
            slaDays: Number(f.get('sla')),
            active: true
        };

        await FirestoreService.save('supply_contracts', newContract.id, newContract);
        refresh();
        setIsModalOpen(false);
        toast.success('Contrato de fornecimento registrado.');
    };

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Contratos de Fornecimento (SLA & Preço Fixo)</h3>
                <Button onClick={() => setIsModalOpen(true)} className="bg-indigo-600 gap-2"><Plus size={18}/> Novo Contrato</Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {contracts.map(c => (
                    <Card key={c.id} className="glass border-l-4 border-l-indigo-500">
                        <div className="flex justify-between items-start">
                            <div>
                                <div className="flex items-center gap-2 mb-1">
                                    <Handshake size={16} className="text-indigo-600"/>
                                    <h4 className="font-black text-sm dark:text-white uppercase tracking-widest">{c.supplierName}</h4>
                                </div>
                                <p className="text-xs font-bold text-slate-500">{c.materialName}</p>
                            </div>
                            <Badge color={c.active ? 'emerald' : 'rose'}>{c.active ? 'VIGENTE' : 'EXPIRADO'}</Badge>
                        </div>
                        <div className="mt-6 grid grid-cols-2 gap-4">
                            <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                                <p className="text-[9px] font-black text-slate-400 uppercase">Preço Acordado</p>
                                <p className="text-lg font-black text-indigo-600">R$ {c.fixedPrice.toLocaleString()}</p>
                            </div>
                            <div className="p-3 bg-slate-50 dark:bg-slate-900 rounded-xl">
                                <p className="text-[9px] font-black text-slate-400 uppercase">SLA Entrega</p>
                                <p className="text-lg font-black text-slate-700 dark:text-slate-300">{c.slaDays} dias</p>
                            </div>
                        </div>
                        <p className="text-[9px] text-slate-400 font-bold uppercase mt-4 tracking-widest text-right">Válido até: {new Date(c.validityEnd).toLocaleDateString()}</p>
                    </Card>
                ))}
            </div>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Contrato de Fornecimento">
                <form onSubmit={handleSaveContract} className="space-y-6">
                    <div className="space-y-1">
                        <label className="text-[10px] font-black uppercase text-slate-400">Fornecedor</label>
                        <select name="supplierId" className="w-full p-3 rounded-xl glass border-none text-sm font-bold">
                            {suppliers.map(s => <option key={s.id} value={s.id}>{s.tradeName}</option>)}
                        </select>
                    </div>
                    <div className="space-y-1">
                        <label className="text-[10px] font-black uppercase text-slate-400">Material</label>
                        <select name="materialId" className="w-full p-3 rounded-xl glass border-none text-sm font-bold">
                            {materials.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                        </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <Input label="Preço Fixo (R$)" name="price" type="number" step="0.01" required />
                        <Input label="SLA Entrega (Dias)" name="sla" type="number" required />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <Input label="Início Vigência" name="start" type="date" required />
                        <Input label="Fim Vigência" name="end" type="date" required />
                    </div>
                    <Button type="submit" className="w-full bg-indigo-600">Registrar Contrato</Button>
                </form>
            </Modal>
        </div>
    );
};

// --- RELATÓRIOS (MB51) ---
export const RelatoriosSuprimentos: React.FC = () => {
  const [materials, setMaterials] = useState<Material[]>([]);
  const [orders, setOrders] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
        try {
            const [mats, ords] = await Promise.all([
                FirestoreService.getAll<Material>('materials'),
                FirestoreService.getAll<PurchaseOrder>('purchase_orders')
            ]);
            setMaterials(mats);
            setOrders(ords);
        } finally {
            setLoading(false);
        }
    };
    fetchData();
  }, []);

  // Dados para Gráfico de Spend por Fornecedor
  const spendBySupplier = useMemo(() => {
    const map = new Map<string, number>();
    orders.forEach(o => {
      const current = map.get(o.supplierName) || 0;
      map.set(o.supplierName, current + o.totalValue);
    });
    return Array.from(map.entries()).map(([name, value]) => ({ name, value })).slice(0, 5);
  }, [orders]);

  // Dados para ABC
  const abcData = useMemo(() => {
    return [
      { name: 'Classe A', value: materials.filter(m => m.abcClass === 'A').length },
      { name: 'Classe B', value: materials.filter(m => m.abcClass === 'B').length },
      { name: 'Classe C', value: materials.filter(m => m.abcClass === 'C').length },
    ];
  }, [materials]);

  if (loading) return <div className="p-10 flex justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>;

  return (
    <div className="space-y-8 animate-in fade-in">
       <div className="flex justify-between items-center">
          <h3 className="text-2xl font-black dark:text-white">Inteligência de Suprimentos</h3>
          <Button variant="outline" className="gap-2 border-orange-500/20 text-orange-600"><Download size={18}/> Exportar Dados</Button>
       </div>

       <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card title="Top 5 Fornecedores (Spend)" subtitle="Volume Financeiro Acumulado">
             <div className="h-[300px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={spendBySupplier} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} strokeOpacity={0.1} />
                      <XAxis type="number" hide />
                      <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 10, fontWeight: 700}} />
                      <Tooltip formatter={(value) => `R$ ${Number(value).toLocaleString()}`} />
                      <Bar dataKey="value" fill="#f97316" radius={[0, 4, 4, 0]} barSize={20} />
                   </BarChart>
                </ResponsiveContainer>
             </div>
          </Card>

          <Card title="Distribuição ABC de Estoque" subtitle="Concentração de Valor">
             <div className="h-[300px] mt-4">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={abcData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} strokeOpacity={0.1} />
                      <XAxis dataKey="name" tick={{fontSize: 12, fontWeight: 700}} axisLine={false} tickLine={false} />
                      <YAxis allowDecimals={false} axisLine={false} tickLine={false} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} barSize={40} />
                   </BarChart>
                </ResponsiveContainer>
             </div>
          </Card>
       </div>
    </div>
  );
};

export const RequisicoesTab: React.FC = () => {
  const toast = useToast();
  const { currentUser } = useAuth();
  const [requests, setRequests] = useState<PurchaseRequest[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [costCenters, setCostCenters] = useState<CostCenter[]>([]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cart, setCart] = useState<{ materialId: string; quantity: number }[]>([]);

  const refresh = async () => {
    const [reqs, mats, projs, ccs] = await Promise.all([
        FirestoreService.getAll<PurchaseRequest>('purchase_requests'),
        FirestoreService.getAll<Material>('materials'),
        FirestoreService.getAll<Project>('projects'),
        FirestoreService.getAll<CostCenter>('cost_centers')
    ]);
    setRequests(reqs);
    setMaterials(mats);
    setProjects(projs);
    setCostCenters(ccs);
  };

  useEffect(() => { refresh(); }, []);

  const totalValue = useMemo(() => {
    return cart.reduce((acc, item) => {
      const mat = materials.find(m => m.id === item.materialId);
      return acc + (item.quantity * (mat?.unitValue || 0));
    }, 0);
  }, [cart, materials]);

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return toast.error('O carrinho está vazio.');
    setIsSubmitting(true);
    const f = new FormData(e.target as HTMLFormElement);
    
    const projectId = f.get('projectId') as string;
    const projName = projects.find(p => p.id === projectId)?.name;

    const newReq: PurchaseRequest = {
      id: `REQ-${Date.now()}`,
      items: cart.map(item => {
        const mat = materials.find(m => m.id === item.materialId);
        return {
          materialId: item.materialId,
          materialName: mat?.name || '',
          quantity: item.quantity,
          unitValue: mat?.unitValue || 0,
          total: item.quantity * (mat?.unitValue || 0)
        };
      }),
      projectId,
      projectName: projName,
      costCenter: f.get('costCenter') as string,
      status: 'PENDING_ANALYSIS',
      urgency: f.get('urgency') as any,
      justification: f.get('justification') as string,
      requesterId: currentUser?.id || 'sys',
      requesterName: currentUser?.name || 'Sistema',
      totalValue,
      createdAt: new Date().toISOString(),
      history: [{ user: currentUser?.name || 'Sys', action: 'SUBMIT', date: new Date().toISOString() }]
    };

    try {
        // CORREÇÃO: Passar o ID explícito para o save garantir consistência
        await FirestoreService.save('purchase_requests', newReq.id, newReq);
        await refresh();
        setIsModalOpen(false);
        setCart([]);
        toast.success('Requisição enviada para análise técnica.');
    } catch (e) {
        toast.error('Erro ao salvar requisição.');
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleApprove = async (req: PurchaseRequest) => {
    let nextStatus: PurchaseRequest['status'] = 'APPROVED';
    if (req.totalValue > 500 && req.status === 'PENDING_ANALYSIS') {
      nextStatus = 'PENDING_DIRECTION';
    }
    const updated: PurchaseRequest = {
      ...req,
      status: nextStatus,
      history: [...(req.history || []), { user: currentUser?.name || 'Sys', action: 'APPROVE', date: new Date().toISOString() }]
    };
    await FirestoreService.save('purchase_requests', req.id, updated);
    refresh();
    toast.success(nextStatus === 'APPROVED' ? 'Requisição aprovada e liberada para cotação.' : 'Aprovada pelo analista. Pendente Direção Executiva.');
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black dark:text-white">Fluxo de Requisições (ME51N)</h3>
        <Button onClick={() => setIsModalOpen(true)} className="bg-indigo-600 gap-2"><Plus size={18}/> Nova Requisição</Button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {requests.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(req => (
          <Card key={req.id} className="glass border-white/10 group hover:border-indigo-500/50 transition-all p-8">
            <div className="flex flex-col lg:flex-row justify-between gap-8">
              <div className="flex-1 space-y-4">
                <div className="flex items-center gap-4">
                   <Badge color={req.status === 'APPROVED' ? 'emerald' : req.status === 'REJECTED' ? 'rose' : 'amber'}>{req.status.replace('_', ' ')}</Badge>
                   <Badge color={req.urgency === 'NORMAL' ? 'slate' : 'rose'}>{req.urgency}</Badge>
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{req.id} • {new Date(req.createdAt).toLocaleDateString()}</span>
                </div>
                <h4 className="text-xl font-black dark:text-white">Solicitante: {req.requesterName}</h4>
                <p className="text-sm font-bold text-slate-500 italic">"{req.justification}"</p>
                <div className="flex flex-wrap gap-2">
                   {req.items.map((it, i) => <Badge key={i} color="indigo">{it.materialName} ({it.quantity})</Badge>)}
                </div>
              </div>
              <div className="flex flex-col items-end justify-between min-w-[200px]">
                 <div className="text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Valor Estimado</p>
                    <p className="text-3xl font-black text-indigo-600">R$ {req.totalValue.toLocaleString()}</p>
                 </div>
                 <div className="flex gap-2">
                    {req.status.startsWith('PENDING') && req.requesterId !== currentUser?.id && (
                      <Button variant="primary" onClick={() => handleApprove(req)} className="bg-emerald-600 hover:bg-emerald-700 rounded-xl gap-2"><CheckCircle size={14}/> Aprovar</Button>
                    )}
                 </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Nova Requisição de Material" size="xl">
        <form onSubmit={handleCreateRequest} className="space-y-8">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Centro de Custo</label>
                 <select name="costCenter" required className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                    {costCenters.map(cc => <option key={cc.id} value={cc.name}>{cc.name}</option>)}
                 </select>
              </div>
              <div className="space-y-1">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Vínculo Projeto (Opcional)</label>
                 <select name="projectId" className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                    <option value="">Consumo Institucional</option>
                    {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                 </select>
              </div>
           </div>
           
           <div className="space-y-4">
              <div className="flex justify-between items-center">
                 <h4 className="text-xs font-black uppercase text-indigo-600 tracking-widest">Itens da Requisição</h4>
                 <Button type="button" onClick={() => setCart([...cart, { materialId: materials[0]?.id || '', quantity: 1 }])} variant="outline" className="rounded-full h-8 px-4 text-[9px] uppercase font-black"><Plus size={12}/> Adicionar Item</Button>
              </div>
              <div className="space-y-3 max-h-[250px] overflow-y-auto pr-2 no-scrollbar">
                 {cart.map((item, idx) => (
                   <div key={idx} className="flex gap-4 items-end animate-in slide-in-from-left-2 p-4 glass rounded-2xl border-white/10">
                      <div className="flex-1 space-y-1">
                         <select 
                           value={item.materialId} 
                           onChange={(e) => {
                             const n = [...cart]; n[idx].materialId = e.target.value; setCart(n);
                           }}
                           className="w-full p-3 rounded-xl border-none glass bg-white dark:bg-slate-800 text-sm font-bold shadow-sm"
                         >
                           {materials.map(m => <option key={m.id} value={m.id}>{m.sku} - {m.name} (R$ {m.unitValue})</option>)}
                         </select>
                      </div>
                      <div className="w-24">
                         <Input label="Qtd" type="number" min="1" value={item.quantity} onChange={(e) => {
                           const n = [...cart]; n[idx].quantity = Number(e.target.value); setCart(n);
                         }} />
                      </div>
                      <Button type="button" variant="ghost" onClick={() => setCart(cart.filter((_, i) => i !== idx))} className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl"><Trash2 size={16}/></Button>
                   </div>
                 ))}
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Urgência</label>
                 <select name="urgency" className="w-full p-4 rounded-2xl glass border-none bg-white dark:bg-slate-800 text-sm font-bold shadow-inner">
                    <option value="NORMAL">Normal (SLA 5 dias)</option>
                    <option value="URGENTE">Urgente (SLA 48h)</option>
                    <option value="EMERGENCIAL">Emergencial (Imediato)</option>
                 </select>
              </div>
              <Input label="Justificativa da Necessidade" name="justification" required placeholder="Por que estes itens são necessários?" />
           </div>

           <div className="pt-8 border-t border-white/10 flex justify-between items-center">
              <div className="glass px-8 py-4 rounded-[32px] border-emerald-500/20">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Custo Projetado</p>
                 <p className="text-3xl font-black text-emerald-600">R$ {totalValue.toLocaleString()}</p>
              </div>
              <div className="flex gap-4">
                 <Button type="button" variant="outline" className="px-8 rounded-3xl" onClick={() => setIsModalOpen(false)}>Cancelar</Button>
                 <Button type="submit" loading={isSubmitting} className="px-12 bg-indigo-600 shadow-xl shadow-indigo-500/20">Enviar Requisição</Button>
              </div>
           </div>
        </form>
      </Modal>
    </div>
  );
};

// --- COTAÇÕES ---
export const CotacoesTab: React.FC = () => {
    const toast = useToast();
    const [quotes, setQuotes] = useState<Quote[]>([]);
    
    useEffect(() => {
        FirestoreService.getAll<Quote>('quotes').then(setQuotes);
    }, []);

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Gestão de Cotações</h3>
                <Button className="bg-indigo-600 gap-2"><Plus size={18}/> Nova Cotação</Button>
            </div>
            <div className="grid grid-cols-1 gap-4">
                {quotes.map(q => (
                    <Card key={q.id} className="glass p-6">
                        <h4 className="text-lg font-bold">{q.id}</h4>
                        <Badge color="amber">{q.status}</Badge>
                    </Card>
                ))}
                {quotes.length === 0 && <p className="text-center text-slate-400 py-10">Nenhuma cotação registrada.</p>}
            </div>
        </div>
    );
};

// --- PEDIDOS DE COMPRA ---
export const PedidosTab: React.FC<{ onUpdate: () => void }> = ({ onUpdate }) => {
    const [orders, setOrders] = useState<PurchaseOrder[]>([]);
    
    useEffect(() => {
        FirestoreService.getAll<PurchaseOrder>('purchase_orders').then(setOrders);
    }, []);

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Pedidos de Compra (POs)</h3>
                <Button className="bg-indigo-600 gap-2"><Plus size={18}/> Emitir Pedido</Button>
            </div>
            <div className="grid grid-cols-1 gap-4">
                {orders.map(o => (
                    <Card key={o.id} className="glass p-6">
                        <div className="flex justify-between">
                            <h4 className="text-lg font-bold">{o.supplierName}</h4>
                            <span className="font-black text-indigo-600">R$ {o.totalValue.toLocaleString()}</span>
                        </div>
                        <p className="text-xs text-slate-400">Entrega: {new Date(o.deliveryDate).toLocaleDateString()}</p>
                    </Card>
                ))}
                {orders.length === 0 && <p className="text-center text-slate-400 py-10">Nenhum pedido de compra.</p>}
            </div>
        </div>
    );
};

// --- CLIENTES / PARCEIROS ---
export const ClientsTab: React.FC = () => {
    const [clients, setClients] = useState<Client[]>([]);
    
    useEffect(() => {
        FirestoreService.getAll<Client>('clients').then(setClients);
    }, []);

    return (
        <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black dark:text-white">Clientes & Parceiros</h3>
                <Button className="bg-indigo-600 gap-2"><Plus size={18}/> Novo Cliente</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {clients.map(c => (
                    <Card key={c.id} className="glass p-6">
                        <h4 className="text-lg font-bold">{c.name}</h4>
                        <p className="text-xs text-slate-400">{c.email}</p>
                    </Card>
                ))}
                {clients.length === 0 && <p className="col-span-full text-center text-slate-400 py-10">Nenhum cliente cadastrado.</p>}
            </div>
        </div>
    );
};


import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from './UI';
import { APP_FOOTER } from '../constants';
import { 
  LayoutDashboard, Users, Package, Briefcase, Settings, LogOut, Menu, X, Bell,
  Search, Sun, Moon, Zap, DollarSign, Box, UserCircle, FileText, ShieldCheck,
  Truck, BrainCircuit, Heart, BarChart3, Leaf
} from 'lucide-react';

interface SidebarItemProps {
  id?: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
  permission?: string;
  colorClass: string;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active, onClick, permission, colorClass }) => {
  const { hasPermission } = useAuth();
  if (permission && !hasPermission(permission)) return null;

  const baseColor = colorClass.split('-')[1];

  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-2xl transition-premium group relative overflow-hidden ${
        active 
          ? `bg-${baseColor}-500/10 text-${baseColor}-500 shadow-sm` 
          : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 hover:text-slate-900 dark:hover:text-slate-100'
      }`}
    >
      <span className={`transition-premium ${active ? 'scale-110' : 'group-hover:scale-110'}`}>{icon}</span>
      <span className="font-bold text-sm tracking-tight">{label}</span>
      {active && <div className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-${baseColor}-500 rounded-r-full shadow-[0_0_10px_rgba(var(--color-rgb),0.5)]`}></div>}
    </button>
  );
};

export const Layout: React.FC<{ children: React.ReactNode; activeTab: string; onTabChange: (tab: string) => void }> = ({ children, activeTab, onTabChange }) => {
  const { currentUser, logout } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modularização solicitada: Recursos, Ações (Projetos), ESG
  const menuItems = [
    { id: 'dashboard', label: 'Painel Geral', icon: <LayoutDashboard size={20} />, color: 'blue' },
    
    // Módulo: Métricas ESG & Impacto
    { id: 'insight', label: 'Painel ESG & Impacto', icon: <Leaf size={20} />, color: 'emerald' },
    { id: 'conformia', label: 'Governança (G)', icon: <ShieldCheck size={20} />, color: 'teal', permission: 'conformia.view' },
    
    // Módulo: Monitorização de Ações (Economia Criativa)
    { id: 'projects', label: 'Projetos Criativos', icon: <Briefcase size={20} />, color: 'violet' },
    { id: 'crm', label: 'Comunidade (S)', icon: <Heart size={20} />, color: 'red' },
    
    // Módulo: Gestão de Recursos
    { id: 'finance', label: 'Recursos Financeiros', icon: <DollarSign size={20} />, color: 'amber' },
    { id: 'supplies', label: 'Materiais & Ativos', icon: <Package size={20} />, color: 'orange' },
    
    // Suporte
    { id: 'reports', label: 'Relatórios Sociais', icon: <BarChart3 size={20} />, color: 'sky' },
    { id: 'users', label: 'Rede de Usuários', icon: <Users size={20} />, color: 'indigo' },
  ];

  const currentModule = menuItems.find(m => m.id === activeTab) || { color: 'indigo' };

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-900 transition-colors duration-500">
      <style>{`
        .active-tab-glow { box-shadow: 0 0 20px -5px currentColor; }
      `}</style>
      
      <aside className={`fixed inset-y-0 left-0 z-40 w-72 glass border-r transform transition-premium lg:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}`}>
        <div className="flex flex-col h-full py-8 px-4">
          <div className="px-4 flex items-center gap-4 mb-10">
            <div className={`w-12 h-12 bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg transition-all duration-500`}>G</div>
            <div className="flex flex-col">
              <h1 className="text-xl font-black tracking-tighter dark:text-white leading-none">GIRA CEAP</h1>
              <span className="text-[9px] text-slate-500 font-bold tracking-widest uppercase mt-1">Economia Criativa</span>
            </div>
          </div>

          <nav className="flex-1 space-y-1 overflow-y-auto custom-scrollbar pr-2">
            <p className="px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 mt-2">Módulos de Gestão</p>
            {menuItems.map(item => (
              <SidebarItem 
                key={item.id}
                icon={item.icon}
                label={item.label}
                active={activeTab === item.id}
                colorClass={`text-${item.color}-500`}
                onClick={() => { onTabChange(item.id); setIsMobileMenuOpen(false); }}
                permission={item.permission}
              />
            ))}
          </nav>

          <div className="mt-4 pt-4 border-t border-slate-200/50 dark:border-slate-800 space-y-4">
            <SidebarItem id="settings" icon={<Settings size={20} />} label="Configurações" active={activeTab === 'settings'} colorClass="text-slate-500" onClick={() => onTabChange('settings')} />
            <div className="p-4 glass rounded-2xl border border-slate-200/50 dark:border-slate-700/30 flex items-center gap-3">
              <img src={currentUser?.photoURL} className="w-10 h-10 rounded-xl border border-white dark:border-slate-800" alt="" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-black truncate dark:text-white">{currentUser?.name}</p>
                <button onClick={logout} className="text-[9px] font-black text-rose-500 uppercase tracking-widest hover:underline transition-premium">Logout</button>
              </div>
              <button onClick={toggleTheme} className="p-2 text-slate-400 hover:text-indigo-500 transition-premium">
                {isDark ? <Sun size={16} /> : <Moon size={16} />}
              </button>
            </div>
          </div>
        </div>
      </aside>

      <div className="flex-1 lg:ml-72 flex flex-col min-w-0">
        <header className="h-20 glass px-8 flex items-center justify-between sticky top-0 z-30 border-b border-slate-200/50 dark:border-slate-800">
          <button onClick={() => setIsMobileMenuOpen(true)} className="lg:hidden p-2 text-slate-400 hover:text-indigo-600 transition-premium">
            <Menu size={24} />
          </button>
          
          <div className="flex-1 flex justify-center max-w-xl mx-auto px-4">
             <div className={`flex items-center glass px-5 py-2.5 rounded-2xl w-full gap-4 border border-slate-200/50 dark:border-slate-800 shadow-inner group focus-within:border-${currentModule.color}-500/50 transition-premium`}>
                <Search size={18} className={`text-slate-400 group-focus-within:text-${currentModule.color}-500`} />
                <input type="text" placeholder="Pesquisar recursos, projetos ou beneficiários..." className="bg-transparent border-none focus:ring-0 text-sm w-full dark:text-white font-medium" />
             </div>
          </div>

          <div className="flex items-center gap-3">
             <button className={`p-3 glass rounded-2xl text-slate-400 hover:text-${currentModule.color}-500 hover:bg-white dark:hover:bg-slate-800 relative transition-premium`}>
                <Bell size={20} />
                <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white dark:border-slate-900 shadow-lg"></span>
             </button>
             <div className={`w-10 h-10 rounded-2xl bg-gradient-to-br from-${currentModule.color}-500 to-${currentModule.color}-400 flex items-center justify-center text-white shadow-lg transition-premium hover:rotate-6`}>
                <Zap size={18} />
             </div>
          </div>
        </header>

        <main className="flex-1 p-8 lg:p-12 animate-in fade-in duration-300">
          {children}
        </main>
      </div>
    </div>
  );
};

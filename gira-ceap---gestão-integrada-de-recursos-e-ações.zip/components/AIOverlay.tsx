
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";
import { MessageSquare, X, Send, Sparkles, Volume2, Brain, Loader2, Bot } from 'lucide-react';
import { Button, Card, Badge } from './UI';

// Helper for TTS decoding
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export const AIOverlay: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string, isThinking?: boolean }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSpeak = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' }
            }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        const ctx = audioContextRef.current;
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => setIsSpeaking(false);
        source.start();
      } else {
        setIsSpeaking(false);
      }
    } catch (error) {
      console.error("TTS Error:", error);
      setIsSpeaking(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const config: any = {};
      if (useThinking) {
        config.thinkingConfig = { thinkingBudget: 32768 };
      }

      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: userMsg,
        config: {
          ...config,
          systemInstruction: 'Você é o Assistente Global do GIRA CEAP. Você tem acesso intelectual a processos de gestão social, suprimentos e compliance. Seja formal, eficiente e empático.'
        }
      });

      setMessages(prev => [...prev, { role: 'ai', text: response.text || 'Não consegui processar essa requisição.', isThinking: useThinking }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Erro de conexão com o núcleo cognitivo.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    // FIX: Fixed Position set to Bottom Right to avoid Sidebar Conflict
    <div className="fixed bottom-6 right-6 z-[100]">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-indigo-500 rounded-full shadow-2xl flex items-center justify-center text-white hover:scale-110 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse-soft opacity-0 group-hover:opacity-100"></div>
          <Bot size={28} className="relative" />
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white"></span>
        </button>
      ) : (
        <Card className="w-[400px] h-[600px] flex flex-col p-0 shadow-3xl animate-in zoom-in-95 slide-in-from-bottom-10 duration-500 border-indigo-500/20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl rounded-[40px] overflow-hidden" glass={true}>
          <div className="p-6 bg-indigo-600 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center">
                <Sparkles size={20} />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-widest">Cognição ATIS</h3>
                <p className="text-[9px] font-bold opacity-70">GEMINI 3 PRO PREVIEW</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar" ref={scrollRef}>
            {messages.length === 0 && (
              <div className="h-full flex flex-col items-center justify-center text-center px-6">
                <Brain size={48} className="text-indigo-200 dark:text-indigo-900 mb-4" />
                <p className="text-sm font-bold text-slate-400">Olá! Como posso ajudar na gestão do GIRA hoje?</p>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-[28px] text-sm font-medium ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none shadow-lg' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-200 dark:border-slate-700'}`}>
                  {m.text}
                </div>
                {m.role === 'ai' && (
                  <div className="flex items-center gap-2 mt-2 ml-1">
                    <button onClick={() => handleSpeak(m.text)} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 transition-colors" title="Ouvir resposta">
                      <Volume2 size={14} className={isSpeaking ? 'text-indigo-500 animate-pulse' : ''} />
                    </button>
                    {m.isThinking && <Badge color="indigo">Pensamento Profundo</Badge>}
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="p-4 rounded-[28px] bg-indigo-500/10 rounded-tl-none flex items-center gap-3">
                  <Loader2 size={16} className="animate-spin text-indigo-500" />
                  <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{useThinking ? 'Processando Complexidade...' : 'Consultando Matriz...'}</span>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between px-2">
              <label className="flex items-center gap-2 cursor-pointer group">
                <div className={`w-8 h-4 rounded-full relative transition-colors ${useThinking ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}>
                  <input type="checkbox" className="hidden" checked={useThinking} onChange={e => setUseThinking(e.target.checked)} />
                  <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${useThinking ? 'translate-x-4' : ''}`}></div>
                </div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-indigo-500 transition-colors">Modo Raciocínio</span>
              </label>
              <Badge color="slate">PRO 3.0</Badge>
            </div>
            
            <div className="flex gap-3">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                placeholder="Pergunte ao GIRA..."
                className="flex-1 bg-slate-50 dark:bg-slate-800 border-none rounded-2xl px-5 py-3 text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 dark:text-white"
              />
              <Button onClick={handleSend} loading={isLoading} className="rounded-2xl w-12 h-12 p-0 flex items-center justify-center">
                <Send size={18} />
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

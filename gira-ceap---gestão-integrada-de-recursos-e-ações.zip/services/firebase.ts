
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

// --- CONFIGURAÇÃO DO FIREBASE ---
const firebaseConfig = {
  apiKey: "AIzaSyAltW7iyh_weXXk2LNzE_iPUotvVRbR30k", 
  authDomain: "gira-annitech-33258.firebaseapp.com",
  projectId: "gira-annitech-33258",
  storageBucket: "gira-annitech-33258.firebasestorage.app",
  messagingSenderId: "51029124271554",
  appId: "1:1029124271554:web:9aacc806076913218bba5b",
  measurementId: "G-RD3X5Q3SDQ"
};

// Singleton Pattern: Usa app existente ou inicializa um novo
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

export default app;

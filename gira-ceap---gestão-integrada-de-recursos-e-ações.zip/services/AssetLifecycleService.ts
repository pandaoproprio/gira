
import { Asset, MaintenanceOrder, AssetInsurance, AssetRevaluation, AccountingEntry } from '../types';
import { FirestoreService } from './FirestoreService';
import { AssetService } from './AssetService';

/**
 * GIRA CEAP - Asset Lifecycle Manager
 * Camada de extensão para gestão de Facilities e Contabilidade de Ativos.
 */
export const AssetLifecycleService = {

  // --- 1. GESTÃO DE MANUTENÇÃO ---

  /**
   * Cria uma Ordem de Serviço (O.S.) vinculada a um ativo
   */
  createWorkOrder: async (asset: Asset, description: string, type: 'PREVENTIVA' | 'CORRETIVA', scheduledDate: string, user: string): Promise<string> => {
    const os: MaintenanceOrder = {
      id: `OS-${Date.now()}`,
      assetId: asset.id,
      assetName: asset.name,
      type,
      status: 'ABERTA',
      priority: type === 'CORRETIVA' ? 'ALTA' : 'MEDIA',
      description,
      scheduledDate,
      cost: 0,
      createdAt: new Date().toISOString(),
      technicianName: user
    };
    
    return await FirestoreService.save('maintenance_orders', os.id, os);
  },

  // --- 2. MOBILIDADE E RASTREAMENTO ---

  /**
   * Gera a URL do QR Code para impressão de etiquetas patrimoniais.
   * Utiliza a API pública do Google Charts (deprecada mas funcional) ou QuickChart para renderizar.
   */
  generateQRCodeUrl: (asset: Asset): string => {
    // Payload contém ID e Hash para validação offline se necessário
    const payload = JSON.stringify({ id: asset.id, code: asset.code });
    const encoded = encodeURIComponent(payload);
    return `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encoded}`;
  },

  /**
   * Simula a leitura de inventário (Bipar Ativo)
   * Atualiza a localização e data de última verificação física.
   */
  scanAssetInventory: async (assetId: string, location: string, userId: string) => {
    // Não altera tabela original estruturalmente, apenas atualiza campos permitidos
    await FirestoreService.save('assets', assetId, { 
      location,
      lastInventoryDate: new Date().toISOString(),
      lastInventoryBy: userId
    });
  },

  // --- 3. GESTÃO FINANCEIRA ---

  /**
   * Registra uma apólice de seguro
   */
  addInsurance: async (assetId: string, policy: Omit<AssetInsurance, 'id' | 'assetId' | 'status'>) => {
    const insurance: AssetInsurance = {
      id: `INS-${Date.now()}`,
      assetId,
      ...policy,
      status: 'VIGENTE'
    };
    return await FirestoreService.save('asset_insurances', insurance.id, insurance);
  },

  /**
   * Reavaliação de Ativo (Mark-to-Market)
   * Mantém o histórico e atualiza o valor contábil para fins de seguro/venda, 
   * mas SEMPRE preserva o custo histórico na tabela original se assim desejado, 
   * ou atualiza com log de auditoria.
   */
  revaluateAsset: async (asset: Asset, newValue: number, reason: string, userId: string) => {
    const revaluation: AssetRevaluation = {
      id: `REV-${Date.now()}`,
      assetId: asset.id,
      oldValue: asset.value,
      newValue,
      revaluationDate: new Date().toISOString(),
      reason,
      responsibleId: userId
    };

    // Salva o histórico de reavaliação
    await FirestoreService.save('asset_revaluations', revaluation.id, revaluation);
    
    // Atualiza o valor atual no mestre (opcional, dependendo da política contábil)
    // Aqui optamos por atualizar para refletir no Dashboard, pois o histórico guarda o original
    await FirestoreService.save('assets', asset.id, { value: newValue });
  },

  // --- 4. MOTOR DE DEPRECIAÇÃO (CONTABILIDADE) ---

  /**
   * Job de Fechamento Mensal de Depreciação.
   * Deve ser executado uma vez por mês (via botão na UI ou Cloud Function).
   * Gera lançamentos contábeis (Journal Entries).
   */
  runDepreciationJob: async (assets: Asset[], referenceDate: Date = new Date()): Promise<number> => {
    let entriesCount = 0;
    const competencia = referenceDate.toISOString().slice(0, 7); // YYYY-MM

    for (const asset of assets) {
      if (asset.status !== 'Operacional') continue;

      // Usa a lógica de cálculo linear do serviço existente
      const details = AssetService.calculateDepreciationDetails(asset);
      const monthlyDepreciation = details.annualDepreciationValue / 12;

      if (monthlyDepreciation <= 0 || details.residualValue <= 0) continue;

      const entry: AccountingEntry = {
        id: `ACC-${asset.id}-${competencia}`,
        assetId: asset.id,
        date: referenceDate.toISOString().split('T')[0],
        type: 'DEPRECIACAO',
        debitAccount: '3.1.05.01 (Despesa Depreciação)',
        creditAccount: '1.2.05.99 (Depreciação Acumulada)',
        amount: Number(monthlyDepreciation.toFixed(2)),
        description: `Depreciação Mensal Ref. ${competencia} - ${asset.code}`,
        processedBy: 'SYSTEM_JOB'
      };

      // Grava na coleção segregada de contabilidade
      await FirestoreService.save('accounting_journal', entry.id, entry);
      entriesCount++;
    }

    return entriesCount;
  }
};


import { db } from './firebase';
import { 
  collection, doc, getDocs, getDoc, setDoc, deleteDoc, 
  addDoc, query, onSnapshot, QueryConstraint 
} from 'firebase/firestore';

export const FirestoreService = {
  // Busca todos os documentos de uma coleção
  getAll: async <T>(collectionName: string): Promise<T[]> => {
    try {
      const snapshot = await getDocs(collection(db, collectionName));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
    } catch (e: any) {
      if (e.code === 'permission-denied') {
        console.warn(`[Acesso Negado] Leitura bloqueada em: ${collectionName}. Verifique seu perfil de usuário.`);
        return [];
      }
      if (e.code === 'unavailable' || e.message?.includes('offline')) {
        console.warn(`[Offline] Leitura em ${collectionName} falhou.`);
        return [];
      }
      console.error(`Erro ao buscar ${collectionName}:`, e);
      return [];
    }
  },

  // Busca documentos com filtros complexos (where, orderBy, limit)
  getByQuery: async <T>(collectionName: string, ...constraints: QueryConstraint[]): Promise<T[]> => {
    try {
      const q = query(collection(db, collectionName), ...constraints);
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
    } catch (e: any) {
      if (e.code === 'permission-denied') {
        console.warn(`[Acesso Negado] Query bloqueada em: ${collectionName}`);
        return [];
      }
      console.error(`Erro na query de ${collectionName}:`, e);
      return [];
    }
  },

  // Busca um único documento por ID
  getById: async <T>(collectionName: string, id: string): Promise<T | null> => {
    try {
      const docRef = doc(db, collectionName, id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as T;
      }
      return null;
    } catch (e: any) {
      if (e.code === 'permission-denied') return null;
      if (e.code !== 'unavailable' && !e.message?.includes('offline')) {
        console.error(`Erro ao buscar documento ${id}:`, e);
      }
      return null;
    }
  },

  // Adiciona ou Atualiza um documento
  save: async (collectionName: string, id: string | null, data: any) => {
    try {
      if (id) {
        const docRef = doc(db, collectionName, id);
        await setDoc(docRef, data, { merge: true });
        return id;
      } else {
        const colRef = collection(db, collectionName);
        const docRef = await addDoc(colRef, data);
        return docRef.id;
      }
    } catch (e: any) {
      if (e.code === 'permission-denied') {
        console.error(`[Acesso Negado] Escrita bloqueada em: ${collectionName}`);
        throw new Error("Permissão insuficiente para salvar dados.");
      }
      console.error(`Erro ao salvar em ${collectionName}:`, e);
      throw e;
    }
  },

  // Deleta um documento
  delete: async (collectionName: string, id: string) => {
    try {
      await deleteDoc(doc(db, collectionName, id));
    } catch (e: any) {
      if (e.code === 'permission-denied') {
        throw new Error("Permissão insuficiente para excluir dados.");
      }
      console.error(`Erro ao deletar ${id}:`, e);
      throw e;
    }
  },

  // Escuta atualizações em tempo real (Real-time Listener)
  subscribe: <T>(
    collectionName: string, 
    onUpdate: (data: T[]) => void, 
    constraints: QueryConstraint[] = []
  ): () => void => {
    try {
      const q = query(collection(db, collectionName), ...constraints);
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T));
        onUpdate(data);
      }, (error) => {
        if (error.code === 'permission-denied') {
             console.warn(`[Listener] Acesso negado a ${collectionName}. Interrompendo escuta.`);
        } else {
             console.error(`Erro no listener de ${collectionName}:`, error);
        }
      });

      return unsubscribe;
    } catch (e) {
      console.error("Erro ao configurar subscription", e);
      return () => {};
    }
  }
};


import { FirestoreService } from './FirestoreService';
import { 
  TimeRecord, AbsenceRequest, PerformanceReview, 
  EmployeeTraining, ProjectCostAllocation, Project 
} from '../types';

interface Employee {
  id: string;
  name: string;
  salary: number;
  role: string;
}

export const HRService = {
  
  // --- 1. OPERACIONAL: PONTO & AUSÊNCIAS ---

  clockIn: async (employeeId: string): Promise<void> => {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date().toISOString();
    
    // Busca registro existente do dia
    const existing = await FirestoreService.getByQuery<TimeRecord>('hr_time_records', 
      ['employeeId', '==', employeeId],
      ['date', '==', today]
    );

    if (existing.length > 0) {
      const record = existing[0];
      const newEntries = [...record.entries, now];
      await FirestoreService.save('hr_time_records', record.id, { entries: newEntries });
    } else {
      const newRecord: TimeRecord = {
        id: `TR-${Date.now()}`,
        employeeId,
        date: today,
        entries: [now],
        type: 'NORMAL',
        status: 'PENDING',
        totalHours: 0
      };
      await FirestoreService.save('hr_time_records', newRecord.id, newRecord);
    }
  },

  requestAbsence: async (req: Omit<AbsenceRequest, 'id' | 'status'>) => {
    const payload: AbsenceRequest = {
      id: `ABS-${Date.now()}`,
      ...req,
      status: 'PENDING'
    };
    return await FirestoreService.save('hr_absences', payload.id, payload);
  },

  // --- 2. GESTÃO DE TALENTOS ---

  submitPerformanceReview: async (review: PerformanceReview) => {
    return await FirestoreService.save('hr_reviews', review.id, review);
  },

  enrollTraining: async (employeeId: string, courseId: string) => {
    const enrollment: EmployeeTraining = {
      id: `TRN-${Date.now()}`,
      employeeId,
      courseId,
      progress: 0,
      status: 'IN_PROGRESS'
    };
    return await FirestoreService.save('hr_employee_trainings', enrollment.id, enrollment);
  },

  // --- 3. INTELIGÊNCIA FINANCEIRA (ALGORITMO DE CUSTEIO) ---

  calculateProjectCost: async (
    employee: Employee, 
    project: Project, 
    hoursWorked: number,
    month: string
  ): Promise<ProjectCostAllocation> => {
    
    const ENCARGOS_FACTOR = 1.6; // 60% de encargos
    const MONTHLY_HOURS = 220; // CLT Padrão

    const totalCost = employee.salary * ENCARGOS_FACTOR;
    const hourlyRate = totalCost / MONTHLY_HOURS;
    const projectCost = hourlyRate * hoursWorked;

    const allocation: ProjectCostAllocation = {
      id: `COST-${employee.id}-${project.id}-${month}`,
      employeeId: employee.id,
      projectId: project.id,
      month,
      hoursAllocated: hoursWorked,
      hourlyRate: parseFloat(hourlyRate.toFixed(2)),
      totalCost: parseFloat(projectCost.toFixed(2)),
      source: 'ESTIMATED'
    };

    await FirestoreService.save('hr_cost_allocations', allocation.id, allocation);
    
    return allocation;
  }
};

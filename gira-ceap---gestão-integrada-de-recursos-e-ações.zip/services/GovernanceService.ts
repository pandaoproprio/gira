
// BACKUP REFERENCIA_V1_20240523
import { ThirdPartyAssessment, MaturityAssessment, IncidentSimulation } from '../types';

export const GovernanceService = {
  
  /**
   * TPRM: Calcula o Score de Risco baseado nas respostas do questionário.
   * Algoritmo Determinístico.
   */
  calculateRiskScore: (answers: ThirdPartyAssessment['questionnaire']): { score: number, level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' } => {
    let score = 0;
    const maxScore = 100;
    
    // Pesos
    if (answers.iso27001) score += 30;
    if (answers.hasDPO) score += 20;
    if (answers.hasEncryption) score += 20;
    if (answers.hasIncidentPlan) score += 15;
    if (answers.dataRetentionPolicy) score += 15;

    // Risco Inverso (Quanto maior o score de segurança, menor o risco)
    const riskScore = maxScore - score; 

    let level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
    if (riskScore >= 80) level = 'CRITICAL';
    else if (riskScore >= 50) level = 'HIGH';
    else if (riskScore >= 20) level = 'MEDIUM';

    return { score: riskScore, level };
  },

  /**
   * MATURITY: Gera assessment de maturidade LGPD.
   */
  calculateMaturityScore: (answers: Record<string, boolean>): Omit<MaturityAssessment, 'id' | 'date'> => {
    // Simulação de cálculo ponderado por domínio
    // Em produção, isso viria de uma base de perguntas e pesos reais
    const domains = { governance: 0, process: 0, technology: 0, people: 0 };
    let totalYes = 0;
    let totalQuestions = 0;

    Object.entries(answers).forEach(([key, value]) => {
      totalQuestions++;
      if (value) {
        totalYes++;
        // Distribuição simplificada para MVP
        if (key.includes('gov')) domains.governance += 25;
        if (key.includes('proc')) domains.process += 25;
        if (key.includes('tech')) domains.technology += 25;
        if (key.includes('ppl')) domains.people += 25;
      }
    });

    const finalScore = totalQuestions > 0 ? Math.round((totalYes / totalQuestions) * 100) : 0;

    return {
      score: finalScore,
      breakdown: domains,
      answers
    };
  },

  /**
   * BCP: Sandbox para Simulação de Incidentes.
   * NÃO persiste dados no banco. Apenas retorna análise para "Tabletop Exercise".
   */
  runIncidentSimulation: (scenarioType: string): IncidentSimulation => {
    // Lógica de "Sandbox" - Cenários pré-definidos
    switch (scenarioType) {
      case 'RANSOMWARE':
        return {
          scenario: 'Ataque de Ransomware em Servidor de Arquivos',
          severity: 'CRITICAL',
          affectedSystems: ['GED Cloud', 'Servidor de Arquivos Local', 'Estações Financeiro'],
          estimatedDataLoss: '4 horas (RPO)',
          recommendedActions: [
            'Isolar rede imediatamente (Kill Switch)',
            'Acionar Plano BCP-01 (Restore Imutável)',
            'Notificar ANPD (Prazo 72h)',
            'Acionar Seguradora Cyber'
          ]
        };
      case 'DATA_LEAK':
        return {
          scenario: 'Vazamento de Credenciais de Admin',
          severity: 'HIGH',
          affectedSystems: ['Painel Administrativo', 'Banco de Dados Usuários'],
          estimatedDataLoss: 'Indeterminado - Integridade Comprometida',
          recommendedActions: [
            'Reset forçado de senhas globais',
            'Revogar tokens de sessão ativos',
            'Auditoria de logs de acesso (últimas 24h)',
            'Comunicar titulares afetados'
          ]
        };
      case 'PROVIDER_OUTAGE':
        return {
          scenario: 'Indisponibilidade do Provedor Cloud (AWS/Azure)',
          severity: 'MEDIUM',
          affectedSystems: ['Frontend GIRA', 'API Gateway'],
          estimatedDataLoss: '0 (Dados preservados, Acesso interrompido)',
          recommendedActions: [
            'Ativar site estático de manutenção',
            'Monitorar status page do provedor',
            'Preparar operação manual (contingência offline)'
          ]
        };
      default:
        return {
          scenario: 'Incidente Não Classificado',
          severity: 'LOW',
          affectedSystems: [],
          estimatedDataLoss: 'N/A',
          recommendedActions: ['Investigar anomalia']
        };
    }
  }
};

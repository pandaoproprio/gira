
/**
 * GIRA CEAP - Backup Service
 * Protocolo de Segurança de Dados v5.2 (Enterprise Snapshot)
 */

const DB_KEYS = [
  // Core e Identidade
  'gira_users_v2', 'gira_roles_v2', 'gira_audit_v2',
  // Suprimentos e Logística
  'gira_materials_v2', 'gira_suppliers_v2', 'gira_clients_v2', 'gira_movements_v2',
  'gira_purchase_requests_v2', 'gira_purchase_orders_v2', 'gira_quotes_v2', 'gira_categories_v2',
  // Projetos e Impacto
  'gira_projects_v2', 'gira_taps_v2', 'gira_diary_v2', 'gira_documents_v2',
  // Financeiro e Patrimônio
  'gira_finance_v2', 'gira_cost_centers_v2', 'gira_patrimony_v2', 'gira_contracts_v2',
  // RH
  'gira_hr_v2',
  // CRM Gira Vínculos
  'gira_crm_beneficiaries_v1', 'gira_crm_attendances_v1', 'gira_crm_funders_v1', 
  'gira_crm_donors_v1', 'gira_crm_donations_v1', 'gira_crm_communications_v1',
  // Conformia (Compliance)
  'conformia_data_mapping_v1', 'conformia_subject_requests_v1', 'conformia_incidents_v1', 
  'conformia_policies_v1', 'conformia_trainings_v1', 'conformia_dpias_v1'
];

export interface BackupData {
  metadata: {
    app: string;
    version: string;
    timestamp: string;
    checksum: string;
    recordsCount: Record<string, number>;
  };
  payload: Record<string, any>;
}

export const BackupService = {
  /**
   * Exporta todo o estado do sistema para um arquivo JSON
   */
  exportAllData: () => {
    const payload: Record<string, any> = {};
    const recordsCount: Record<string, number> = {};
    
    DB_KEYS.forEach(key => {
      const data = localStorage.getItem(key);
      if (data) {
        try {
          const parsed = JSON.parse(data);
          payload[key] = parsed;
          recordsCount[key] = Array.isArray(parsed) ? parsed.length : 1;
        } catch (e) {
          payload[key] = data;
          recordsCount[key] = 1;
        }
      }
    });

    const backup: BackupData = {
      metadata: {
        app: "GIRA CEAP",
        version: "5.2-ENTERPRISE",
        timestamp: new Date().toISOString(),
        checksum: Math.random().toString(36).substring(7).toUpperCase(),
        recordsCount
      },
      payload
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const dateStr = new Date().toISOString().split('T')[0];
    link.href = url;
    link.download = `GIRA_SNAPSHOT_${dateStr}_${backup.metadata.checksum}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  /**
   * Analisa e valida um arquivo de backup
   */
  analyzeBackup: (jsonContent: string): BackupData | null => {
    try {
      const data = JSON.parse(jsonContent) as BackupData;
      
      // Validação Básica de Assinatura
      if (data.metadata?.app !== "GIRA CEAP") return null;

      // Validação de Schema (Deve conter chaves vitais para o sistema não quebrar)
      const vitalKeys = ['gira_users_v2', 'gira_projects_v2', 'gira_materials_v2'];
      const hasVitalKeys = vitalKeys.every(key => data.payload && data.payload[key]);
      
      if (!hasVitalKeys) return null;

      return data;
    } catch (e) {
      return null;
    }
  },

  /**
   * Restaura o sistema e gera log de auditoria
   */
  restoreData: (backup: BackupData) => {
    // Limpeza de segurança das chaves monitoradas
    DB_KEYS.forEach(key => localStorage.removeItem(key));

    // Restauração do Payload
    Object.entries(backup.payload).forEach(([key, value]) => {
      localStorage.setItem(key, JSON.stringify(value));
    });

    // Auditoria forçada (Garante que a restauração seja registrada mesmo em um banco antigo)
    const auditKey = 'gira_audit_v2';
    const logs = JSON.parse(localStorage.getItem(auditKey) || '[]');
    logs.unshift({
      id: crypto.randomUUID(),
      userId: 'system-restore',
      userName: 'Recuperação de Desastre',
      action: 'RESTORE_DATABASE',
      module: 'SYSTEM',
      timestamp: new Date().toISOString(),
      ip: '127.0.0.1',
      details: `Banco restaurado com sucesso. Checksum: ${backup.metadata.checksum}. Origem: Snapshot de ${new Date(backup.metadata.timestamp).toLocaleString()}`,
      criticality: 'CRITICAL'
    });
    localStorage.setItem(auditKey, JSON.stringify(logs.slice(0, 1000)));

    return true;
  }
};

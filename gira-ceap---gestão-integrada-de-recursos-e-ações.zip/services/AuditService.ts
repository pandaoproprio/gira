
import { FirestoreService } from './FirestoreService';
import { AuditLog } from '../types';
import { mockDB } from './mockDB';

export const AuditService = {
  /**
   * Captura o IP público do usuário através de serviço externo
   */
  getVisitorIp: async (): Promise<string> => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (e) {
      return '127.0.0.1';
    }
  },

  /**
   * Registra uma ação crítica com estratégia de Fallback (Cloud -> Local)
   */
  log: async (params: {
    userId: string;
    userName: string;
    action: string;
    module: string;
    details: string;
    criticality: 'INFO' | 'WARN' | 'CRITICAL';
    oldValue?: string;
    newValue?: string;
  }) => {
    let ip = '127.0.0.1';
    try {
      ip = await AuditService.getVisitorIp();
    } catch (e) {
      // Ignora erro de IP em produção
    }

    const logData: Omit<AuditLog, 'id'> = {
      ...params,
      timestamp: new Date().toISOString(),
      ip,
      device: navigator.userAgent
    };

    try {
      // 1. Tenta persistência na nuvem (Firestore)
      await FirestoreService.save('auditLogs', null, logData);
    } catch (error: any) {
      // 2. Fallback para armazenamento local em caso de erro de permissão/rede
      if (error.code === 'permission-denied' || error.message?.includes('permissions')) {
        console.warn(`[AUDIT] Sem permissão de escrita Cloud. Salvando localmente.`);
      } else {
        console.warn(`[AUDIT] Erro de conexão Cloud. Salvando localmente.`, error);
      }

      try {
        await mockDB.audit({
          ...params,
          ip,
          device: navigator.userAgent
        });
      } catch (localError) {
        console.error("Falha crítica no sistema de auditoria (Local & Cloud).", localError);
      }
    }
  }
};

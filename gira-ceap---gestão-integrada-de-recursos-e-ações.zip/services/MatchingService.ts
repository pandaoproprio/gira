
import { Beneficiary, ProjectCriteria } from '../types';

/**
 * GIRA CEAP - Matching & Targeting Service
 * Algoritmo de Elegibilidade para Projetos Sociais
 */
export const MatchingService = {
  
  /**
   * Calculates age from birth date string (YYYY-MM-DD)
   */
  calculateAge: (birthDate: string): number => {
    if (!birthDate) return 0;
    const birth = new Date(birthDate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  },

  /**
   * Filters beneficiaries based on project criteria
   * Returns a list of eligible candidates sorted by vulnerability count (priority)
   */
  findEligibleBeneficiaries: (beneficiaries: Beneficiary[], criteria: ProjectCriteria): Beneficiary[] => {
    return beneficiaries.filter(b => {
      // 1. Status Check
      if (b.status !== 'ATIVO' || b.isAnonymized) return false;

      // 2. Age Check
      const age = MatchingService.calculateAge(b.birthDate);
      if (criteria.minAge && age < criteria.minAge) return false;
      if (criteria.maxAge && age > criteria.maxAge) return false;

      // 3. Location Check
      if (criteria.location && criteria.location.length > 0) {
        if (!criteria.location.includes(b.address.neighborhood)) return false;
      }

      // 4. Gender Check
      if (criteria.gender && criteria.gender !== 'TODOS') {
        if (b.gender !== criteria.gender) return false;
      }

      // 5. Vulnerability Check (Must have at least one of the required, or all if strict mode - using loose match for MVP)
      if (criteria.requiredVulnerabilities && criteria.requiredVulnerabilities.length > 0) {
        const hasRequired = criteria.requiredVulnerabilities.some(v => b.vulnerabilities.includes(v));
        if (!hasRequired) return false;
      }

      return true;
    }).sort((a, b) => b.vulnerabilities.length - a.vulnerabilities.length); // Higher vulnerability first
  }
};

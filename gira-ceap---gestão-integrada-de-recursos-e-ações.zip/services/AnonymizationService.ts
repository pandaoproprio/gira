
import { Beneficiary } from '../types';
import { FirestoreService } from './FirestoreService';
import { AuditService } from './AuditService';

/**
 * GIRA CEAP - LGPD Anonymization Service
 * Rotina de Mascaramento de Dados Pessoais para Conformidade
 */
export const AnonymizationService = {

  /**
   * Mascara dados sensíveis de um beneficiário mantendo utilidade estatística
   */
  maskBeneficiaryData: (b: Beneficiary): Beneficiary => {
    return {
      ...b,
      name: `ANONIMIZADO-${b.id.slice(-6)}`,
      cpf: '000.000.000-00',
      email: 'anonymized@ceap.data',
      phone: '(00) 00000-0000',
      address: {
        ...b.address,
        street: 'RUA ANONIMIZADA',
        number: '000',
        cep: '00000-000'
        // Mantém Bairro, Cidade e UF para mapas de calor
      },
      isAnonymized: true,
      lgpdConsent: {
        ...b.lgpdConsent,
        revokedAt: new Date().toISOString()
      }
    };
  },

  /**
   * Executa a rotina de limpeza para registros inativos há mais de X anos
   */
  runAnonymizationJob: async (beneficiaries: Beneficiary[], thresholdYears: number = 5, userId: string): Promise<number> => {
    const cutoffDate = new Date();
    cutoffDate.setFullYear(cutoffDate.getFullYear() - thresholdYears);

    let processedCount = 0;

    for (const ben of beneficiaries) {
      // Pula se já anonimizado
      if (ben.isAnonymized) continue;

      // Verifica data da última interação ou criação
      const lastActivityDate = ben.lastInteraction ? new Date(ben.lastInteraction) : new Date(ben.createdAt);
      
      if (lastActivityDate < cutoffDate) {
        const anonymizedBen = AnonymizationService.maskBeneficiaryData(ben);
        
        // Persiste a alteração (Non-Regression: Update apenas, não delete)
        await FirestoreService.save('beneficiaries', ben.id, anonymizedBen);
        processedCount++;
      }
    }

    if (processedCount > 0) {
      await AuditService.log({
        userId: userId,
        userName: 'LGPD Automator',
        action: 'BATCH_ANONYMIZATION',
        module: 'COMPLIANCE',
        details: `Rotina de anonimização executada. ${processedCount} registros processados (Inatividade > ${thresholdYears} anos).`,
        criticality: 'INFO'
      });
    }

    return processedCount;
  }
};


/**
 * GIRA CEAP - Asset Logic Service
 * Gestão de Depreciação e Ciclo de Vida de Ativos v1.1
 */

import { Asset } from '../types';

export const AssetService = {
  /**
   * Calcula o valor residual atual de um ativo baseado na depreciação linear.
   */
  calculateCurrentValue: (asset: Asset): number => {
    if (asset.status === 'Baixado') return 0;
    
    const acquisitionDate = new Date(asset.acquisitionDate);
    const now = new Date();
    
    // Tratamento básico para datas inválidas
    if (isNaN(acquisitionDate.getTime())) return asset.value;

    const diffInMs = now.getTime() - acquisitionDate.getTime();
    const yearsOfUse = diffInMs / (1000 * 60 * 60 * 24 * 365.25);
    
    if (yearsOfUse <= 0) return asset.value;
    if (yearsOfUse >= asset.lifespan) return 0;

    const depreciationPerYear = asset.value / asset.lifespan;
    const totalDepreciation = yearsOfUse * depreciationPerYear;
    
    return Math.max(0, asset.value - totalDepreciation);
  },

  /**
   * Retorna detalhes completos do cálculo de depreciação.
   */
  calculateDepreciationDetails: (asset: Asset) => {
    const acquisitionDate = new Date(asset.acquisitionDate);
    const now = new Date();
    const diffInMs = now.getTime() - acquisitionDate.getTime();
    const yearsOfUse = Math.max(0, diffInMs / (1000 * 60 * 60 * 24 * 365.25));
    
    const remainingLife = Math.max(0, asset.lifespan - yearsOfUse);
    const annualRate = (1 / asset.lifespan) * 100;
    const annualDepreciation = asset.value / asset.lifespan;
    const currentValue = AssetService.calculateCurrentValue(asset);

    return {
      originalValue: asset.value,
      yearsOfUse: yearsOfUse.toFixed(2),
      remainingLife: asset.status === 'Baixado' ? '0.00' : remainingLife.toFixed(2),
      annualRate: annualRate.toFixed(2),
      annualDepreciationValue: annualDepreciation,
      residualValue: currentValue
    };
  },

  /**
   * Gera pontos de dados para o gráfico de evolução do valor residual.
   */
  getDepreciationCurve: (asset: Asset) => {
    const data = [];
    const acquisitionYear = new Date(asset.acquisitionDate).getFullYear();
    const annualDepreciation = asset.value / asset.lifespan;

    for (let i = 0; i <= asset.lifespan; i++) {
      let val = Math.max(0, asset.value - (i * annualDepreciation));
      if (asset.status === 'Baixado') val = 0; // Opcional: Curva poderia mostrar histórico até a baixa

      data.push({
        ano: acquisitionYear + i,
        valor: val,
        label: `Ano ${i}`
      });
    }
    return data;
  },

  /**
   * Retorna o status de saúde do ativo baseado no tempo de vida restante.
   */
  getAssetHealth: (asset: Asset) => {
    if (asset.status === 'Baixado') return { label: 'Inativo', color: 'slate' };

    const acquisitionDate = new Date(asset.acquisitionDate);
    const now = new Date();
    const diffInMs = now.getTime() - acquisitionDate.getTime();
    const yearsOfUse = diffInMs / (1000 * 60 * 60 * 24 * 365.25);
    
    const usagePct = (yearsOfUse / asset.lifespan) * 100;
    
    if (usagePct >= 90) return { label: 'Substituição Recom.', color: 'rose' };
    if (usagePct >= 70) return { label: 'Atenção', color: 'amber' };
    return { label: 'Saudável', color: 'emerald' };
  }
};

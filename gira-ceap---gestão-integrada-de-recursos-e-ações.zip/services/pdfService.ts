
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { TAP, PurchaseOrder, Project, InstitutionalReport } from "../types";

export const pdfService = {
  generateTAPPdf: (project: Project, tap: TAP) => {
    const doc = new jsPDF() as any;
    const primaryColor = "#4f46e5";

    // Topo
    doc.setFillColor(primaryColor);
    doc.rect(0, 0, 210, 40, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text("GIRA CEAP - TAP", 15, 25);
    doc.setFontSize(10);
    doc.text("TERMO DE ABERTURA DO PROJETO", 15, 32);

    // Corpo
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(14);
    doc.text(`Projeto: ${project.name}`, 15, 55);
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Financiador: ${project.financerName}`, 15, 62);
    doc.text(`Patrocinador (Sponsor): ${tap.sponsorName}`, 15, 67);
    doc.text(`Orcamento Teto: R$ ${tap.budgetLimit.toLocaleString()}`, 15, 72);

    doc.setFont("helvetica", "bold");
    doc.text("JUSTIFICATIVA ESTRATÉGICA (BUSINESS CASE):", 15, 85);
    doc.setFont("helvetica", "normal");
    const splitBC = doc.splitTextToSize(tap.businessCase, 180);
    doc.text(splitBC, 15, 92);

    let currentY = 92 + (splitBC.length * 5) + 10;
    doc.setFont("helvetica", "bold");
    doc.text("PRINCIPAIS ENTREGAS:", 15, currentY);
    doc.setFont("helvetica", "normal");
    tap.majorDeliverables.forEach((d, i) => {
      currentY += 6;
      doc.text(`- ${d}`, 20, currentY);
    });

    // Rodapé
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(`Gerado em: ${new Date().toLocaleString()} | GIRA CEAP v5.0`, 15, 285);

    doc.save(`TAP_${project.name.replace(/\s/g, "_")}.pdf`);
  },

  generateInstitutionalReportPdf: (report: InstitutionalReport) => {
    const doc = new jsPDF() as any;
    const accentColor = "#0284c7"; // Sky 600

    // Header
    doc.setFillColor(accentColor);
    doc.rect(0, 0, 210, 50, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(24);
    doc.setFont("helvetica", "bold");
    doc.text("GIRA CEAP", 15, 25);
    doc.setFontSize(14);
    doc.text("RELATÓRIO DE IMPACTO INSTITUCIONAL", 15, 35);
    doc.setFontSize(10);
    doc.text(`Período: ${report.period} | Responsável: ${report.generatedBy}`, 15, 42);

    // Body
    doc.setTextColor(50, 50, 50);
    doc.setFontSize(16);
    doc.text("Resumo Executivo", 15, 65);
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    const splitSummary = doc.splitTextToSize(report.summary, 180);
    doc.text(splitSummary, 15, 75);

    // Indicators Table
    const tableY = 75 + (splitSummary.length * 6) + 15;
    doc.setFontSize(16);
    doc.setFont("helvetica", "bold");
    doc.text("Indicadores de Execução", 15, tableY);

    const tableData = [
      ["Impacto Direto", `${report.indicators.directImpact} famílias`],
      ["Impacto Indireto (Comunidade)", `${report.indicators.indirectImpact} pessoas`],
      ["Alimentos Distribuídos", `${report.indicators.foodDistributedKg} kg`],
      ["Cestas Básicas Entregues", `${report.indicators.basketsDistributed} unidades`]
    ];

    autoTable(doc, {
      startY: tableY + 8,
      head: [['Métrica', 'Resultado Alcançado']],
      body: tableData,
      headStyles: { fillColor: [2, 132, 199] },
      styles: { cellPadding: 5 }
    });

    // Footer
    const finalY = (doc as any).lastAutoTable.finalY + 30;
    doc.setDrawColor(200, 200, 200);
    doc.line(15, finalY, 195, finalY);
    doc.setFontSize(8);
    doc.text("Desenvolvido pela ATIS – Área de Tecnologia e Inovação Social do CEAP", 15, finalY + 10);
    doc.text("ceapoficial.com.br", 170, finalY + 10);

    doc.save(`Relatorio_${report.period.replace(/\s/g, "")}.pdf`);
  },

  generatePurchaseOrderPdf: (order: PurchaseOrder) => {
    const doc = new jsPDF() as any;
    const primaryColor = "#4f46e5";

    doc.setFillColor(primaryColor);
    doc.rect(0, 0, 210, 40, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.text("PEDIDO DE COMPRA", 15, 25);
    doc.setFontSize(10);
    doc.text(`PROTOCOLO: ${order.id}`, 15, 32);

    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.text("DADOS DO FORNECEDOR:", 15, 55);
    doc.setFontSize(10);
    doc.text(`Nome: ${order.supplierName}`, 15, 62);
    doc.text(`Emissão: ${new Date(order.createdAt).toLocaleDateString()}`, 15, 67);
    doc.text(`Previsao de Entrega: ${new Date(order.deliveryDate).toLocaleDateString()}`, 15, 72);

    const tableData = order.items.map((item: any) => [
      item.materialName || item.materialId,
      item.quantityRequested,
      `R$ ${item.unitValue.toLocaleString()}`,
      `R$ ${(item.quantityRequested * item.unitValue).toLocaleString()}`
    ]);

    autoTable(doc, {
      startY: 85,
      head: [['Material', 'Qtd', 'V. Unit.', 'Total']],
      body: tableData,
      headStyles: { fillColor: [79, 70, 229] },
    });

    const finalY = (doc as any).lastAutoTable.finalY + 15;
    doc.setFontSize(14);
    doc.setFont("helvetica", "bold");
    doc.text(`TOTAL DO PEDIDO: R$ ${order.totalValue.toLocaleString()}`, 15, finalY);

    doc.setFontSize(8);
    doc.setFont("helvetica", "normal");
    doc.text("Este pedido deve ser acompanhado da respectiva NF-e no ato da entrega.", 15, finalY + 15);

    doc.save(`${order.id}.pdf`);
  }
};


import { Permission, Role, RoleType, UserStatus } from './types';

export const PERMISSIONS: Permission[] = [
  // Core / Dashboard
  { code: 'dashboard.view', label: 'Ver Painel Geral', module: 'Geral' },

  // Financial
  { code: 'finance.view', label: 'Ver Financeiro', module: 'Financeiro' },
  { code: 'finance.manage', label: 'Gerir Orçamentos', module: 'Financeiro' },

  // User Management
  { code: 'users.view', label: 'Visualizar Usuários', module: 'Usuários' },
  { code: 'users.create', label: 'Criar Usuários', module: 'Usuários' },
  { code: 'users.edit', label: 'Editar Usuários', module: 'Usuários' },
  { code: 'users.delete', label: 'Desativar Usuários', module: 'Usuários' },
  { code: 'roles.manage', label: 'Gerir Perfis e Permissões', module: 'Usuários' },
  
  // Supplies
  { code: 'supplies.view', label: 'Visualizar Estoque', module: 'Suprimentos' },
  { code: 'supplies.manage', label: 'Gerir Materiais', module: 'Suprimentos' },
  { code: 'supplies.purchase.request', label: 'Solicitar Compras', module: 'Suprimentos' },
  
  // Patrimony
  { code: 'patrimony.view', label: 'Ver Patrimônio', module: 'Patrimônio' },

  // HR
  { code: 'hr.view', label: 'Ver RH', module: 'RH' },

  // Projects
  { code: 'projects.view', label: 'Visualizar Projetos', module: 'Projetos' },
  { code: 'projects.create', label: 'Criar Projetos', module: 'Projetos' },
  { code: 'projects.field.diary', label: 'Registrar Diário de Campo', module: 'Projetos' },
  
  // CRM Gira Vínculos
  { code: 'crm.view', label: 'Acessar GIRA Vínculos', module: 'Vínculos' },
  { code: 'crm.beneficiaries.manage', label: 'Gerir Beneficiários', module: 'Vínculos' },
  { code: 'crm.attendances.create', label: 'Registrar Atendimentos', module: 'Vínculos' },
  { code: 'crm.funders.manage', label: 'Gerir Financiadores', module: 'Vínculos' },

  // Contracts
  { code: 'contracts.view', label: 'Ver Contratos', module: 'Contratos' },

  // Documents
  { code: 'docs.view', label: 'Ver Documentos', module: 'GED' },

  // AI
  { code: 'ai.access', label: 'Acesso à IA', module: 'IA' },

  // System
  { code: 'system.audit', label: 'Logs de Auditoria', module: 'Configurações' },
  { code: 'system.backup', label: 'Realizar Backup', module: 'Configurações' },

  // Conformia (Compliance)
  { code: 'conformia.view', label: 'Ver Dashboard Compliance', module: 'Conformia' },
  { code: 'conformia.inventory', label: 'Gerir Inventário de Dados', module: 'Conformia' },
  { code: 'conformia.subjects', label: 'Atender Direitos dos Titulares', module: 'Conformia' },
  { code: 'conformia.thirdparty', label: 'Due Diligence de Terceiros', module: 'Conformia' },
  { code: 'conformia.incidents', label: 'Gerir Incidentes e Violações', module: 'Conformia' },
  { code: 'conformia.policies', label: 'Gerir Políticas e Documentos', module: 'Conformia' },
  { code: 'conformia.training', label: 'Gerir Treinamentos LGPD', module: 'Conformia' },
  { code: 'conformia.dpia', label: 'Realizar Relatórios DPIA', module: 'Conformia' },
];

export const INITIAL_ROLES: Role[] = [
  {
    id: 'superadmin',
    name: 'Super Admin',
    description: 'Acesso total e irrestrito ao sistema.',
    level: 99,
    financialLimit: 99999999,
    type: RoleType.INTERNAL,
    permissions: PERMISSIONS.map(p => p.code),
    icon: 'Shield',
    color: 'bg-indigo-600'
  },
  {
    id: 'direcao',
    name: 'Direção',
    description: 'Gestão estratégica e aprovações.',
    level: 10,
    financialLimit: 1000000,
    type: RoleType.INTERNAL,
    permissions: [
      'dashboard.view', 'finance.view', 'users.view', 'supplies.view', 
      'projects.view', 'crm.view', 'system.audit', 'ai.access', 'conformia.view'
    ],
    icon: 'Briefcase',
    color: 'bg-emerald-600'
  },
  {
    id: 'tecnico',
    name: 'Técnico ATIS',
    description: 'Acesso operacional e diários de campo.',
    level: 1,
    financialLimit: 10000,
    type: RoleType.INTERNAL,
    permissions: [
      'dashboard.view', 'supplies.view', 'supplies.purchase.request', 
      'projects.view', 'projects.field.diary', 'crm.view', 'crm.attendances.create', 'conformia.training'
    ],
    icon: 'Zap',
    color: 'bg-amber-500'
  }
];

export const APP_FOOTER = "© 2026 GIRA CEAP — Onde a tecnologia gira com propósito. Módulo GIRA Vínculos integrado. Desenvolvido pela ATIS – Área de Tecnologia e Inovação Social do CEAP. | v5.1 MVP";
